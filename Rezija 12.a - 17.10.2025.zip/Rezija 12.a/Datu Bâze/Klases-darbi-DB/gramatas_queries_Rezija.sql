--a
SELECT*FROM gramatas;

--b
SELECT
    gramatas.nosaukums AS Grāmatu_nosaukumi,
    gramatas.izdosanas_gads AS Grāmatas_izdošanas_gads
FROM gramatas;

--c
SELECT*FROM autori;

--d
SELECT
    autori.vards AS Autoru_vārdi,
    autori.dzimsanas_gads as Autora_dzimšanas_gads
FROM autori;

--e
SELECT*FROM zanri;

--f
SELECT*FROM izdeveji;

--g
SELECT*FROM gramatas WHERE gramatas.izdosanas_gads>=1950;

--h
SELECT*FROM autori WHERE autori.dzimsanas_gads>=1950;

--i
SELECT*FROM gramatas ORDER BY gramatas.izdosanas_gads ASC;

--j
SELECT*FROM gramatas WHERE gramatas.zanrs_id=1;

--k
SELECT
    gramatas.nosaukums AS Grāmatu_nosaukumi,
    autori.vards AS Autoru_vārdi
FROM gramatas
JOIN autori ON gramatas.autors_id=autori.autors_id
GROUP BY gramatas.nosaukums;

--l
SELECT
    gramatas.nosaukums AS Grāmatu_nosaukumi,
    autori.vards AS Autoru_vārdi,
    izdeveji.izdevejs_nosaukums AS Izdevēju_nosaukumi
FROM gramatas
JOIN autori ON gramatas.autors_id=autori.autors_id
JOIN izdeveji ON gramatas.izdevejs_id=izdeveji.izdevejs_id
GROUP BY gramatas.nosaukums;

--m
SELECT
    autori.vards AS Autoru_vārdi,
    COUNT(gramatas.gramatas_id) AS Grāmatu_skaits
FROM autori
JOIN gramatas ON autori.autors_id=gramatas.autors_id
GROUP BY autori.vards;

--n
SELECT
    autori.vards AS Autoru_vārdi,
    autori.valsts AS Autora_valsts_nosaukums
FROM autori
JOIN gramatas ON autori.autors_id=gramatas.autors_id
WHERE gramatas.zanrs_id=2;

--o
SELECT
    gramatas.nosaukums AS Grāmatu_nosaukumi,
    gramatas.izdosanas_gads AS Grāmatas_izdošanas_gads
FROM gramatas
WHERE izdosanas_gads=(SELECT MIN(izdosanas_gads)FROM gramatas)
OR izdosanas_gads=(SELECT MAX(izdosanas_gads) FROM gramatas);
