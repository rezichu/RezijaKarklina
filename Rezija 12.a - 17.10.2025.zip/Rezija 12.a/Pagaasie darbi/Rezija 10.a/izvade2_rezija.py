#Rēzija Kārkliņa
print('Lugas "Zelta zirgs" autors ir Rainis')
print('10',' 20',' 30')
print('A')
print('    B')
print('        C')
print('D')