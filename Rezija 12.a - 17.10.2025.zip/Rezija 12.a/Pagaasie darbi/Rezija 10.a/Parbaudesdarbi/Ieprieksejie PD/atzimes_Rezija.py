import datetime #Lai iegūtu datumu
from functools import reduce

laiks = input('Ievadiet ieskaites datumu formā YYYY-MM-DD: ')
datums = datetime.datetime.strptime(laiks, '%Y-%m-%d').date() #Pārveido datumu par datetime objektu un maina prasīto datu formātu
def iegut_laiku():
    while True:
        try: 
            if datums <= datetime.date.today(): #Pārbauda vai datums nav nākotnē
                print('Dati ir saglabāti failā!\n')
            else:
                print('Datums nevar būt lielāks par šodienas datumu!\n')
        except ValueError: #Formāta pārbaude 
            print('Nepareizs datuma formāts!\n') #Izveido ciklu, kas neiziet ārā no programmas
        return datums

iegut_laiku() #Funkcijas izsaukšana

tema = input('Ievadiet tēmu: ')
klase = str(input('Ievadiet klasi: '))
skoleni = int(input('Ievadiet skolēnu skaitu: '))
while True: 
    try:
        if skoleni > 18 or skoleni < 0:
            print('Ievadiet pareizus datus(skaitli no 0 līdz 18)!\n')
            skoleni = int(input('Ievadiet skolēnu skaitu: '))
            continue
        else:
            print('\n')
            break
    except ValueError: #Izveido ciklu, kas neiziet ārā no programmas
        print('Ievadiet pareizus datus(skaitli no 0 līdz 18)!\n')
        skoleni = int(input('Ievadiet skolēnu skaitu: '))
        continue

atzimes = []
for i in range(skoleni):
    print('Ievadiet datus par',i+1,'. skolēnu.')
    skolena_vards = input('Ievadiet skolēna vārdu: ')
    while True:
        try:
            atzime = int(input('Ievadiet skolēna atzīmi: '))
            if atzime > 10 or atzime < 1:
                print('Ievadiet pareizos datus(Skaitli no 1 līdz 10 vai nv)!\n')
                atzime = int(input('Ievadiet skolēna atzīmi: '))
                continue
            else:
                break
        except ValueError:
            print('Ievadiet pareizos datus(Skaitli no 1 līdz 10 vai nv)!\n')
            atzime = int(input('Ievadiet skolēna atzīmi: '))
            continue

nosaukums = tema + '.' + klase + '.txt' #Faila nosaukuma izveide
def saglabat_datus():
    with open(nosaukums, 'w', encoding='utf-8') as fails:
        fails.write({'Datums':datums, '\nTēma':tema, '\nKlase':klase, '\nSkolēniem ievadīti dati':skoleni})
        fails.close()

saglabat_datus() #Funkcijas izsaukšana