gradi = float(input("Ievadiet grādus (Celsija):"))

def farenheits():
    print(1.8*gradi+32)

farenheits()