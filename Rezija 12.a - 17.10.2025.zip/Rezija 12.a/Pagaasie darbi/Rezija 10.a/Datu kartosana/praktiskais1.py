#Izveidot vārdnīcu, kas glabā grāmatas nosaukumu kā atslēgu un lappušu skaitu kā vērtību
#pielietojot for ciklu, sakārto vārdnīcu pēc atslēgas(alfabēta secībā)
#uz ekrāna parāda gan atslēgu, gan vērtību
#sakārtot pēc lappušu skaita augoša un dilstošā secībā

'''gramata = {'Harijs Poters':400,'Sarkanā Karaliene':300,'Pirms Kafija Atdziest':100}

for atslega in sorted(gramata):
    print(atslega,gramata[atslega])
booksup=sorted(gramata.items(), key = lambda x:x[1])
print(booksup)
booksdown=sorted(gramata.items(), key = lambda x:x[1], reverse = True)
print(booksdown)
print('---------------------------------')

gramatas_augosi = dict(sorted(gramata.items()))
print('Lappušu skaits augoši:', gramatas_augosi)
gramatas_dilstosi = dict(sorted(gramata.items(), reverse = True))
print('Lappušu skaits dilstoši:', gramatas_dilstosi)'''

#izveidot vārdnīcu, kas glabā grāmatas(6) nosaukumu kā atslēgu un lappušu skaitu kā vērtību
#pielietojot for ciklu, sakārtot vārdnīcu alfabēta secībā
#uz ekrāna parādīt gan atslēgu, gan vērtību
#sakārtot pēc lappušu skaita augošā un dilstošā secībā

gramatas = {
    'Potter':'400',
    'Harry potter':'360',
    'Five nights at freddys': '180',
    'Lord of the rings':'250',
    'Horrid henry':'210',
    'Elbaf':'500'
}
for key in sorted(gramatas):
    print((key, gramatas[key]))
print('--------------------------')

gramatas_augosi = sorted(gramatas,key=gramatas.get)
gramata_kartots = {}
for key in gramatas_augosi:
    gramata_kartots[key] = gramatas[key]
print(gramata_kartots)