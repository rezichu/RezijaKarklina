print('Hello, World!')
print('Dzīvnieki') #programmas nosaukums
#teksta pārvietošana uz jaunu rindu
print('Zebras is strīpainas','\nĶenguri lēkā','\nSuns rej')
#tabulācijas atstarpe
print('\tZilonis \tir \tliels')


#atsevišķa print funkcija, bet visi vārdi viena rindā
print('Visi',end=' ')
print('vārdi',end=' ')
print('vienā',end=' ')
print('rindā')