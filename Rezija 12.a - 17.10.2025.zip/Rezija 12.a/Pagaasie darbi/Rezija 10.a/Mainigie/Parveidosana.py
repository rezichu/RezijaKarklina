#int pārveidošana par str
a = 5
b = 7
print('Skaitlis:', a + b)
print('Teksts:',str(a) + str(b)) #concat

#izveidot 2 str tipa mainīgos(vertības '123' un '456')
#pārveidot šos mainigos par int tipa
#noteikt datu tipu

m = 123
n = 456
g = int(m)
q = int(n)
print(g + q, type(q + g)) 
