#Rēzija Kārkliņa
print('Sekos tukša rinda')

print('Visi vārdi vienā rindā')
print('Visi ',end='')
print('vārdi ',end='')
print('vienā ',end='')
print('rinda')
print('No zvaigznem * veidots trijstūris')
print('  *','\n * *','\n*****')