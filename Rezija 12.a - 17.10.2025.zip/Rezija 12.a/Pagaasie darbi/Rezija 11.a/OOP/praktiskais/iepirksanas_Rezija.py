class Product:
    def __init__(self,name,price,quantity):
        self.name = name
        self.price = price
        self.quantity = quantity
    
    def get_total_price(self):
        print("The total price:",self.price * self.quantity)

tomato = Product("Tomato",0.42,20)
tomato.get_total_price()
print("-------------------------------------------")

class ShoppingCart:
    def __init__(self):
        pass

    def add_product_to_cart(self):
        pass

    def remove_product_from_cart(self):
        pass

    def get_total_price(self):
        pass

class SystemUser:
    def __init__(self,username,password,email):
        self.username = username
        self.password = password
        self.email = email

    def set_user_info(self):
        username = input("Enter your username: ")
        if username != self.username:
            print("Entered information is wrong! Please try again!")
            username = input("Enter your username: ")
        password = input("Enter your password: ")
        if password != self.password:
            print("Entered information is wrong! Please try again!")
            password = input("Enter your password: ")
        email = input("Enter your username: ")
        if email != self.email:
            print("Entered information is wrong! Please try again!")
            email = input("Enter your email: ")

    def get_user_info(self):
        print(f"Username: {self.username} \nUser's password: {self.password} \nUser's email: {self.email}")

ance = SystemUser("ance.pienene21","**AnceLiepaUnMuris**","ance.liepa@gmail.com")
ance.set_user_info()
print("\n")
ance.get_user_info()
print("-------------------------------------------")

class Customer(SystemUser):
    def __init__(self, username, password, email,customer_id,purchase_history,membership_status):
        super().__init__(username, password, email)
        self.customer_id = customer_id
        self.purchase_history = purchase_history
        self.membership_status = membership_status
    
    def set_user_info(self):
        pass

    def get_user_info(self):
        print(f"Customer ID: {self.customer_id} \nUser's purchase history: {self.purchase_history} \nUser's membership status: {self.membership_status}")