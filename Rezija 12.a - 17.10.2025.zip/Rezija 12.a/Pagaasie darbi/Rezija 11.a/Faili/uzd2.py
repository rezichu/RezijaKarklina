import csv
#ievietot failā 5 ierakastus, parādīt uz ekrāna 3 no tiem

csv_file = 'darbinieki.csv'
#ierakstāmie dati
darbinieki = [
    {'Vārds':'Anna','Amats':'Skursteņslauķe','Alga':900},
    {'Vārds':'Mārtiņš','Amats':'Datoriķis','Alga':2000},
    {'Vārds':'Romija','Amats':'Zinātniece','Alga':1950},
    {'Vārds':'Kristaps','Amats':'inžinieris','Alga':"liepa"},
    {'Vārds':'Paulīne','Amats':'Apkopēja','Alga':800},
    {'Vārds':'Laura','Amats':'Daktere','Alga':"uno"}
]
#datu ierakstīšana failā
with open(csv_file, "w", encoding='utf8', newline='') as file:
    fieldnames = ['Vārds','Amats','Alga'] #kolonnu nosaukumi
    writer=csv.DictWriter(file, fieldnames)
    writer.writeheader() #ieraksta galveno
    writer.writerows(darbinieki)

#nolasīt faila saturu un parādīt darbiniekus ar algu >1000
'''with open(csv_file, "r", encoding='utf8') as file:
    reader=csv.DictReader(file)
    
    for rinda in reader:
        if int(rinda['Alga'])>1000:
            print(f"Vārds:{rinda['Vārds']},Amats:{rinda['Amats']},Alga:{rinda['Alga']}")'''

#nolasīt faila saturu un veikt pārbaudi
try:
    with open(csv_file, "r", encoding='utf8', newline='') as file:
        reader = csv.DictReader(file)
        algas_filtrs = []
        for rinda in reader:
            try:
                alga = int(rinda['Alga'])
                if alga > 1000:
                    algas_filtrs.append(rinda)
            except ValueError:
                print(f"Brīdinājums: Rindā {rinda['Vārds']} {rinda['Amats']} nav derīga alga!")
        if algas_filtrs:
            for darbinieks in algas_filtrs:
                print(f"Vārds:{darbinieks['Vārds']},Amats:{darbinieks['Amats']},Alga:{darbinieks['Alga']}")
        else:
            print("Nav tādu darbinieku!")
except FileNotFoundError:
    print(f"Brīdinājums: fails {csv_file} neeksistē!")
except Exception as e:
    print(f"Kļūda nolasot failu: {e}")