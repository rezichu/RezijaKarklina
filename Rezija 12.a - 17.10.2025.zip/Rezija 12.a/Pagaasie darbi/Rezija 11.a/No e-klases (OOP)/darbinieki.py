#bāzes klase Darbinieks
class Darbinieks:
    def __init__(self, vards, uzvards, alga):
        self.vards = vards  
        self.uzvards = uzvards 
        self.alga = alga  

    def uzraditInfo(self):
        print(f"{self.vards} {self.uzvards}, alga: {self.alga}") #metode, ko pārrakstīs


#bāzes klase Programmētājs
class Programmetajs(Darbinieks):
    def __init__(self, vards, uzvards, alga, programmesanasValoda):
        super().__init__(vards, uzvards, alga)  #pamatklases konstruktors
        self.programmesanasValoda = programmesanasValoda  ##papildus ipasiba tieši šai klasei

    def uzraditInfo(self):
        super().uzraditInfo()  #pamatklases metode
        print(f"Programmēšanas valoda: {self.programmesanasValoda}")  #papildus informacija


#bāzes klasePārdevējs
class Pardevejs(Darbinieks):
    def __init__(self, vards, uzvards, alga, pārdošanasApjoms):
        super().__init__(vards, uzvards, alga) #pamatklases konstruktors
        self.pārdošanasApjoms = pārdošanasApjoms   ##papildus ipasiba tieši šai klasei

    def uzraditInfo(self):
        super().uzraditInfo()  #Izsaucam pamatklases metodi
        print(f"Pārdošanas apjoms: {self.pārdošanasApjoms}") 


#objektu izvediosana
programmetajs = Programmetajs("Jānis", "Bērziņš", 2000, "Python")
pardevejs = Pardevejs("Anna", "Liepiņa", 1500, 10000)

# Izsaucam metodi uzraditInfo() katram objektam, kas izvadīs informaaciju
programmetajs.uzraditInfo()  
pardevejs.uzraditInfo()  