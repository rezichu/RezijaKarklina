#parasta vārdnīca
vardi = {
    1:"Jēkabs",
    2:"Linards",
    3:"Gunārs",
    4:"Emīls",
    5:"Artūrs",
    6:"Jānis"
}
print(dict)

#vārdnīca vārdnīcā
