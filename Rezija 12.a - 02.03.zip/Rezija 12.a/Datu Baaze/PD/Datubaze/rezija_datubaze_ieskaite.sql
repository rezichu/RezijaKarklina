DROP TABLE IF EXISTS televizijas_sovi;
DROP TABLE IF EXISTS sovu_dalibnieki;
DROP TABLE IF EXISTS sovu_dalibas;

CREATE TABLE IF NOT EXISTS televizijas_sovi(
    televizijas_sovi_id INTEGER PRIMARY KEY AUTOINCREMENT,
    nosaukums TEXT NOT NULL,
    kanals TEXT NOT NULL,
    zanrs TEXT NOT NULL,
    gads INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sovu_dalibnieki(
    sovu_dalibnieki_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards TEXT NOT NULL,
    uzvards TEXT NOT NULL,
    profesija TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sovu_dalibas(
    sovu_dalibas_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sovu_dalibnieki_id INTEGER NOT NULL,
    televizijas_sovi_id INTEGER NOT NULL,
    loma TEXT NOT NULL,
    FOREIGN KEY(sovu_dalibnieki_id) REFERENCES sovu_dalibnieki(sovu_dalibnieki_id) ON DELETE CASCADE,
    FOREIGN KEY(televizijas_sovi_id) REFERENCES televizijas_sovi(televizijas_sovi_id) ON DELETE CASCADE,
    UNIQUE(sovu_dalibnieki_id,televizijas_sovi_id)
);

INSERT INTO televizijas_sovi(nosaukums, kanals, zanrs, gads) VALUES
('X Faktors', 'TV3', 'Mūzika', 2017),
('Balss maskā', 'TV3', 'Mūzika', 2020),
('Supernova', 'LTV1', 'Konkurss', 2015),
('Lauku sēta', 'Go3', 'Sarunu šovs', 2011),
('Gudrs, vēl gudrāks', 'LTV1', 'Spēle', 2012);

INSERT INTO sovu_dalibnieki(vards, uzvards, profesija) VALUES
('Aija', 'Ozoliņa', 'Žurnāliste'),
('Jānis', 'Kalniņš', 'Šefpavārs'),
('Elīna', 'Bērziņa', 'Režisore'),
('Roberts', 'Liepiņš', 'Ārsts'),
('Laura', 'Mežs', 'Profesors'),
('Mārtiņš', 'Krastiņš', 'Šefpavārs'),
('Baiba', 'Grīnberga', 'Pasākumu vadītāja'),
('Kristaps', 'Ozols', 'Ārsts'),
('Rūta', 'Ābele', 'Grima māksliniece'),
('Gatis', 'Vilsons', 'Ārsts'),
('Dace', 'Eglīte', 'Redaktore'),
('Renārs', 'Ziediņš', 'Profesors');

INSERT INTO sovu_dalibas(sovu_dalibnieki_id, televizijas_sovi_id, loma) VALUES
(1, 1, 'Dalībniece'),
(1, 3, 'Dalībniece'),
(2, 1, 'Dalībnieks'),
(2, 4, 'Dalībnieks'),
(3, 2, 'Vadītāja'),
(3, 5, 'Vadītāja'),
(4, 1, 'Dalībnieks'),
(4, 3, 'Dalībnieks'),
(5, 2, 'Dalībniece'),
(6, 4, 'Dalībnieks'),
(7, 5, 'Vadītāja'),
(8, 4, 'Dalībnieks'),
(9, 1, 'Dalībniece'),
(9, 5, 'Dalībniece'),
(10, 3, 'Dalībnieks'),
(11, 3, 'Žūrija'),
(12, 3, 'Žūrija'),
(12, 1, 'Viesis');

--a)
SELECT
    nosaukums AS Sova_nosaukums,
    kanals AS TV_kanals,
    zanrs AS Sova_zanrs
FROM televizijas_sovi;

--b)
SELECT
    vards || ' ' || uzvards AS Dalibnieka_vards,
    profesija AS Dalibnieka_profesija
FROM sovu_dalibnieki
WHERE profesija='Ārsts';

--c)
SELECT
    nosaukums AS Sova_nosaukums,
    kanals AS TV_kanals,
    gads AS Sova_izlaisanas_gads
FROM televizijas_sovi
WHERE gads>2018;

--d)
SELECT
    nosaukums AS Sova_nosaukums,
    kanals AS TV_kanals
FROM televizijas_sovi
WHERE kanals='Go3' OR kanals='TV3';

--e)
SELECT 
    vards || ' ' || uzvards AS Dalibnieka_vards,
    nosaukums AS Sova_nosaukums,
    loma AS Dalibnieka_loma
FROM sovu_dalibas
JOIN sovu_dalibnieki ON sovu_dalibas.sovu_dalibnieki_id=sovu_dalibnieki.sovu_dalibnieki_id
JOIN televizijas_sovi ON sovu_dalibas.televizijas_sovi_id=televizijas_sovi.televizijas_sovi_id
ORDER BY nosaukums DESC;

--f)
SELECT
    nosaukums AS Sova_nosaukums,
    vards || ' ' || uzvards AS Zurijas_vards
FROM sovu_dalibas
JOIN sovu_dalibnieki ON sovu_dalibas.sovu_dalibnieki_id=sovu_dalibnieki.sovu_dalibnieki_id
JOIN televizijas_sovi ON sovu_dalibas.televizijas_sovi_id=televizijas_sovi.televizijas_sovi_id
WHERE loma='Žūrija';

--g)
SELECT
    kanals AS TV_kanals,
    COUNT(nosaukums) AS Sovu_skaits
FROM televizijas_sovi
GROUP BY kanals
ORDER BY COUNT(nosaukums) ASC;

--h)
SELECT
    vards || ' ' || uzvards AS Dalibnieka_vards,
    COUNT(sovu_dalibas.sovu_dalibnieki_id) AS Sovu_skaits
FROM sovu_dalibnieki
JOIN sovu_dalibas ON sovu_dalibnieki.sovu_dalibnieki_id=sovu_dalibas.sovu_dalibnieki_id
GROUP BY vards
ORDER BY COUNT(sovu_dalibas.sovu_dalibnieki_id) ASC;

--i)
SELECT
    nosaukums AS Sova_nosaukums,
    COUNT(sovu_dalibas.sovu_dalibnieki_id) AS Dalibnieku_skaits
FROM televizijas_sovi
JOIN sovu_dalibas ON televizijas_sovi.televizijas_sovi_id=sovu_dalibas.televizijas_sovi_id
GROUP BY nosaukums;

--j)
SELECT
    vards || ' ' || uzvards AS Dalibnieka_vards,
    nosaukums AS Sova_nosaukums
FROM sovu_dalibas
JOIN sovu_dalibnieki ON sovu_dalibas.sovu_dalibnieki_id=sovu_dalibnieki.sovu_dalibnieki_id
JOIN televizijas_sovi ON sovu_dalibas.televizijas_sovi_id=televizijas_sovi.televizijas_sovi_id
GROUP BY vards
HAVING COUNT(vards)>1;