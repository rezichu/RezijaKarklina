#piemērs sarakstam ar dažādiem datu tipiem
mixed_list = ['suns', 7.25, 8, True]
print(mixed_list[2])

#apgriezt skaitļu sarakstu
skaitli = [1,2,4,5,6,7,3,4,7,8,9,7]
apgriezt = list(reversed(skaitli))
print(apgriezt)

#filtrēt tikai pāra skaitļus
para_skaitli = [num for num in skaitli if num%2 == 0]
print(para_skaitli)

#iegūst saraksta garumu
#garums = len(skaitli)

videjais = sum(skaitli)/len(skaitli)
print(f"Videjais skaitlis: {videjais}")

#atrast lielāko un mazāko skaitli, parādīt uz ekrāna
lielakais = max(skaitli)
mazakais = min(skaitli)
print(f"Mazākais skaitlis ir: {mazakais}")
print(f"Lielākais skaitlis ir: {lielakais}")

#filtrēt tikai nepāra skaitļus
para_skaitli = [num for num in skaitli if num%2 != 0]

#sarakste ar 5 augļiem
augli = ['citroni', 'ananass', 'apelsīns', 'mango', 'bumbiers']
#atrast vārdus, kas sākas ar konkrētu burtu
varda_sakums = [vards for vards in augli if vards.startswith('a')]
print(f"Vārdi, kas sākas ar 'a':{varda_sakums}")