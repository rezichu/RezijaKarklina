krasas = {
    'red':'#FF0000',
    'green':'#008000',
    'black':'#000000',
    'white':'#FFFFFF'
}

for atslega in sorted(krasas):
    print(atslega, krasas[atslega])

saraksts = ['viens','divi','burkāns','pelēks','helikopters']
saraksts_augosi = sorted(saraksts,key = len) #pēc garuma augošā secībā
saraksts_dilstosi = sorted(saraksts,key = len,reverse = True) #pēc garuma augošā secībā, bet otrādi
print('Augošā secībā pēc garuma:', saraksts_augosi)
print('Dilstoša secībā pēc garuma:', saraksts_dilstosi)

gramata = ['Mājkalpotāja','TITĀNIKS','you','AFTER','dune']
gramata.sort
print('Kārtots:',gramata)
gramata.sort()
print('Kārtots:',gramata)

print(sorted(gramata, key = str.lower)) #Ignorē lielos burtus