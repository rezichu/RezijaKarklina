#definē klasi dzivnieks, kas ir saistīta ar kāju skaitu
class Dzivnieks:
    def __init__(self,kaju_skaits = 0):
        self.kaju_skaits = kaju_skaits

    @classmethod #izmanto objektu izveidošanai ar noteiktu kāju skaitu
    def putns(kajas):
        return kajas(2)

    @classmethod
    def majlops(kajas):
        return kajas(4)

    @classmethod
    def zirneklis(kajas):
        return kajas(8)
    
    @classmethod
    def simtkajis(kajas):
        return kajas(100)
    #metode, kas izdrukā kāju skaitu
    def izdrukat_kaju_skaits(self):
        print(self.kaju_skaits)

#objekts(instance) 
odze = Dzivnieks()
zoss = Dzivnieks.putns()
kaza = Dzivnieks.majlops()
zirneklis = Dzivnieks.zirneklis()
simtkajis = Dzivnieks.simtkajis()

odze.izdrukat_kaju_skaits()
zoss.izdrukat_kaju_skaits()
kaza.izdrukat_kaju_skaits()
zirneklis.izdrukat_kaju_skaits()
simtkajis.izdrukat_kaju_skaits()