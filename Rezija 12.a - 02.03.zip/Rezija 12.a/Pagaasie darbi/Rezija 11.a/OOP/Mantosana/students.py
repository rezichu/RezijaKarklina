#bāzes klases Persona ar laukiem vārds, vecums un metodi, kas šos datus izdrukā
class Persona:
    def __init__(self,vards,vecums):
        self.vards = vards
        self.vecums = vecums
    def izdrukat(self):
        print(f"Students: {self.vards} \nStudenta vecums: {self.vecums}")
#atvasinātā klase students, kas manto abus divus laukus un pievieno specifisko lauku "kurss"
class Students(Persona):
    def __init__(self,vards,vecums,kurss):
        super().__init__(vards,vecums)
        self.kurss = kurss
        #metodes pārrakstīšana
    def izdrukat(self):
        super().izdrukat()
        print(f"Kurss: {self.kurss}")
#izveido katrai klasei vienu objektu
students1 = Persona("Alnis",20)
students1.izdrukat()

students2 = Students("Sandra",19,2)
students2.izdrukat()

super(Students,students2).izdrukat()