print("-------------------------------------------") #Lai vieglāk pārskatīt konsolē izvadīto infomāciju :]
class Masina: #A uzdevums - bāzes klases izveide
    def __init__(self,marka,modelis,gads):
        self.marka = marka
        self.modelis = modelis
        self.gads = gads
    
    def uzsakt(self):#B uzdevums - 3 metožu izveide - uzsakt(), kas parāda ka konkrēta mašīna sāk darboties
        print(f"{self.marka} {self.modelis} sāk darboties.")

    def apstaties(self):#B uzdevums - 3 metožu izveide - apstaties(), kas parāda ka konkrēta mašīna ir apstādināta
        print(f"{self.marka} {self.modelis} ir apstādināta.")

    def info_par_auto(self): #B uzdevums - 3 metožu izveide - info_par_auto(), kas parāda infomāciju par konkrētu mašīnu
        print(f"Marka: {self.marka}, Modelis: {self.modelis}, Gads: {self.gads}")

masina1 = Masina("Toyota","Corolla",2010) #C uzdevums - izveido objektu klasei Masina
masina1.info_par_auto()
masina1.uzsakt()
masina1.apstaties()
print("-------------------------------------------")

class Elektro_Auto(Masina): #D uzdevums - izveido atvasinātu klasi Elektro_Auto, kas manto visus atribūtus un metodes no klases Masina un izveido atribūtu akumulatora_ietilp
    def __init__(self,marka,modelis,gads,akumulatora_ietilp):
        super().__init__(marka,modelis,gads)
        self.akumulatora_ietilp = akumulatora_ietilp 
        self.akumulatora_uzlades_limenis = 100 #E uzdevums - iestatīt noklusēto akumulatora līmeni 100

    def uzsakt(self): #F uzdevums - pārraksta metodi uzsakt(), lai pārbauda vai akumulatora uzlādes līmenis ir >=20
        if self.akumulatora_uzlades_limenis >= 20: 
            print(f"{self.marka} {self.modelis} sāk darboties. Akumulators: {self.akumulatora_uzlades_limenis}%")
        elif self.akumulatora_uzlades_limenis < 20:
            print(f"{self.marka} {self.modelis} nevar sākt darboties, jo akumulators ir pārāk zems: {self.akumulatora_uzlades_limenis}%")

    def apstaties(self):
        return super().apstaties()

    def info_par_auto(self): #G uzdevums - nodrošina, ka metode info_par_auto() parāda akumulatora ietilpību kWh
        super().info_par_auto()
        print(f"Akumulators: {self.akumulatora_ietilp} kWh")

    def iestatit_akumulatoru(self): #I uzdevums - simulē akumulatora līmeņa samazināšanos
        self.akumulatora_uzlades_limenis = 15

masina2 = Elektro_Auto("Tesla","Model 3",2022,75) #H uzdevums - izveido objektu
masina2.info_par_auto()
masina2.uzsakt()
masina2.iestatit_akumulatoru()
masina2.uzsakt() #izsauc metodi uzsakt() vēl reiz, kā dots pāraugā
print("-------------------------------------------")

class Degvielas_Auto(Masina): #atvasināta klase manto no klases Masina
    def __init__(self,marka,modelis,gads,bakas_tilpums):
        super().__init__(marka,modelis,gads)
        self.bakas_tilpums = bakas_tilpums #šai klasei unikāls atribūts
        self.degvielas_limenis = 100 #iestata bākas uzpildes līmeni
    
    def uzsakt(self):
        if self.degvielas_limenis >= 10: #pārbauda vai bākas uzpildes līmenis ir pietiekami liels
            print(f"{self.marka} {self.modelis} sāk darboties. Degvielas līmenis: {self.degvielas_limenis}%")
        elif self.degvielas_limenis < 10:
            print(f"{self.marka} {self.modelis} nevar sākt darboties, jo degvielas līmenis ir pārāk zems: {self.degvielas_limenis}%")
        
    def apstaties(self):
        return super().apstaties() #ar metodi super() manto no vecāk klases

    def info_par_auto(self):
        super().info_par_auto()
        print(f"Bākas tilpums: {self.bakas_tilpums} litri") #pievieno papildus informāciju pie mantotā teksta
    
    def iestatit_baku(self): #simulē bākas uzpildes līmeņa samazināšanos
        self.degvielas_limenis = 5

masina3 = Degvielas_Auto("Audi","A7",2022,85) #objekta izveide
masina3.info_par_auto()
masina3.uzsakt()
masina3.iestatit_baku()
masina3.uzsakt() #izsauc metodi uzsakt() vēl reiz, kā dots pāraugā
print("-------------------------------------------")