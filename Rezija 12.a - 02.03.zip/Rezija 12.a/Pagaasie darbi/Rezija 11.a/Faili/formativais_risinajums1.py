def parbaudit_vardu_uzvardu(teksts):
    return teksts.isalpha() and teksts.strip() 

def parbaudit_vecumu(vecums):
    return vecums.isdigit() and int(vecums)>0 #vecuma ierobežošana

def parbaudit_atzimi(atzime):
    return atzime.isdigit and 0<=int(atzime)<=10 #atzīmes ierobežošana

def ierobezo_meginajumus(parbaudit_funkcija, ievades_teksts, kludas_teksts):
    #ievades ar pārbaudi, kur atļauj max 3 mēģīnājumus
    for i in range(3):
        dati = input(ievades_teksts)
        if parbaudit_funkcija(dati):
            return dati
        print(kludas_teksts)
    print("Pārsniegts mēģinājumu skaits!")

def iegut_ierakstu():
    ieraksti = []
    while True:
        #vārda uzvārda ievade un pārbaude
        vards =ierobezo_meginajumus(parbaudit_vardu_uzvardu,
                                    "Ievadiet vārdu: ",
                                    "Kļūda: Vārdā drīkst būt tikai burti.")
        if not vards:
            break
        uzvards =ierobezo_meginajumus(parbaudit_vardu_uzvardu,
                                    "Ievadiet uzvārdu: ",
                                    "Kļūda: Uzvārdā drīkst būt tikai burti.")
        if not uzvards:
            break
        #vecuma ievade un pārbaude
        vecums =ierobezo_meginajumus(parbaudit_vecumu,
                                    "Ievadiet vecumu: ",
                                    "Kļūda: Vecumā drīkst būt tikai skaitļi.")
        if not vecums:
            break
        #atzīmes ievade un pārbaude
        atzime =ierobezo_meginajumus(parbaudit_atzimi,
                                    "Ievadiet gala atzīmi (1-10): ",
                                    "Kļūda: Atzīmē drīkst būt tikai skaitļi.")
        if not atzime:
            break

        ieraksti.append((vards,uzvards,int(vecums),int(atzime)))
        turpinat = input("Vai turpināt(j/n): ").lower()
        if turpinat != "j": #ja nav vienāds ar jā
            break
        return ieraksti

def saglabat_faila(ieraksti, faila_nosaukums="kontroldarbs.txt"):
    #saglabāt ierakstus ar tabulatoriem starp laukiem
    with open(faila_nosaukums, "a", encoding='utf8') as file:
        for ieraksts in ieraksti:
            file.write("\t".join(map(str,ieraksts))+ "\n")
    print(f"Dati saglabāt failā: {faila_nosaukums}")

'''def paradit_sakartotus_datus(ieraksti):
    #sakārtoti dati pēc gala atzīmes
    #definēt anonīmo funkciju lambda, kas pieņem 1 argumentu x (katrs ieraksts no saraksta)
    sakartoti_ieraksti = sorted(ieraksti,key=lambda x:x[3])
    print("\nVārds\tUzvārds\tVecums\tAtzīme")
    for ieraksts in sakartoti_ieraksti:
        print("\t".join(map(str,ieraksts)))'''

def paradit_sakartotus_datus(ieraksti):
    #sakārtoti dati pēc gala atzīmes
    #definēt anonīmo funkciju lambda, kas pieņem 1 argumentu x (katrs ieraksts no saraksta)
    sakartoti_ieraksti = sorted(ieraksti,key=lambda x:x[3])
    print("\nVārds\tUzvārds\tVecums\tAtzīme")
    for ieraksts in sakartoti_ieraksti:
        print("\t".join(map(str,ieraksts)))

#kārtošanas opcija ar atsevišķu funkciju
def iegut_gala_atzimi(ieraksts):
    return ieraksts[3]

def izvele(): #programmas galvenā daļa
    ieraksti = []

    while True:
        print("\nIzvēlieties darbību:")
        print("1 - Iegūt datus")
        print("2 - Saglabāt datus failā")
        print("3 - Parādīt datus sakārtotus pēc gala atzīmes (augošā secībā)")
        print("4 - Iziet no programmas")
        izvele = input("Jūsu izvēle: ")

        if izvele == '1':
            ieraksti += iegut_ierakstu()
        elif izvele == '2':
            if ieraksti:
                saglabat_faila(ieraksti)
            else:
                print("Nav datu, ko saglabāt!")
        elif izvele == '3':
            if ieraksti:
                paradit_sakartotus_datus(ieraksti)
            else:
                print("Nav datu, ko parādīt!")
        elif izvele == '4':
            print("Programma pārtraukta.")
            break
        else:
            print("Nepareiza izvēle. Lūdzu, mēģiniet vēlreiz.")

izvele()