print("1.uzvevums - darbs ar sarakstu")
saraksts=[]

parbaude=0
while parbaude<10:
    try:
        skaitlis=int(input("Ievadiet veselu skaitli: "))
        saraksts.append(skaitlis)
        parbaude=parbaude+1
    except ValueError:
        print("Ievadiet veselu skaitli!")

print(saraksts)
summa=0
for num in saraksts:
    summa += num
print("Saraksta vērtību summa: ",summa)

print("2.uzvevums - darbs ar vārdnīcu")
