class Doktorats:
    def __init__(self): #konstruktors, bez dotiem datiem
        self.nosaukums = "" #tiek izveidoti tukši lauki
        self.pacientu_skaits = 0

    def ievade(self): #metode, kas ļauj ievadīt datus
        self.nosaukums = input("Ievadiet doktorāta nosaukums: ")
        while True:
            try:
                self.pacientu_skaits = int(input("Ievadiet doktorāta pacientu skaitu: "))
                break
            except ValueError: #pārbauda vai ievadītais ir skaitlis
                print("Ievadet derīgus datus!")

    def izvade(self): #metode, kas ļauj izvadīt iegūtos datus pēc prasītā formāta
        print(f"\nDoktorāts {self.nosaukums} apkalpo {self.pacientu_skaits} pacientus.")

#objekts klasei Doktorats, kam nav doti parametri
dati = Doktorats()
dati.ievade() #izsauc ievadi un izvadi ar ārpus bāzes klases
dati.izvade()