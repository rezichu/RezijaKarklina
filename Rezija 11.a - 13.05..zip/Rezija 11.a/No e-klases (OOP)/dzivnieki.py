
class Dzīvnieks:
    def __init__(self, vārds, vecums):
        self.vārds = vārds  
        self.vecums = vecums  

    def izdodSkanu(self):
        print("Nezināms skan")  #Noklusētā metode


#apakšklase suns
class suns(Dzīvnieks):
    def izdodSkanu(self):
        print(f"{self.vārds} saka: Vau vau!")  #Pārraksta metodi, lai atbilstu sunim


#apakšklase kakis
class Kakis(Dzīvnieks):
    def izdodSkanu(self):
        print(f"{self.vārds} saka: Ņau Ņau!")  #Pārraksta metodi, lai atbilstu kaķim


#Izveido objektus
suns = suns("Reksis", 3)
kakis = Kakis("Muris", 5)

#Izsaucam metodi izdodSkanu() katram objektam
suns.izdodSkanu()  #Izvadīs: Reksis saka: Vau vau!
kakis.izdodSkanu()  #Izvadīs: Muris saka: Ņau Ņau!