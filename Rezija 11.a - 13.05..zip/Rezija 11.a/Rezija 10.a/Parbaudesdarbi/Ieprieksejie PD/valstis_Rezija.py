valstis = { #Iedzīvotāju skaits ir miljonos
    'Latvija':1.884,
    'Igaunija':1.331,
    'Lietuva':2.801,
    'Zviedrija':10.42,
    'Somija':5.541,
    'Dānija':5.857,
    'Vācija':83.2,
    'Austrija':8.956,
    'Norvēģija':5.408,
    'Francija':67.75
}
print('1 - valstis sakārtotas pēc nosaukuma augošā secībā \n2 - valstis sakārtotas pēc nosaukuma dilstošā secībā \n5 - pievienot jaunu valsti ar iedzīvotāju skaitu \n6 - apskatīt visas valstis')
print("Ja vēlaties beigt, ievadiet 'stop'")

izvele = int(input('Ko jūs vēlētos darīt?: '))
while izvele != 'stop': #Loop
    if izvele == 1:
        print('Jūs izvēlējāties sakārtot valstis augošā secībā pēc to nosaukuma.')
        valstis = sorted(valstis,key = len) #Ņem pēc valsts nosaukuma lieluma
        print(valstis)
        izvele = int(input('Ko jūs vēlētos darīt?: ')) #Lai strādātu loop
        continue
    elif izvele == 2:
        print('Jūs izvēlējāties sakārtot valstis dilstošā secībā pēc to nosaukuma.')
        valstis = sorted(valstis,key = len,reverse = True) #ņem pēc valsts nosaukuma lieluma un ņem otrādi
        print(valstis)
        izvele = int(input('Ko jūs vēlētos darīt?: '))
        continue
    elif izvele == 5:
        print('Jūs izvēlējāties pievienot jaunu valsti un to iedzīvotāju skaitu.')
        valstis_atsl = str(input('Ievadiet valsts nosaukumu: ')) #Lietotājam jāievada valsts nosaukums
        valstis_vert = int(input('Ievadiet valsts iedzīvotāju skaitu: ')) #Lietotājam jāievada valsts iedzīvotāja skaits
        valstis[valstis_atsl] = valstis_vert #Pievieno datus
        print(valstis)
        izvele = int(input('Ko jūs vēlētos darīt?: '))
        continue
    elif izvele == 6:
        print('Jūs izvēlējāties apskatīt visas valstis vārdnīcā.')
        print(valstis)
        izvele = int(input('Ko jūs vēlētos darīt?: '))
        continue
    else:
        print('Ievadiet pareizos datus.') #Lai ievada pareizos datus
        izvele = int(input('Ko jūs vēlētos darīt?: '))
        continue