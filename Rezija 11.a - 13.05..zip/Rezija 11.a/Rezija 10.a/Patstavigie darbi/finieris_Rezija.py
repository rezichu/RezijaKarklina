def materialuUzskaite():
    mat_veids = input('Ievadiet materiāla veidu (finieris, liste, stūris): ')
    pod_izmers = float(input('Ievadiet podesta izmēru: '))
    pas_skaits = int(input('Ievadiet pasūtījumu skaitu: '))


def materialuAprekins():
    print()

def iegut_pareizus_datus():
    print()

def galvenais():
    materialuUzskaite()

galvenais()