masina = 'Volvo'
x = 50

x = 5
y = 10
print(x + y)

z = x + y
print(z) 

my_first_name = "John"