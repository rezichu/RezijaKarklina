#ierakstīt teksta failā(no programmas) vārdu, uzvārdu un vecumu
#konsolē parādīt sakārtotus datus pēc vecuma(nospiežot 3)
'''dot iespēju izvēlēties: 
1-pievienot datus, 
2-parādīt sakārtotus datus pēc vecuma
3-sakārtot datus
4-iziet'''
#apstrādāt kļūdas

def parbaudit_vardu(vards): #pārbauda vai dati sastāv tikai no burtiem
    if not vards.isalpha():
        print("Vārdā drīkst būt tikai burti!")
        return False
    return True

def parbaudit_vecumu(vecums): #pārbauda vai derīgi dati
    if not vecums.isdigit():
        print("Vecumam jābūt skaitlim!")
        return False
    if int(vecums)<= 0:
        print("Vecumam ir jābūt lielākam par 0!")
        return False
    return True

def normalizet_vardu(vards):
    return vards.strip().capitalize() #noņem liekās atstarpes un uzliek lielo sākuma burtu

def dublikats(vards, uzvards, vecums, faila_nosaukums):
    try:
        with open("dati.txt", "r", encoding='utf8') as file:
            dati = file.readlines()
        ieraksts = f"{vards},{uzvards},{vecums}\n"
        return ieraksts in dati
    except FileNotFoundError:
        return False #fails nav izveidots, tātad dublikātu nav

def pievienot_datus_failam(faila_nosaukums):
    try:
        with open("dati.txt", "a", encoding='utf8') as file:
            while True:
                vards = input("Ievadiet vārdu: ")
                if not parbaudit_vardu(vards):
                    vards = normalizet_vardu(vards)
                    break

            while True:
                uzvards = input("Ievadiet uzvārdu: ")
                if not parbaudit_vardu(uzvards):
                    uzvards = normalizet_vardu(uzvards)
                    break

            while True:
                vecums = input("Ievadiet vecumu: ")
                if not parbaudit_vecumu(vecums):
                    break

            if dublikats(vards, uzvards, vecums, faila_nosaukums):
                print("Šis ieraksts jau pastāv!")
                return

            #dati tiek saglabāti teksta failā
            file.write(f"{vards} {uzvards} {vecums}\n")
        print("Dati ir pievienoti!")
    except Exception as e:
        print(f"Kļūda, saglabājot datus failā: {e}")

def paradit_datus(faila_nosaukums):
    try:
        with open("dati.txt", "r", encoding='utf8') as file:
            dati = file.readlines()
        if not dati: #Pārbauda vai failā ir dati
            print("Fails ir tukšs. Pievienojiet datus.")
        else:
            print("\nDati no faila: ")
            for ieraksts in dati():
                print(ieraksts.strip())
    except FileNotFoundError:
        print(f"Fails {faila_nosaukums} nepastāv!")

def iegut_vecumu_no_datiem(ieraksts):
    try:
        vecums = int(ieraksts.strip().split(",")[-1])
        return vecums
        #ja formāts nav pareizs, tad atgriež 0
    except(IndexError, ValueError):
        return 0

def sakartot_un_paradit(faila_nosaukums):
    try:
        with open("dati.txt", "r", encoding='utf8') as file:
            dati=file.readlines()
        if not dati: #Pārbauda vai failā ir dati
            print("Fails ir tukšs. Pievienojiet datus.")
        else:
            #kārtošana
            sakartoti_dati = sorted(dati, key=iegut_vecumu_no_datiem)
            print("\nPēc vecuma sakārtoti dati: ")
            for ieraksts in sakartoti_dati:
                print(ieraksts)
    except FileNotFoundError:
        print(f"Fails {faila_nosaukums} nepastāv!")

#programmas galvenā daļa
def izvele():
    faila_nosaukums = "dati.txt"

    while True:
        print("\nIzvēlieties opciju:")
        print("1 - Pievienot datus")
        print("2 - Parādit datus")
        print("3 - Parādīt sakārtotus datus pēc vecuma")
        print("4 - Iziet")

        izvele = input("Izvēle: ")
        if izvele == '1':
            pievienot_datus_failam(faila_nosaukums)
        elif izvele == '2': #nolasa datus no faila ar ciklu
            paradit_datus(faila_nosaukums)
        elif izvele == '3':
            sakartot_un_paradit(faila_nosaukums)
        elif izvele == '4':
            print("Izvēle tiek pārtraukta.")
            break
        else:
            print("Nepareiza izvēle. Mēģiniet vēlreiz.")

izvele()