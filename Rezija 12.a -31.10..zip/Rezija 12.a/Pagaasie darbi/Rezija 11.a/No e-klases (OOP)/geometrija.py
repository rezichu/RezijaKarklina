import math

class Forma: #bāzes klase visām ģeometriskajām figūrām(kā šablons citām klasēm)
    #metodes aprekinatLaukumu() un aprekinatPerimetru(), kas atgriež 0 (jo bāzes klase nezin, kā konkrēti aprēķināt laukumu un perimetru).
    def aprekinatLaukumu(self):
        return 0
    
    def aprekinatPerimetru(self):
        return 0

class Kvadrats(Forma):#manto bāzes klasei forma
    def __init__(self, mala): #saglabā malas garumu
        self.mala = mala
    
    def aprekinatLaukumu(self):
        return self.mala ** 2
    
    def aprekinatPerimetru(self):
        return 4 * self.mala

class Taisnsturis(Forma): #Manto Forma klasi. Konstruktorā saglabā garumu un platumu.
    def __init__(self, garums, platums):
        self.garums = garums
        self.platums = platums
    
    def aprekinatLaukumu(self):
        return self.garums * self.platums
    
    def aprekinatPerimetru(self):
        return 2 * (self.garums + self.platums)

class Aplis(Forma):  #Manto Forma klasi.
#Konstruktorā saglabā rādiusu.
    def __init__(self, radiuss):
        self.radiuss = radiuss
    
    def aprekinatLaukumu(self):
        return math.pi * self.radiuss ** 2
    
    def aprekinatPerimetru(self):
        return 2 * math.pi * self.radiuss

#Izveido sarakstu formas, kurā ir dažādas formas (Kvadrats, Taisnsturis, Aplis).
#Izmanto for ciklu, lai visām formām izsauktu aprekinatLaukumu() un aprekinatPerimetru().
#Šeit redzams polimorfisms – lai gan katra forma ir cita klase, tās visas tiek apstrādātas vienād


formas = [Kvadrats(4), Taisnsturis(3, 5), Aplis(2)]
for forma in formas:
    print(f"Laukums: {forma.aprekinatLaukumu()}, Perimetrs: {forma.aprekinatPerimetru()}")