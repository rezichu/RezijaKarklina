class Blazes:
    def __init__(self,name,tekst):
        self.name = name
        self.tekst = tekst

    def familiar_blazes(self,house):
        try:
            if house == "yes":
                return "All around me are familiar Blazes, worn out Blazes, worn out Blazes- IS THAT WHAT A HOUSE LOOKS LIKE?! THIS PLACES IS AMAIZING, IS THIS THE FUTURE?... Worn out Blazes... I though I heard a cat."
            elif house == "no":
                return "All around me are familiar Blazes, worn out Blazes, worn out Blazes..."
            else:
                return "No familiar Blazes for you! >:["
        except ValueError:
            return "No familiar Blazes for you! >:["

meme = input("House yes or no?: ")
song = Blazes("Blaze",meme)

print(song.familiar_blazes(meme))