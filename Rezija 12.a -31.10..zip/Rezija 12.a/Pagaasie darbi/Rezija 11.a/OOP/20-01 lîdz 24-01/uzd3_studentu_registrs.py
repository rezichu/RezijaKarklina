class Students:
    def __init__(self):
        self.vards = ""
        self.uzvards = ""
        self.vecums = 0
        self.kursa_numurs = 0

    def parbaude(self):
        self.vards = input("Studenta vārds: ")
        self.uzvards = input("Studenta uzvārds: ")
        while True:
            try:
                self.vecums = int(input("Studenta vecums: "))
                if self.vecums <= 18:
                    print("Vecumam vaig būt mazākam par 18!")
            except ValueError:
                print("Ievadiet derīgu vecumu!")

    def izprintet(self):
        print(f"Izvade: \nStudents: {self.vards} {self.uzvards} \nVecums: {self.vecums} \nKurss: {self.kursa_numurs}. kurss")
