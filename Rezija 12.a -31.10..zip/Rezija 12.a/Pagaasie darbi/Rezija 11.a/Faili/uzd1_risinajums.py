#nolasīt csv faila saturu, aprēķināt vidējo vērtējumu
#pievienot jaunu lauku Vidējais, to viasu saglabā jaunā csv failā
import csv

ievades_dati = 'skoleni.csv'
izvades_dati = 'skoleni_videjais.csv'

with open(ievades_dati, "r", encoding='utf8') as file: #mainīgais fails tagad attēlo atvērto failu
    #nolasa csv failu un katru rindu pārvērš par vārdnīcu (kolonna:atslēga, 
    reader=csv.DictReader(file)
    skoleni = list(reader) #mainīgais skolēni ir python saraksts
    #katra saraksta elements ir 1 ieraksts no csv faila

#rēķinam vidējo un pievieno jaunu lauku
for skolens in skoleni:
    matemātika = int(skolens['Matemātika'])
    anglu_val = int(skolens['Angļu valoda'])
    biologija = int(skolens['Bioloģija'])
    videjais = round((matemātika+anglu_val+biologija)/3,2)
    #katram skolēna ierakstam tiek pievienots jauns lauks Vidējais
    skolens['Vidējais']=videjais

#saglabāt datus jaunā failā
with open(izvades_dati, "w", encoding='utf8', newline='') as file:
    fieldnames = skoleni[0].keys() #atgriež pirmās kolonnas(atslēgas nosaukumu)
    #objekts, kas raksta datus uz csv faila
    writer=csv.DictWriter(file, fieldnames=fieldnames) #rakstīs pareizā secībā
    #ieraksta pirmo rindu, kas ir kolonnu nosaukumi
    writer.writeheader() #ieraksta pirmo rindiņu, kas ir kolonnu nosaukumi
    writer.writerows(skoleni) #iziet cauri sarakstam un ieraksta katru, kā jaunu rindiņu

print(f"Jaunais fails ir saglabāts kā '{izvades_dati}'.")