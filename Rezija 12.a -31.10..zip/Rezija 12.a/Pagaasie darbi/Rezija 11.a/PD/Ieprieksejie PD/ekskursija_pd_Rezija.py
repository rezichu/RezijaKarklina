nosaukums = "ekskursija.txt"
with open(nosaukums, 'w', encoding='utf') as fails:
    fails.close

bil_kopa = []
laiks_kopa= []
def datu_iegusana():
        try:
            pieturu_sk = int(input('Ievadiet pieturu skaitu: '))
            for i in range(pieturu_sk):
                pieturas = input('Lūdzu ievadiet pieturas nosaukumu: ')
                transports = input(f'Ar kādu transporta veidu Jūs nokļūsiet uz {pieturas}? (vilciens/autobuss/pastaiga): ')
                if transports == 'vilciens':
                    bil_cena = float(input('Cik maksā biļete?: '))
                    bil_kopa.append(bil_cena)
                    cels = int(input('Cik km ir liels attālums līdz nākošai pieturai?(vesels skaitlis): '))
                    laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?(h/vesels skaitlis): '))
                    laiks_kopa.append(laiks)
                    with open(nosaukums, 'a', encoding='utf8') as fails:
                        fails.write(f"Pietura:{pieturas},Transporta veids:{transports},Biļetes cena:{bil_cena},Attālums:{cels},Laiks:{laiks}\n")
                elif transports == 'autobuss':
                    bil_cena = float(input('Cik maksā biļete?: '))
                    bil_kopa.append(bil_cena)
                    cels = int(input('Cik km ir liels attālums līdz nākošai pieturai?(vesels skaitlis): '))
                    laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?(h/vesels skaitlis): '))
                    laiks_kopa.append(laiks)
                    with open(nosaukums, 'a', encoding='utf8') as fails:
                        fails.write(f"Pietura:{pieturas},Transporta veids:{transports},Biļetes cena:{bil_cena},Attālums:{cels},Laiks:{laiks}\n")
                elif transports == 'pastaiga':
                    cels = int(input('Cik km ir liels attālums līdz nākošai pieturai?(vesels skaitlis): '))
                    laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?(h/vesels skaitlis): '))
                    laiks_kopa.append(laiks)
                    with open(nosaukums, 'a', encoding='utf8') as fails:
                        fails.write(f"Pietura:{pieturas},Transporta veids:{transports},Biļetes cena:{bil_cena},Attālums:{cels},Laiks:{laiks}\n")
                else:
                    print('Ievadiet pareizus datus!')
        except ValueError:
            print('Ievadiet pareizus datus!')

def datu_aprekinasana():
    izmaksas = sum(bil_kopa)
    kop_laiks = sum(laiks_kopa)
    print(f"Viena skolēna izmaksa ir {izmaksas} un ekskursijā kopēji pavadītais laiks ir {kop_laiks}.")
        
def datu_mainisana():
    with open(nosaukums, 'r', encoding='utf8') as fails:
        print(fails.readlines())
        mainit = input("Kurus datus jūs vēlaties mainīt?: ")
        data = fails.read()
        pieturas = input('Ievadiet jauno pieturas nosaukumu: ')
        transports = input('Ievadiet transporta veidu(vilciens, autobuss, pastaiga): ')
        if transports == 'vilciens':
            bil_cena = float(input('Cik maksā biļete?: '))
            bil_kopa.append(bil_cena)
            cels = int(input('Cik km ir liels attālums līdz nākošai pieturai?(vesels skaitlis): '))
            laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?(h/vesels skaitlis): '))
            laiks_kopa.append(laiks)
            mainit_datus = (f'Pietura : {pieturas}, Transporta veids : {transports}, Biļetes cena : {bil_cena}, Attālums : {cels}, Laiks : {laiks}\n')
            with open(nosaukums,'a',encoding='utf8')as fails:
                data = data.replace(mainit, mainit_datus)
                fails.write(data)
                    
        elif transports == 'autobuss':
            bil_cena = float(input('Cik maksā biļete?: '))
            bil_kopa.append(bil_cena)
            cels = int(input('Cik km ir liels attālums līdz nākošai pieturai?(vesels skaitlis): '))
            laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?(h/vesels skaitlis): '))
            laiks_kopa.append(laiks)
            mainit_datus = (f'Pietura : {pieturas}, Transporta veids : {transports}, Biļetes cena : {bil_cena}, Attālums : {cels}, Laiks : {laiks}\n')
            with open(nosaukums,'a',encoding='utf8')as fails:
                data = data.replace(mainit, mainit_datus)
                fails.write(data)
                    
        elif transports == 'pastaiga':
            cels = int(input('Cik km ir liels attālums līdz nākošai pieturai?(vesels skaitlis): '))
            laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?(h/vesels skaitlis): '))
            laiks_kopa.append(laiks)
            mainit_datus = (f'Pietura : {pieturas}, Transporta veids : {transports}, Attālums : {cels}, Laiks : {laiks}\n')
            with open(nosaukums,'a',encoding='utf8')as fails:
                data = data.replace(mainit, mainit_datus)
                fails.write(data)

def galvena():
    datu_iegusana()
    while True:
        try:
            izvele = input('Vai Jūs vēlaties mainīt savus datus?(jā/nē): ')
            if izvele == 'nē':
                datu_aprekinasana()
                exit()
            elif izvele == 'jā':
                datu_mainisana()
            else:
                    print('Ievadiet pareizus datus!')
        except ValueError:
            print('Ievadiet pareizus datus!')
galvena()