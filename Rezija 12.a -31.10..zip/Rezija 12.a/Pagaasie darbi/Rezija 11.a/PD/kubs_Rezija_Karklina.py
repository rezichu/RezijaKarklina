class Kubs: #klase Kubs
    def __init__(self,malas_garums,krasa): #konstruktors ar prasītajiem atribūtiem
        if malas_garums >= 10 or malas_garums <= 2:
            self.malas_garums = 2
        else:
            self.malas_garums = malas_garums
        self.krasa = krasa
        self.kuba_tilpums = 0

    def aprekinat_tilpumu(self): 
        self.kuba_tilpums = self.malas_garums*self.malas_garums*self.malas_garums

kubg = Kubs(10,"Zaļa")
kubg.aprekinat_tilpumu()
print(f"Dati par kubg objektu: \nKubg krāsa un tilpums: {kubg.krasa} {kubg.kuba_tilpums} \nKubg malas garums: {kubg.malas_garums} \n***")
kubr = Kubs(1,"Sarkana")
kubr.aprekinat_tilpumu()
print(f"Dati par kubg objektu: \nKubg krāsa un tilpums: {kubr.krasa} {kubr.kuba_tilpums} \nKubg malas garums: {kubr.malas_garums} \n***")


class Bloks(Kubs):
    def __init__(self,malas_garums,krasa,kubu_skaits,forma):
        super().__init__(malas_garums,krasa)
        if kubu_skaits > 4 and kubu_skaits < 1:
            self.kubu_skaits = 1
            self.pazinojums_skaits = "Nepareiza kubu skaita vērtība!"
        else:
            self.kubu_skaits = kubu_skaits
        self.nosaukums = krasa+str(kubu_skaits)
        if forma == 11 or forma == 12 or forma == 13 or forma == 14 or forma == 22:
            self.forma = forma
            self.derigums = 1
        else:
            self.forma = ""
            self.derigums = 0
            self.pazinojums_forma = "Forma neatbilst nosacījumiem!"
        self.kuba_tilpums = malas_garums*malas_garums*malas_garums*kubu_skaits

    def tilpums(self):
        pass

oranzs3 = Bloks(5,"Oranžs",3,13)
print(f"{oranzs3.krasa} objekts: \n{oranzs3.nosaukums} {oranzs3.kuba_tilpums} {oranzs3.derigums} \n***")

zils5 =Bloks(7,"Zils",5,23) #pārbauda vai istatītie
print(f"{zils5.krasa} objekts:")
if zils5.kubu_skaits > 4 and zils5.kubu_skaits < 1:
    print(zils5.pazinojums_skaits)
else:
    pass
if zils5.forma == 11 or zils5.forma == 12 or zils5.forma == 13 or zils5.forma == 14 or zils5.forma == 22:
    pass
else:
    print(zils5.pazinojums_forma)
if zils5.derigums == 1:
    derigums = "derīgs"
else:
    derigums = "nederīgs"
print(f"{zils5.nosaukums} {zils5.forma} {derigums} {zils5.derigums} \n***")

zils5.forma = 12
print(f"Nomainīta forma:")
print(f"{zils5.krasa} objekts:")
if zils5.kubu_skaits > 4 and zils5.kubu_skaits < 1:
    print(zils5.pazinojums_skaits)
else:
    pass
if zils5.forma == 11 or zils5.forma == 12 or zils5.forma == 13 or zils5.forma == 14 or zils5.forma == 22:
    pass
else:
    print(zils5.pazinojums_forma)
if zils5.derigums == 1:
    derigums = "derīgs"
else:
    derigums = "nederīgs"
print(f"{zils5.nosaukums} {zils5.forma} {derigums} {zils5.derigums} \n***")