'''30% atlaide
40% atlaide ar karti
20%, bet ar karti 50%
30% ja pērc 3+ preces
katra otrā prece pa brīvu'''