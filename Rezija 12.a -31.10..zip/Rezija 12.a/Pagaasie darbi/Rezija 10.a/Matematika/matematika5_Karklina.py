vards, uzvards = "Rēzija", "Kārkliņa"
print("Programmu izstrādāja:", vards, uzvards)
print('\t ')
print('Laukuma aprēķins ģeometriskām figūrām')
print('\t****')

a = int(input("Ievadiet malas A garumu: "))
print(a)
print('Malas A garums: ', float(a))
print('\t****')

b = int(input('Ievadiet malas B garumu: '))
print(b)
print('\t****')

ag = int(input('Ievadiet augstumu: '))
print('Augstums: ', float(ag))
print('Laukums trijstūrim: ', )
print('Laukums trapecei: ')
print('Laukums paralelogramam: ')
print('\t****')

print('Paldies!')