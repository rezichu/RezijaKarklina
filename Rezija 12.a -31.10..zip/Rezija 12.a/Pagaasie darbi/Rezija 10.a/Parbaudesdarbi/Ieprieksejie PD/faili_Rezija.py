def iegut_datus():
    dati = {}
    sk_vards = input('Ievadiet skolēna vārdu: ')
    sk_uzvards = input('Ievadiet skolēna uzvārdu: ')
    while True:
        prieksmets = input('Ievadiet mācību priekšmetu: ')
        if prieksmets == 'stop' or prieksmets == 'iziet':
            break
        elif prieksmets != 'stop' or prieksmets != 'iziet':
            continue
        atzime = int(input('Ievadiet skolēna atzīmi: '))
    

    dati[sk_vards] = sk_uzvards
    dati[prieksmets] = atzime

    with open('rezultati_Rezija.txt', 'w+', encoding='utf8') as fails:
        for sk_vards, prieksmets in dati.items():
            fails.write(f'{sk_vards}: {prieksmets}\n')


def sakartot_atzimes():
    print()
        

def ievadit_konsole():
    print()


def galvenais():
    atbilde = input("1 - Ievadīt informāciju \n2 - Sakārtot atzīmes augošā secībā \n3 - Izvadīt informāciju par atzīmēm konsolē \nLai izietu - teksts 'stop' vai 'iziet' \nKo jūs vēlētos darīt?: ")
    while True:
        if atbilde == '1':
            iegut_datus()
        elif atbilde == '2':
            sakartot_atzimes()
        elif atbilde == '3':
            ievadit_konsole()
        elif atbilde.lower() == 'stop' or 'iziet':
            break
        else:
            print('Šāda funkcija nav pieejama.')


try:
    print()
except ValueError:
    print('Nekorekta datu ievade.')
except FileNotFoundError:
    print('Fails neeksistē.')


galvenais()