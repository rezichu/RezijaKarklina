import math #Importē fukciju math, lai izrēķinātu faktoriāla lielumu

print('Faktoriāla aprēķināšana')
for i in range(55,56,1): #Izmanto for ciklu, lai izprintētu noteikta skaita zvaigznītes
    print(i*'*')

while True:
    skaitlis = int(input('Ievadiet veselu pozitīvu skaitli (mazāk par 13): ')) 
    if skaitlis < 13: #Pārbauda vai lietotājs ir ievadījis pareizo skaitli
        print('Faktoriāls: ', math.factorial(skaitlis))
    else:
        print('Ievadītais skaitlis ir pārā liels!')
    atbilde = input('Vai vēlaties turpināt? (j - jā, citi taustiņi - nē): ')
    if atbilde == 'j': #Pārbauda vai lietotājs vēlas turpināt vai beigt
        print('\n \n')
        continue
    else:
        print('\n \n')
        break

for i in range(10,11,1): #Izmanto for ciklu vēl vienreiz, lai izprintētu zvaigznītes
    print(i*'*')
print('Paldies!')