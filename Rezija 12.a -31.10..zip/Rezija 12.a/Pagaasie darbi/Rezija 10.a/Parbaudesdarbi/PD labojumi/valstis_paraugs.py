valstis = {
    'Latvija':1.884,
    'Igaunija':1.331,
    'Lietuva':2.801,
    'Zviedrija':10.420,
    'Somija':5.541,
    'Dānija':5.857,
    'Vācija':83.200,
    'Austrija':8.956,
    'Norvēģija':5.408,
    'Francija':67.750
}

#sākumā var izveidot sakārtotus sarakstus vēlākai izmantošanai
valstisAug = sorted(valstis, key = len)#pēc vārda garuma
valstisDil = sorted(valstis, key = len, reverse = True)
iedzivotajiAug = sorted(valstis, key = valstis.get)
iedzivotajiDil = sorted(valstis, key = valstis.get, reverse = True)

while True:
    print('Tavas iespējas: \n1 - valstis sakārtotas pēc nosaukuma augošā secībā \n2 - valstis sakārtotas pēc nosaukuma dilstošā secībā \n3 - valstis sakārtotas pēc iedzīvotāju skaita augošā secībā \n4 - valstis sakārtotas pēc iedzīvotāju skaita dilstošā secībā \n5 - pievienot jaunu valsti ar iedzīvotāju skaitu \n6 - apskatīt visas valstis')
    print("Ja vēlaties beigt, ievadiet 'stop'")
    print('---------------------------------------------------------------')
    izvele = input('Ko jūs vēlētos darīt?: ')
    if izvele == '1':
        print('Jūs izvēlējāties valstis sakārtot pēc nosaukuma augošā secībā.')
        for vertiba in valstisAug:
            print(vertiba, valstis[vertiba])
    elif izvele == '2':
        print('Jūs izvēlējāties valstis sakārtot pēc nosaukuma dilstošā secībā.')
        for vertiba in valstisDil:
            print(vertiba, valstis[vertiba])
    elif izvele == '3':
        print('Jūs izvēlējāties valstis sakārtot pēc iedzīvotāju skaita augošā secībā.')
        for atslega in iedzivotajiAug:
            print(atslega, valstis[atslega])
    elif izvele == '4':
        print('Jūs izvēlējāties valstis sakārtot pēc iedzīvotāju skaita dilstoša secībā.')
        for atslega in iedzivotajiDil:
            print(atslega, valstis[atslega])
    elif izvele == '5':
        jaunaValsts = input('Ievadiet valsts nosaukumu: ')
        if jaunaValsts == 'stop':
            print('Atā!')
            exit()

        jaunValstsIdz = input('Ievadiet valsts iedzīvotāju skaitu: ')
        if jaunValstsIdz == 'stop':
            print('Atā!')
            exit()

        valstis.update({jaunaValsts:jaunValstsIdz})
        print('\n\tVārdnīca + jaunais ieraksts')
        for vertiba in valstis:
            print(vertiba,valstis[vertiba])
    elif izvele == '6':
        print('\n\tVisas valstis:')
        for vertiba in valstis:
            print(vertiba, valstis[vertiba])
    elif izvele == 'stop':
        print('Atā!')
        exit()
    else:
        print('Ievadiet pareizos datus!')