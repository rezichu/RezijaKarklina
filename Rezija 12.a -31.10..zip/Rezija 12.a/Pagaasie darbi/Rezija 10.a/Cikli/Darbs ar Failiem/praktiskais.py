#uzrakstīt programmu, kas lasa katru rindiņu un sadala to vārdos ༼ つ ◕_◕ ༽つ
#prgramma pārbauda vai ir pietiekams datu skaits, lai izvadītu informāciju un pēc tam izvada datus uz ekrāna
#Vārds, uzvārds, vecums

#1 - izveidot savā mapē failu dati.txt
#faila nosaukums
faila_nosaukums = 'prakstiskais.txt'

#2 - atvērt failu un lasīt datus
try:
    with open(faila_nosaukums, 'r', encoding='utf-8') as fails:

#3 - katru rindu sadala pa vārdiem, izmantojot atstarpes kā atdalītājus
        for rindina in fails:
            dati = rindina.split()

#4 - pārbaudīt vai ir pietiekams datu skaits(vārds, uzvārds, vecums)
            if len(dati) >= 3:
                vards = dati[0]
                uzvards = dati[1]
                vecums = dati[2]
#5 = parādīt datus uz ekrāna
                print(f"Vārds:{vards}, Uzvārds:{uzvards}, Vecums{vecums}")
            else:
                print("Kļūda: Faila nepietiek datu.")

except FileNotFoundError:
    print(f'Kļūda: Fails',{faila_nosaukums},'nav atrasts')
except Exception as e:
    print(f'Kļūda: Neparedzēta kļūda = {e}')