#Darbu sāk no fukcijas saglabat_recepti(), kas ļauj ievadīt nosaukumu, kalorijas saturu
#Saglabā šo datus failā 'receptes.txt'
#Funkcija paradi_recepti() atver failu un izvada visu recepšu nosaukumus
#Funkcija paradit_visas_receptes() parādīs receptes un kalorijas

def saglabat_recepti():
    receptes = {}
    while True:
        nosaukums = input('Ievadiet receptes nosaukumu (iziet, lai pārtrauktu): ')
        if nosaukums.lower() == 'iziet':
            break
        kalorijas = float(input('Ievadiet kaloriju daudzumu: '))
        receptes[nosaukums] = kalorijas

    with open('receptes.txt', 'w', encoding='utf8') as fails:
        for nosaukums, kalorijas in receptes.items():
            fails.write(f'{nosaukums}: {kalorijas}\n')
    

def paradit_visas_receptes():
    try:
        with open('receptes.txt', 'r', encoding='utf8') as fails:
            print('Pieejamās receptes: ')
            for rinda in fails:
                nosaukums, kalorijas = rinda.strip().split(': ')
                print(f'{nosaukums}-{kalorijas} kcal.')
    except FileNotFoundError:
        print('Nav pieejamu recepšu. Lūdzu, papildiniet failu.')

#Parādīs vienu konkrētu recepti
def paradi_recepti():
    try:
        with open('receptes.txt', 'r', encoding='utf8') as fails:
            receptes = {}
            for rinda in fails:
                nosaukums, kalorijas = rinda.strip().split(': ')
                receptes[nosaukums] = float(kalorijas)
            print('Pieejamās receptes: ')
            #Izdrukā pieejamo recepšu nosaukumu
            for nosaukums in receptes:
                print(nosaukums)
            izvele = input('Izvēlieties recepti (varēs redzēt kalorijas): ')
            if izvele in receptes:
                print(f'{izvele} kaloriju saturs: {receptes[izvele]} kcal.')
            else:
                print('Recepte nav atrasta.')
    except FileNotFoundError:
        print('Nav pieejamu recepšu. Lūdzu, papildiniet failu.')


def galvenais():
    print('Šī ir DIY recepšu programma.')
    while True:
        darbiba = input('1 - Saglabāt receptes \n2 - Redzēt visas receptes \n3 - Sīkāka informācija par recepti \nq - Iziet \nIevadiet jūsu izvēli: ')
        if darbiba == '1':
            saglabat_recepti()
        elif darbiba == '2':
            paradit_visas_receptes()
        elif darbiba == '3':
            paradi_recepti()
        elif darbiba.lower() == 'q':
            break
        else:
            print('Nepareiza ievade. Jāievada darbība no saraksta.')

galvenais()