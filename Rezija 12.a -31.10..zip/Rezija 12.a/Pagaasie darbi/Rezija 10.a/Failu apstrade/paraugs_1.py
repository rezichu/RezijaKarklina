#Prasīt ievadīt datus līdz brīdim, kamēr ievada tukšu rindu
#Datus saglabāt failā
dati = []
while True:
    ievades_dati = input('Ievadiet datus (iziet, lai izietu) Enter, lai beigtu :')
    if ievades_dati.lower() == 'iziet':
        print('Programma pārtraukta pēc jūsu lūguma.')
        break
    #pārtrauc ciklu, ja ievada tukšu rindu (Enter)
    elif not ievades_dati:
        break
    dati.append(ievades_dati)

    #Atvērt failu, lai ierakstītu datus
    with open('jaunais_fails.txt','w', encoding='utf-8') as fails:
        #
        for line in dati:
            dati.write(line + '\n')
        print('Dati ir ierakstīti jaunajā failā.')
