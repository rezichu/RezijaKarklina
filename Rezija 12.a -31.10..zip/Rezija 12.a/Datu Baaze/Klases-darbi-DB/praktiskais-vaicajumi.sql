DROP TABLE IF EXISTS atzimes;
DROP TABLE IF EXISTS studentu_kursi;
DROP TABLE IF EXISTS kursi;
DROP TABLE IF EXISTS studenti;

-- studenti - galbāt studentu pamatinformāciju
CREATE TABLE IF NOT EXISTS studenti(
    studenti_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards TEXT NOT NULL,
    uzvards TEXT NOT NULL,
    epasts NOT NULL UNIQUE CHECK (epasts LIKE '%@%')
);

CREATE TABLE IF NOT EXISTS kursi(
    kurss_id INTEGER PRIMARY KEY AUTOINCREMENT,
    nosaukums TEXT NOT NULL UNIQUE,
    apraksts TEXT DEFAULT 'Nav apraksta'
);

CREATE TABLE IF NOT EXISTS studentu_kursi(
    studentu_kursu_id INTEGER PRIMARY KEY AUTOINCREMENT,
    studenti_id INTEGER NOT NULL, --norāda uz tabulu studenti
    kurss_id INTEGER NOT NULL, --norāda uz tabulu kursi
    UNIQUE(studenti_id,kurss_id), --viens students nevar būt divreiz pierakstīts tajā pašā kursā
    FOREIGN KEY(studenti_id) REFERENCES studenti(studenti_id) ON DELETE CASCADE,
    --ja izdzēš studentu vai kursu, tad attiecīgi pierakstus dzēš automātiski
    FOREIGN KEY(kurss_id) REFERENCES kursi(kurss_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS atzimes(
    atzime_id INTEGER PRIMARY KEY AUTOINCREMENT,
    studenti_id INTEGER NOT NULL,
    kurss_id INTEGER NOT NULL,
    atzime INTEGER NOT NULL CHECK(atzime BETWEEN 1 AND 10), --atzīme no 1-10
    FOREIGN KEY(studenti_id) REFERENCES studenti(studenti_id) ON DELETE CASCADE,
    FOREIGN KEY(kurss_id) REFERENCES kursi(kurss_id) ON DELETE CASCADE,
    --kombinācija studenti_id un kurss_id nevar atkārtoties
    UNIQUE(studenti_id,kurss_id)
);

--studentu pievienošana
INSERT INTO studenti(vards,uzvards,epasts) VALUES
    ('Marija','Liepa','marija.liepa213@inbox.lv'),
    ('Mārcis','Liepa','marcis.liepa213@inbox.lv'),
    ('Gunārs','Ozols','gunars_ozols@gmail.com'),
    ('Baiba','Gulbe','gulbe_bai@inbox.lv');

INSERT INTO kursi(nosaukums,apraksts) VALUES
    ('Matemātika','Algebra is svarīga'),
    ('Programmēšana','Besis, jo atkal kaut kas nestrādā'),
    ('Fizika','Mašīna pēkšņi iet -100km/h'),
    ('Ķīmija','Ooops');

INSERT OR IGNORE INTO studentu_kursi(studenti_id,kurss_id) VALUES
    (1,3), (1,1), (1,4), --Marija
    (2,1), (2,3), (2,2), --Mārcis
    (3,1), (3,2), (3,3), -- Gunārs
    (4,4), (4,3), (4,2); --Baiba

INSERT INTO atzimes(studenti_id,kurss_id,atzime) VALUES
    (1,3,7),
    (1,1,10),
    (1,4,8),
    (2,1,8),
    (2,3,6),
    (2,2,10),
    (3,1,5),
    (3,2,6),
    (3,3,4),
    (4,4,9),
    (4,3,7),
    (4,2,7);


--visus studentus parādīt dilstošā secībā pēc uzvārda
SELECT*FROM studenti ORDER BY uzvards DESC;

--parādīt visus kursus un studentus, kas tajos pierakstīti
SELECT
    kursi.nosaukums AS Kursa_nosaukums,
    studenti.vards || ' ' || studenti.uzvards AS Students
FROM kursi
JOIN studentu_kursi ON kursi.kurss_id=studentu_kursi.kurss_id
JOIN studenti ON studentu_kursi.studenti_id=studenti.studenti_id
ORDER BY kursi.nosaukums;

--saskaitīt, cik studentu ir katrā kursā(parādīt studentu skaitu un kursa nosaukumu)
SELECT
    kursi.nosaukums AS Kursa_nosakumus,
    COUNT(studentu_kursi.studenti_id) AS Studentu_skaits
FROM kursi
LEFT JOIN studentu_kursi ON kursi.kurss_id=studentu_kursi.kurss_id
GROUP BY kursi.nosaukums;


--katram kursam parādīt vidējo atzīmi un studentu skaitu (kursa nosaukums atzīme skaits)
--SELECT
    --kursi.nosaukums AS Kursa_nosaukums,
    --ROUND(AVG(atzimes.atzime),2) AS Kursa_vidējā_atzīme,
    --COUNT(studentu_kursi.studenti_id) AS Studentu_skaits
--FROM studentu_kursi
--JOIN atzimes ON studentu_kursi.studenti_id=atzimes.studenti_id
--LEFT JOIN kursi ON studentu_kursi.kurss_id=kursi.kurss_id
--GROUP BY kursi.nosaukums;

SELECT
    kursi.nosaukums AS Kursa_nosaukums,
    COUNT(atzimes.studenti_id) AS Studentu_skaits,
    ROUND(AVG(atzimes.atzime),2) AS Vidējā_atzime
FROM kursi
LEFT JOIN atzimes ON kursi.kurss_id=atzimes.kurss_id
GROUP BY kursi.nosaukums;

--parādīt katra studenta vidējo atzīmi(vārds, atzīme)
SELECT
    studenti.vards || ' ' || studenti.uzvards AS Studenta_vārds,
    ROUND(AVG(atzimes.atzime),2) AS Vidējā_atzime
FROM studenti
LEFT JOIN atzimes ON studenti.studenti_id=atzimes.studenti_id
GROUP BY kursi.nosaukums;