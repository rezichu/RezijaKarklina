DROP TABLE IF EXISTS kafejnicas;
DROP TABLE IF EXISTS darbinieka;
DROP TABLE IF EXISTS pasutijumi;

CREATE TABLE IF NOT EXISTS kafejnicas(
        kafejnica_id INTEGER PRIMARY KEY AUTOINCREMENT,
        nosaukums TEXT NOT NULL,
        adrese TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS darbinieki(
        darbinieka_id INTEGER PRIMARY KEY AUTOINCREMENT,
        vards TEXT NOT NULL,
        uzvards TEXT NOT NULL,
        talrunis INTEGER NOT NULL,
        amats TEXT NOT NULL,
        atvalinajuma TEXT NOT NULL,
        FOREIGN KEY (kafejnica_id) REFERENCES kafejnicas.kafejnica_id
);

CREATE TABLE IF NOT EXISTS pasutijumi(
        pasutijuma_id INTEGER PRIMARY KEY AUTOINCREMENT,
        summa REAL NOT NULL,
        datums TEXT NOT NULL,
        apraksts TEXT NOT NULL,
        FOREIGN KEY (darbinieka_id) REFERENCES darbinieki.darbinieka_id
);

INSERT INTO kafejnicas (nosaukums, adrese) VALUES
('Pie Jāņa', 'Brīvības iela 10'),
('Zelta Tase', 'Lāčplēša iela 22'),
('Kafijas Stūrītis', 'Valdemāra iela 15'),
('Siltie Rīti', 'Kr. Barona iela 5'),
('Rīta Prieks', 'Elizabetes iela 30');

INSERT INTO darbinieki (vards, uzvards, talrunis, amats, atvalinajuma, kafejnica_id) VALUES
('Jānis', 'Bērziņš', '+37120000000', 'viesmīlis', 'Jā', 1),
('Anna', 'Kalniņa', '+37121234567', 'barista', 'Nē', 1),
('Pēteris', 'Ozols', '+37122334455', 'viesmīlis', 'Nē', 2),
('Laura', 'Liepa', '+37121112222', 'vadītāja', 'Nē', 3),
('Mārtiņš', 'Vilks', '+37123456789', 'viesmīlis', 'Jā', 4);

INSERT INTO pasutijumi (summa, datums, apraksts, darbinieka_id) VALUES
(249.99, '2024-04-01', 'Produkti atvēršanai', 1),
(89.50, '2024-04-03', 'Kafijas pupiņas', 2),
(120.00, '2024-04-04', 'Krūzītes un šķīvji', 3),
(310.40, '2024-04-05', 'Virtuves piederumi', 4),
(99.99, '2024-04-06', 'Deserti', 2),
(45.00, '2024-04-07', 'Papīra maisiņi', 5);

--2.1. Darbinieki, kas ir atvaļinājumā
SELECT 
    vards || ' ' || uzvards AS Darbinieki_atvalinajuma
FROM darbinieki
WHERE atvalinajuma = 'Jā';

--2.2. Pasūtijumu kopējais skaits
SELECT 
    COUNT(pasutijuma_id) AS Pasutijumu_skaits
FROM pasutijumi;

--2.3. Cik pasutījumi ir katram darbiniekam
SELECT
    darbinieki.vards || ' ' || darbinieki.uzvards AS Darbinieks,
    COUNT(pasutijumi.darbinieka_id) AS Darbinieka_pasutijumu_sk
FROM darbinieki
LEFT JOIN pasutijumi ON darbinieki.darbinieka_id=pasutijumi.darbinieka_id
GROUP BY darbinieki.vards;

--2.4. Katra darbinieka vislielākā summa
SELECT
    darbinieki.vards || ' ' || darbinieki.uzvards AS Darbinieks,
    MAX(pasutijumi.summa) AS Pasutijuma_lielaka_summa
FROM darbinieki
JOIN pasutijumi ON darbinieki.darbinieka_id=pasutijumi.darbinieka_id
GROUP BY darbinieki.darbinieka_id;

--2.5. Katras kafejnīcas pasūtijuma vidējā summa
SELECT
    kafejnicas.nosaukums AS Kafejnicas_nosaukums,
    ROUND(AVG(pasutijumi.summa),2) AS Videja_summa
FROM darbinieki
JOIN kafejnicas ON darbinieki.kafejnica_id=kafejnicas.kafejnica_id
JOIN pasutijumi ON darbinieki.darbinieka_id=pasutijumi.darbinieka_id
GROUP BY kafejnicas.kafejnica_id;

--2.6. Parāda visus darbiniekus, kas ir viesmīļi
SELECT
    vards || ' ' || uzvards AS Darbinieks,
    amats AS Darbinieka_amats
FROM darbinieki
WHERE amats='viesmīlis';

--2.7. Parāda visus pasūtījumus, kuru summa ir lielāka par 100 (parāda vēl summu un datumu)
SELECT
    pasutijuma_id AS Pasutijuma_id,
    summa AS Pasutijuma_summa,
    datums AS Pasutijuma_datums
FROM pasutijumi
WHERE summa>=100;

--2.8. Kafejnīca ar visvairāk pasūtijumiem, kas ir jākārto dilstoši
SELECT
    kafejnicas.nosaukums AS Kafejnicas_nosaukums,
    COUNT(pasutijumi.pasutijuma_id) AS Pasutijumu_skaits
FROM darbinieki
JOIN kafejnicas ON darbinieki.kafejnica_id=kafejnicas.kafejnica_id
JOIN pasutijumi ON darbinieki.darbinieka_id=pasutijumi.darbinieka_id
GROUP BY kafejnicas.kafejnica_id
ORDER BY Pasutijumu_skaits DESC;


--2.9. Parāda katra darbinieka pasūtijumu kopsummu
SELECT
    darbinieki.vards || ' ' || uzvards AS Darbinieks,
    SUM(pasutijumi.summa) AS Kopsumma
FROM darbinieki
JOIN pasutijumi ON darbinieki.darbinieka_id=pasutijumi.darbinieka_id
GROUP BY darbinieki.darbinieka_id;

--2.10. Darbinieki, kuri veikuši vizmaz 2 piegādes
SELECT
    darbinieki.vards || ' ' || uzvards AS Darbinieks,
    COUNT(pasutijumi.pasutijuma_id) AS Pasutijumu_skaits
FROM darbinieki
JOIN pasutijumi ON darbinieki.darbinieka_id=pasutijumi.darbinieka_id
GROUP BY darbinieki.darbinieka_id
HAVING COUNT(pasutijumi.pasutijuma_id)>=2;