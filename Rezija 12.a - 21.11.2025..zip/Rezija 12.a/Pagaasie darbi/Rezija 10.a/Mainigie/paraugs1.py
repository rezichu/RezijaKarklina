'''mainīgo tipu pārveidošana,
datu tipu iegūšana no literāļa,
konkatenācija'''

name = 'Anna'
teksts = "teksts"
skaitlis = 9 #int tips
print(name)
kombo = name, teksts #mainīgo apvienošana
print(kombo)

varda_garums = len(teksts)
print('Mainīga garums:',varda_garums)

a = b = c = 300 #chained_assigmnet = kaskādes ve
print(a,b,c)

x, y = 10, 'hello'
print(x, y)