def atnemsana(): #funkcijai netiek nodoti parametri
    print(34-4)

print('Sveka, ziema!')
atnemsana() #funkcijas atnemsana() pie izsaukšanas ievada  rezultātu 30
print('-------------------------')

#funkcijai 'plus' tiek padoti 2 parametri
#konsolei jāparāda summa
#funkciju izsauc, norādot šīs 2 vērtības

def plus(num1, num2):
    print(num1 + num2)

plus(4,5)
print('-------------------------')

#nodefinē funkciju reizinat(), iedodot parametru num1
def reizinat(num1):
    return num1 * 8
rez = reizinat(8)
print(rez)
print('-------------------------')

#izsauc funkciju, nodot skaitli 8 kā argumentu num1 un
#funkcijas izsauksmes