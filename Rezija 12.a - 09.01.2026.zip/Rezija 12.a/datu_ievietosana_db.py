import flet as ft
import sqlite3

def main(page:ft.Page):
    page.title="TV šovi:datubāze"

    #savienojums ar datubāzi
    savienojums=sqlite3.connect("testa_dati_tv_sovi.db")
    cursor=savienojums.cursor()

    #teksts statusam(vai visi dati )
    statuss=ft.Text("Te būs statusa dati")

    #lauki datu ievadei
    lauks_nosaukums=ft.TextField(label="Nosaukums")
    lauks_kanals=ft.TextField(label="Kanāls")
    lauks_zanrs=ft.TextField(label="Žanrs")
    lauks_gads=ft.TextField(label="Gads")

    #dropdown dati
    dd_dalibnieks=ft.Dropdown(label="Izvēlies darbinieku")
    dd_sovs=ft.Dropdown(label="Izvēlies šovu")
    lauks_loma=ft.TextField(label="loma(vadītājs/dalībnieks/žūrija)")

    def ieladet_dropdown():
        #dalībnieki:id+vārds,uzvārds,profesija
        cursor.execute(
            """SELECT sovu_dalibnieki_id,vards,uzvards,profesija
            FROM sovu_dalibnieki
            ORDER BY uzvards,vards"""
        )
        dal_fetchall=cursor.fetchall()
        dd_dalibnieks.options=[
            ft.dropdown.Option(
            key=str(r[0]),
            text=f"{r[1]}({r[2]},{r[3]})"
            )
            for r in dal_fetchall
        ]

        #šovu dati dropdownam: id+nosaukums(kanāls,gads)
        cursor.execute(
            """SELECT televizijas_sovi_id,nosaukums,kanals,gads
            FROM televizijas_sovi
            ORDER BY nosaukums"""
        )
        sovi=cursor.fetchall()
        options=[]
        for r in sovi:
            options.append(
                ft.dropdown.Option(
                key=str(r[0]),
                text=f"{r[1]}({r[2]},{r[3]})"
                )
        )
        dd_sovs.options=options
        page.update()
    #lai dropdown uzreiz 
    ieladet_dropdown()
        
    def saglabat_dalibu(_):
        dal_id=dd_dalibnieks.value
        sova_id=dd_sovs.value
        loma=lauks_loma.value.strip()

        if dal_id is None or sova_id is None or loma=="":
            statuss.value="Jāaizpilda visi lauki!"
            page.update()
            return

        cursor.execute(
            """INSERT INTO sovu_dalibas(sovu_dalibnieki_id,televizijas_sovi_id,loma) 
            VALUES(?,?,?)""",
            (int(dal_id),int(sova_id),loma)
        )
        savienojums.commit()
        statuss.value="Dalība pievienota!"
        lauks_loma.value=""
        page.update()

    def saglabat(_): #nolasa ievadītās vērtības
        nosaukums=lauks_nosaukums.value.strip()
        kanals=lauks_nosaukums.value.strip()
        zanrs=lauks_nosaukums.value.strip()
        gads_txt=lauks_nosaukums.value.strip()

        if "" in [nosaukums,kanals,zanrs,gads_txt]:
            statuss.value="Kļūdas: aizpildi visus laukus!"
        else:
            cursor.execute(
                """INSERT INTO televizijas_sovi(nosaukums,kanals,zanrs,gads) VALUES(?,?,?,?)""",
                (nosaukums,kanals,zanrs,gads_txt)
            )
            savienojums.commit()
            statuss.value="Dati pievienoti!"

            #jānotīra ievades lauki
            lauks_nosaukums.value=""
            lauks_kanals.value=""
            lauks_zanrs.value=""
            lauks_gads.value=""

        page.update()
    poga=ft.ElevatedButton("Saglabāt datus",on_click=saglabat,color="pink")

    lauks_vards=ft.TextField(label="Dalībnieka vārds")
    lauks_uzvards=ft.TextField(label="Dalībnieka uzvārds")
    lauks_profesija=ft.TextField(label="Dalībnieka profesija")

    def saglabat_dabilb(_):
        vards=lauks_vards.value.strip()
        uzvards=lauks_uzvards.value.strip()
        profesija=lauks_profesija.value.strip()
        if "" in [vards,uzvards,profesija]:
            statuss.value="Kļūdas: aizpildi visus laukus!"
        else:
            cursor.execute(
                """INSERT INTO sovu_dalibnieki(vards,uzvards,profesija) VALUES(?,?,?)""",
                (vards,uzvards,profesija)
            )
            savienojums.commit()
            statuss.value="Dati pievienoti!"

            lauks_vards.value=""
            lauks_uzvards.value=""
            lauks_profesija.value=""

        page.update()
    poga2=ft.ElevatedButton("Saglabāt datus",on_click=saglabat_dabilb,color="pink")
    poga_daliba=ft.ElevatedButton("Saglabāt dalību", on_click=saglabat_dalibu,color="pink")

    page.add(ft.Text("Šova pievienošana"),
             lauks_nosaukums,
             lauks_kanals,
             lauks_zanrs,
             lauks_gads,
             poga,
             ft.Text("Dalībnieka pievienošana"),
             lauks_vards,
             lauks_uzvards,
             lauks_profesija,
             poga2,
             ft.Text("Dalības pievienošana"),
             dd_dalibnieks,
             dd_sovs,
             lauks_loma,
             poga_daliba,
             statuss)

ft.app(target=main)