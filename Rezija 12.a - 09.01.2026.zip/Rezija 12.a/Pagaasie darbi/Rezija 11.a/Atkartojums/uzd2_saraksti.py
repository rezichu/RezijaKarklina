'''edieni = ['ābols', 'cepums', 'čipsi']
print(edieni)

print(edieni[1]) #otrais elements pēc kārtas

print(edieni[::-1]) #apgriezta secība

#izveidot sarakstu ar for ciklu, lai elementi būt
lielie_burti = []
for ediens in edieni:
    lielie_burti.append(ediens.capitalize()) #upper visi lielie burti
print(lielie_burti)'''

burti = ['A',  'B', 'C', 'D', 'E', 'F', 'G']
print(len(burti))


#Pēdējais saraksta elements
print(burti[-1])

#konkrēti elementi no saraksta
konkreti = burti[3:6]
print(konkreti)