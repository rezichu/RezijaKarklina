pieturas = []
dati = {}

def iegut_datus():
    try:
        while True:
            marsrutu_sk = int(input('Ievadiet pieturu skaitu: '))
            for a in range(marsrutu_sk):
                marsruts = input('Ievadiet pieturas nosaukumu: ')
                pieturas.append(marsruts)
                transports = input('Ar kādu maršruta veidu Jūs nokļūsiet uz nākošo pieturu?(vilciens/autobuss/pastaiga): ')
                if transports == 'pastaiga':
                    attalums = int(input('Cik km ir liels attālums līdz nākošai pieturai?(km): '))
                    laiks = int(input('Cik ilgi Jūs pavadīsiet ejot uz nākamo pieturu?(h): '))
                    dati[marsruts] = attalums, laiks
                    with open('ekskursija.txt','w', encoding='utf-8') as fails:
                        fails.write(f'{marsruts} : {attalums} : {laiks}')
                elif transports == 'vilciens':
                    bil_cena = input('Cik maksā biļete?(EUR): ')
                    attalums = int(input('Cik km ir liels attālums līdz nākošai pieturai?(km): '))
                    laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?(h): '))
                    dati[marsruts] = attalums, laiks, bil_cena
                    with open('ekskursija.txt','w', encoding='utf-8') as fails:
                        fails.write(f'{marsruts} : {attalums}km : {laiks}h : {bil_cena}EUR')
                elif transports == 'autobuss':
                    bil_cena = input('Cik maksā biļete?(EUR): ')
                    attalums = int(input('Cik km ir liels attālums līdz nākošai pieturai?(km): '))
                    laiks = int(input('Cik ilgi Jūs pavadīsiet braucot uz nākamo pieturu?: '))
                    dati[marsruts] = attalums, laiks, bil_cena
                    with open('ekskursija.txt','w', encoding='utf-8') as fails:
                        fails.write(f'{marsruts} : {attalums} : {laiks} : {bil_cena}')
    except ValueError:
        print('Lūdzu ievadiet pareizos datus!')

def datu_aprekins(sk_skolenu):
    print()

def galvena():
    while True:
        iegut_datus()
        try:
            sk_skolenu = int('Cik skolēnu piedalas ekskursijā?: ')
        except ValueError:
            print('Lūdzu ievadiet pareizos datus!')
        datu_aprekins()

galvena()