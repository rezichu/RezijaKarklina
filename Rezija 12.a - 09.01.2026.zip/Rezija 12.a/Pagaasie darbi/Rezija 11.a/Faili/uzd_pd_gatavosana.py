import csv
#uzd1 - ierakastīt tekstu .txt failā ar input metodi, failu izveidot programmu

'''faila_nos = "skola"

print('Ievadiet stop, lai pārtrauktu programmu.')
while True:
    skolens_v = input('Ievadiet skolēna vārdu: ')
    if skolens_v == 'stop':
        break
    

    with open(faila_nos, 'w', encoding='utf8') as fails:
        fails.write(f"Vārds:{skolens_v}\n")
        fails.close

#uzd2 - nolasīt tekstu no faila. Ja nav atrasts fails informē

try:
    with open(faila_nos, 'r', encoding='utf8') as fails:
        fails.read()
        fails.close
except FileNotFoundError:
    print(f"Brīdinājums: Fails {faila_nos} neeksistē!")'''


def ierakstit_faila():
    with open("fails.txt","w",encoding='utf8') as fails:
        for i in range(1,7):
            vards = input(f"Ievadi {i}. vārdu: ")
            fails.write(vards+"\n")
    print("Informācija saglabāta!")  
#ierakstit_faila()

'''def nolasit_no_faila():
    try:
        with open("fails.txt","r",encoding='utf8') as fails:
            saturs = fails.read'''

def nolasit_ar_for():
    try:
        with open("fails.txt","r",encoding='utf8') as fails:
            print("\nFaila saturs: ")
            for i in fails:
                print(i.strip())
    except FileNotFoundError:
        print("Fails nav atrasts!")
#nolasit_ar_for()


#izveidot programmu ar 3 vārdiem
#pievienot to sarakstu failiem
#pārādīt konsolē cik vārdi pievienoti

def uzdevums3():
    try:
        vardi = {"Ābols","Liepa","Karote"}
        with open("vardi.txt","w",encoding='utf8', newline='')as fails:
            fails.write(vardi)
        print("Dodtie vārdi ir saglabāti failā!")
    except FileNotFoundError:
        print("Fails neeksistē!")
#uzdevums3()

def vardi_manuali():
    jauni_vardi = ["Māja","Kaķis","Cālis"]
    try:
        with open("fails.txt","w",encoding='utf8')as fails:
            for i in jauni_vardi:
                fails.write(i+"\n")
            print(f"{len(jauni_vardi)} jauni vārdi pievienoti.")
    except FileNotFoundError:
        print("Fails nav atrasts!")
#vardi_manuali()

#ievadīt vārdu, ko meklē failā un informē vai tāds ir

def vai_vards_ir():
    try:
        with open("fails.txt","r",encoding='utf8')as fails:
            vards = input("Ievadiet vārdu ko meklē: ")
            for i in fails:
                if vards == i:
                    print("Vārds ir failā!")
            print("Failā nav vārda!")
    except FileNotFoundError:
        print("Fails nav atrasts!")
#vai_vards_ir()

def meklet_vardu():
    vards = input("Ievadi vārdu, ko meklē: ")
    try:
        with open("fails.txt",'w',encoding='utf8')as fails:
            saturs = fails.read()
        if vards in saturs:
            print(f"Vārds {vards} ir atrasts.")
        else:
            print(f"Vārds {vards} nav atrasts.")
    except FileNotFoundError:
        print("Fails nav atrasts!")
#meklet_vardu()

#sakārtot vārdus failā, dilstošā secībā

def sakartot_vardus():
    try:
        with open("fails.txt","r",encoding='utf8')as fails:
            saturs = fails.readlines()
        kartot = sorted(saturs,reverse=True)
        #ieraksta atpakaļ failā
        with open("fails.txt","w",econding='utf8')as fails:
            fails.writelines(kartot)
        print("Vārdi sakārtoti dilstošā secībā.")
    except FileNotFoundError:
        print("Fails nav atrasts!")
#sakartot_vardus()




#funkcija, kas izveido csv failu un ieraksta 3 rindas
def csv_fails():
    with open("fails.csv","w",encoding='utf8',newline='')as fails:
        writer = csv.writer(fails)
        writer.writerow(["ID","Name","Age"])
        writer.writerows([[1,"Alise",25],[2,"Pauls",21],[3,"Marta",32]])
    print("Fails ir izveidots.")
csv_fails()

#parādīt csv faila saturu
def csv_saturs():
    try:
        with open("fails.csv","r",newline='',encoding='utf8')as fails:
            reader = csv.reader(fails)
            for rinda in reader:
                print(*rinda)
    except FileNotFoundError:
        print("Fails nav atrasts!")
#csv_saturs()

#pievienot jaunu ID, vārdu, vecumu ar input

def pievienot_jaunu():
    try:
        with open("fails.csv","a",newline='',encoding='utf8')as fails:
            writer = csv.writer(fails)
            id = input("ID: ")
            vards = input("Vārds: ")
            vecums = input("Vecums: ")
            writer.writerows([[id,vards,vecums]])
        print("Fails ir izveidots!")
    except FileNotFoundError:
        print("Fails nav atrasts!")
#pievienot_jaunu()