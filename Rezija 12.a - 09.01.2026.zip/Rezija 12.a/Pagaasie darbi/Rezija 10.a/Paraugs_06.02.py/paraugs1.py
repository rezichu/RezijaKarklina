import sys
def nolasit_failu(failins):
    try:
        with open(failins, 'r', encoding = 'utf8') as file:
            saturs = file.read()
            return saturs
    except FileNotFoundError as e:
        print(f"Fails '{failins}' nav atrasts", file = sys.stderr)

#funkcija, kas saskaita simbolu failā
def saskaitit(saturs):
    return len(saturs)

#funkcija, kas parāda pirmo un pēdējo simbolu
def pirmais_un_pedejais(saturs):
    return saturs[0], saturs[-1]

def lasit_simbols(failins,garums):
    try:
        with open(failins, 'r', encoding = 'utf8') as file:
            saturs = file.read(int(garums))
            return saturs
    except FileNotFoundError as e:
        print(f"Fails '{failins}' nav atrasts", file = sys.stderr)
    except ValueError:
        return "'Garums' jābūt skaitlim."

#Funkcija, kas nolasa pirmo rindiņu no faila satura
    
def nolasit_pirmo(failins):
    try:
        with open(failins, 'r', encoding = 'utf8') as file:
            pirma_rinda = file.readline()
            print(pirma_rinda)
    except FileNotFoundError:
        print(f"Fails '{failins}' nav atrasts", file = sys.stderr)

failins = input('Lūdzu, ievadiet faila nosaukumu: ')
saturs = nolasit_failu(failins)

if saturs:
    print('1)Simbolu skaitu: ', saskaitit(saturs))
    print('2)Pirmais un pēdējais simbols: ', pirmais_un_pedejais(saturs))

    garums = input('Lūdzu, ievadiet garumu: ')
    print('3)Simboli no sākuma līdz garumam: ', lasit_simbols(failins,garums))

    print('\nPirmā rinda: ')
    nolasit_pirmo(failins)