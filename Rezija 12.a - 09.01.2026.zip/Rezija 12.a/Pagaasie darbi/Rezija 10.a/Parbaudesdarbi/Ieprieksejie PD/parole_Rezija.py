lietvards = 'pavasaris' #mainīgais lietvārds un parole
parole = 'roze' 
parbparole = len(parole)

for i in range(1,6): #cikls noteiktas reizes
    n = 1 + i
    ievadvards = input('Ievadiet lietotājvārdu: ')
    ievadparole = input('Ievadiet paroli: ')
    if ievadvards == 'stop' or ievadparole == 'stop': #ja grib beigt
        print('-----------------')
        break
    elif ievadvards != lietvards or ievadparole != parole:
        print('Ievadiet pareizo lietotājvārdu vai paroli.') 
        print('-----------------')
        continue
    elif ievadvards == lietvards and ievadparole == parole:
        print('Pieslēgšanās veiksmīga.')
        parbaude = input('Vai vēlaties pārbaudīt paroles garumu? (j/n): ') #jautājums ja grib pārbaudīt
        if parbaude == 'n':
            print('-----------------')
            break
        elif parbaude == 'j':
            if parbparole > 5:
                print('Paroles garums ir lielāks par 5.')
                print('-----------------')
                break
            elif parbparole < 5:
                print('Paroles garums ir mazāks par 5.')
                print('-----------------')
                break
    else:
        n > 6
        print('Atļauts mēģināt pieslēgties tikai 5 reizes.')
        print('-----------------')
        break

skaitlis1 = int(input('Ievadiet 1. veselo skaitli: ')) #mainīgie skaitļi
skaitlis2 = int(input('Ievadiet 2. veselo skaotli: '))

while skaitlis1 < 0 or skaitlis2 < 0: #lai lietotājs ievada pareizos skaitļus, kas nav negatīvi
    if skaitlis1 < 0 or skaitlis2 < 0:
        print('Veselais skaitlis nevar būt negatīvs.')
        skaitlis1 = int(input('Ievadiet 1. veselo skaitli: '))
        skaitlis2 = int(input('Ievadiet 2. veselo skaotli: '))
    else:
        break

print(skaitlis1, skaitlis2)