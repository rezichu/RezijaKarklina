iziesana = ['stop']

def izveles_opcijas():
    izvele = input('1 - Izvēlēties kādu no jau esošajiem vārdiem, kas jau ir programmā. \n2 - Izvēlēties kādu mēmā šova vārdu pēc konkrētas tēmas, piemēram, Lieldienas, skola, drošs internets \nKo jūs vēlētos darīt?: ')
    if izvele == iziesana:
        exit()
    elif izvele == '1':
        esosie_vardi()
    elif izvele == '2':
        print()

def esosie_vardi():
    esosie_vardi = [f'Darbības vārds', 'Kaija', 'Gludeklis', 'Nūja', 'Sports', 'Burts', 'Māja', 'Programmēšana', 'Cepetis', 'Ūdens pudele']
    with open('esosie_vardi.txt', 'a', encoding='utf-8') as fails:
        fails.write(f"{esosie_vardi}")



izveles_opcijas()


def saglabat_savi_vardi():
    savi_vardi = []
    print()