def pasuti_tkreklus(skaits,apdruka,piegade):
    if apdruka == 'teksts' and skaits > 0 and piegade == True:
        cena = 5*skaits
        if cena < 50 and cena < 100:
            print('Jums par piegādi jāmaksā 15 eiro.')
            print('Kopējā pirkuma summa:', cena+15)
        elif cena >= 50 and cena < 100:
            print('Piegādāšana ir bezmaksas.')
            print('Kopējā pirkuma summa:', cena)
        else:
            print('Par pirkumu jūs ieguvāt atlaidi par 5%')
            print('Piegādāšana ir bezmaksas.')
            print('Kopējā pirkuma summa:', cena-cena*0.05)
    elif apdruka == 'zīme' and skaits > 0 and piegade == True:
        cena = 7*skaits
        if cena < 50 and cena < 100:
            print('Jums par piegādi jāmaksā 15 eiro.')
            print('Kopējā pirkuma summa:', cena+15)
        elif cena >= 50 and cena < 100:
            print('Piegādāšana ir bezmaksas.')
            print('Kopējā pirkuma summa:', cena)
        else:
            print('Par pirkumu jūs ieguvāt atlaidi par 5%')
            print('Piegādāšana ir bezmaksas.')
            print('Kopējā pirkuma summa:', cena-cena*0.05)
    elif apdruka == 'foto' and skaits > 0 and piegade == True:
        cena = 20*skaits
        if cena < 50 and cena < 100:
            print('Jums par piegādi jāmaksā 15 eiro.')
            print('Kopējā pirkuma summa:', cena+15)
        elif cena >= 50 and cena < 100:
            print('Piegādāšana ir bezmaksas.')
            print('Kopējā pirkuma summa:', cena)
        else:
            print('Par pirkumu jūs ieguvāt atlaidi par 5%')
            print('Piegādāšana ir bezmaksas.')
            print('Kopējā pirkuma summa:', cena-cena*0.05)
    else:
        print('Nevair veikt pirkumu!')
    


par_skaits = int(input('Cik kreklus jūs pirksiet?: '))
par_apdruka = input('Kādu apdruku jūs vēlaties? (teksts/zīme/foto): ')
par_piegade = input('Vai apstiprināt pirkumu? (T/F): ')
pasuti_tkreklus(par_skaits,par_apdruka,par_piegade)