#pieslēgties esošajai datubāzei
#jāuzraksta programma, kur lietotājs var izvēlēties opcijas no 0-5
#katra opcija atgriež vaicājuma rezultātus, bet 0-iziet no programmas
#nevar ievadīt neko citu kā tikai no 0-5
#1-visi klienti
#2-visi pakalpojumi
#3-visi pieraksti (ar klienta vārdu un pakalpojuma nosaukumu)
#4-tuvāko 7 dienu pieraksti
#5-lietotājs norāda cenu->parādīt pakalpojumus, kas ir dārgāki
import sqlite3
from datetime import datetime

savienojums=sqlite3.connect("spa_sistema.db")
cursor = savienojums.cursor()

while True:
    print("\n1 - Parāda visus klientus \n2 - Parāda visus pakalpojumus\n3 - Parāda visus pierakstus\n4 - Parāda tuvāko 7 dienu pierakstus\n5 - Parāda pakalpojumus, kas ir dārgāki par klienta norādīto cenu\n0 - Iziet\n")
    while True:
        try:
            izvele = int(input("Ko jūs vēlētos darīt?(0-5): "))
            if izvele>5:
                print("Ievadiet skaitli starp 0 un 5!")
            else:break
        except ValueError:
            print("Ievadiet skaitli!")
    if izvele==1:
        print("Visi klienti:")
        cursor.execute("SELECT*FROM klienti ORDER BY uzvards ASC\n")
        dati=cursor.fetchall()
        if dati:
            for rinda in dati:
                print(f"ID {rinda[0]}:{rinda[1]} {rinda[2]}, telefona nr.:{rinda[3]}")
        else:
            print("Datu bāzē nav klientu!")
    elif izvele==2:
        print("Visi pakalpojumi:")
        cursor.execute("SELECT*FROM pakalpojumi ORDER BY nosaukums ASC\n")
        dati=cursor.fetchall()
        if dati:
            for rinda in dati:
                print(f"ID {rinda[0]}:{rinda[1]}, ilgums:{rinda[2]}h, cena:{rinda[3]}EUR")
        else:
            print("Datu bāzē nav pakalpojumu!")
    elif izvele==3:
        print("Visi pieraksti:")
        cursor.execute("""
            SELECT pieraksti.pieraksti_id,
                klienti.vards ||' '|| klienti.uzvards AS klients,
                pakalpojumi.nosaukums AS Pakalpojums,
                pakalpojumi.cena,
                pieraksti.datums
            FROM pieraksti
            JOIN klienti ON pieraksti.klients_id=klienti.klienti_id
            JOIN pakalpojumi ON pieraksti.pakalpojums_id=pakalpojumi.pakalpojumi_id
            ORDER BY pieraksti.datums ASC""")
        dati=cursor.fetchall()
        if dati:
            for rinda in dati:
                print(f"ID {rinda[0]}:{rinda[1]}, Pakalpojums:{rinda[2]}, Cena:{rinda[3]}, Datums:{rinda[4]}")
        else:
            print("Datu bāzē nav pierakstu!")
    elif izvele==4:
        print("Pieraksti tuvāko 7 dienu laikā: ")
        cursor.execute("""
            SELECT 
                pieraksti.pieraksti_id,
                klienti.vards ||' '|| klienti.uzvards AS klients,
                pakalpojumi.nosaukums AS Pakalpojums,
                pieraksti.datums
            FROM pieraksti
            JOIN klienti ON pieraksti.klients_id=klienti.klienti_id
            JOIN pakalpojumi ON pieraksti.pakalpojums_id=pakalpojumi.pakalpojumi_id
            WHERE pieraksti.datums BETWEEN date('now') AND date('now'+'7 days')
            ORDER BY pieraksti.datums ASC""")
        dati=cursor.fetchall()
        if dati:
            for rinda in dati:
                print(f"ID {rinda[0]}:{rinda[1]} {rinda[2]}")
        else:
            print("Datu bāzē nav tādu pierakstu!")
    elif izvele==5:
        while True:
            try:
                slieksnis = float(input("Ievadiet jūsu izvēlēto cenu: "))
                if slieksnis<0:
                    print("Ievadiet pozitīvu skaitli!")
                else:
                    break
            except ValueError:
                print("Ievadiet skaitli!")
        cursor.execute("""
            SELECT pakalpojumi.nosaukums, pakalpojumi.ilgums, pakalpojumi.cena
            FROM pakalpojumi
            WHERE pakalpojumi.cena>?
            ORDER BY pakalpojumi.cena DESC""",(slieksnis,))
        dati=cursor.fetchall()
        if dati:
            for rinda in dati:
                print(f"ID {rinda[0]}:{rinda[1]} ({rinda[2]}EUR)")
    elif izvele==0:
        break
    else:
        print("No.")