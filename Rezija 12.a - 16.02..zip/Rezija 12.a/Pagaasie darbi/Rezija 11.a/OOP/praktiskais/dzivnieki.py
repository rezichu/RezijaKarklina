class Dzivnieki:
    def __init__(self,vards,vecums):
        self.vards = vards
        self.vecums = vecums
    def izdodSkanu(self):
        print("Izdod skaņu: ")

class Kakis(Dzivnieki):
    def __init__(self,vards,vecums):
        super().__init__(vards,vecums)
    def izdodSkanu(self):
        super().izdodSkanu()
        return "Ņau ņau!"

class Suns(Dzivnieki):
    def __init__(self,vards,vecums):
        super().__init__(vards,vecums)
    def izdodSkanu(self):
        super().izdodSkanu()
        return "Vau vau!"

dzivnieks1 = Kakis("Muris",12)
dzivnieks1.izdodSkanu()
dzivnieks2 = Suns("Lakons",15)
dzivnieks2.izdodSkanu()