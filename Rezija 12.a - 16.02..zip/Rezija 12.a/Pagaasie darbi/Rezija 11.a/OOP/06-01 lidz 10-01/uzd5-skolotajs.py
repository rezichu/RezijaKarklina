#definēt klasi Skolotajs ar 2 atribūtiem un 2 metodēm
#atribūti - vārds un priekšmets
#metodes iepazistinatArSevi un izliktVertejumu

class Skolotajs:
    def __init__(self,vards,prieksmets):
        self.vards = vards
        self.prieksmets = prieksmets

    def iepazistinatArSevi(self):
        return f"Sveiki, mani sauc {self.vards} un es pasniedzu {self.prieksmets}!"

    def izliktVertejumu(self,vertejums):
        if vertejums < 4:
            return "Priekšmets nav nokārtots!"
        else:
            return "Priekšmets ir nokārtots!"

skolotajs1 = Skolotajs("Rinalds","Ģeogrāfija")
skolotajs2 = Skolotajs("Sandra","Vēsture")

skolotajs1.iepazistinatArSevi()
print(skolotajs1.izliktVertejumu(7))
skolotajs2.iepazistinatArSevi()
print(skolotajs2.izliktVertejumu(3))