#izveidot klasi BankasKonts
#ielikt 2 atribūtus-klienta vārds un atlikums
#klasē ir 2 metodes-iemaksat(summa)-palielinās konta atlikumu ar norādīto summu
#metode iznemt (summa)-samazina konta atlikumu par norādīto summu, ja pieliek līdzekļu
#objekti-klienta Laura sākumā ir 100 eiro |
#iemaksā 50, pārbauda atlimuku |
#izņem 30, pēc tam izņem 200, lai notestētu gadījumu, kad nav līdzekļu

class BankasKontas:
    def __init__(self,vards,atlikums):
        self.vards = vards
        self.atlikums = atlikums

    #metode iemaksai
    def iemaksat(self,summa):
        self.atlikums += summa #palielina atlikumu
        return f"Iemaksāti {summa} EUR. Jaunais atlikums: {self.atlikums} EUR."
    
    def iznemt(self,summa):
        #pārbauda vai kontā pietiek līdzekļu
        if summa > self.atlikums:
            return "Nepietiek līdzekļu!"
        self.atlikums-=summa #samazina konta atlikumu
        return f"Izņemti {summa} EUR. Jaunais atlikums: {self.atlikums} EUR."

konts = BankasKontas("Laura", 100)

print(konts.iemaksat(50))
print(konts.iznemt(30))
print(konts.iznemt(200))