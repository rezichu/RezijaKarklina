from datetime import datetime #tiek importēts datetime, lai iegūtu pāsreizējo laiku un datumu

class Transportlidzeklis:
    def __init__(self,zimols,modelis,reg_datums,pilna_masa,degvielas_veids): #konstruktors, kas satur vajadzīgos parametrus
        self.zimols = zimols #izveido laukus katram parametram
        self.modelis = modelis
        self.reg_datums = reg_datums
        self.pilna_masa = pilna_masa
        self.degvielas_veids = degvielas_veids

    def izvade(self): #metode, kas izvada datus pēc dotā formāta
        print(f"Izvade: \nzīmols: {self.zimols} \nmodelis: {self.modelis} \nreģistrētais datums: {self.reg_datums} \npilna masa: {self.pilna_masa} \ndegvielas veids: {self.degvielas_veids}")
        
registracijas_dat = datetime.now().strftime("%d-%m-%Y") #paņem šī brīža laiku
testa_dati = Transportlidzeklis("Audi","A4",registracijas_dat,1800,"BG") #ārpus bāzes konsoles objekts ar dotiem testa datiem
testa_dati.izvade() #izsauc izvades metodi