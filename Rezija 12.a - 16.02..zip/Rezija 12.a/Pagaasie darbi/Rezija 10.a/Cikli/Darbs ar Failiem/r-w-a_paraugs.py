#ar w+ izveidot failu 'dati2.txt' ༼ つ ◕_◕ ༽つ
file = open('dati2.txt', 'w+', encoding = 'utf-8')

#ierakstīt failā sarakstu ar 3 pilsētām
saraksts = ['Latvija\n','Igaunija\n','Lietuva\n']
file.writelines(saraksts) #ieraksta vairākās rindiņās
#ierakstīt vienu virkni 'Hello, World!'
file.write('Hello, World!\n')

file = open('dati2.txt', 'a+', encoding = 'utf-8')
#pievienot vārdnīcu ar 3 valstīm un galvaspilsētām

vardnica = {
    '\nLatvija':'Rīga',
    '\nIgaunija':'Tallina',
    '\nSomija':'Helsinki'
}
file.writelines(vardnica)