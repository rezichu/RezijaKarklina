print("1. Darbs ar sarakstu")
skoleni = ["Jānis","Pēteris","Anna","Lauma","Rūdolfs","Nikola","Liene","Artūrs"]

print("Sakārtots skolēnu saraksts=", sorted(skoleni))
print("Dalībnieku skaits=", len(skoleni))
skoleni.pop(2)
print("Jaunais dalībnieku saraksts=",skoleni)
print("\n*************")
print("2. Korteži")
pasakumi=[
    ("Sporta diena","Skolas stadions",120),
    ("Zinātnes diena","Skola",80),
    ("Karjeras diena","Skola",100)
]

def drukaKortezs(pasakumi):
    print("Saraksta garums:")
    for i in pasakumi:
        print(i)
    print()
drukaKortezs(pasakumi)
print("\n*************")
print("3. Kopa")
sporta_skoleni=["Jānis","Pēteris","Anna","Lauma","Rūdolfs","Nikola","Liene"]
zinatnes_skoleni=["Jānis","Lauma","Artūrs","Loreta","Gustavs","Evelīna","Atis","Patriks"]

sporta_diena=set(sporta_skoleni)
zinatnes_diena=set(zinatnes_skoleni)

sporta_diena.add("Sonora")
print("Jaunais sarkasts: ",sporta_diena)
visi_skoleni=sporta_diena.intersection(zinatnes_diena)
print("Skolēni ,kas piedalās abos pasākumos: ",visi_skoleni)
rez=sporta_diena.difference(zinatnes_diena)
print("Skolēni, kas piedalās tikai sporta dienā: ",rez)
viens=sporta_diena.union(zinatnes_diena)
print("Visi unikālie skolēni, kas piedalās vismaz vienā pasākumā: ",viens)
print("\n*************")
print("4. Vārdnīca")
skolenu_saraksts={
    "Jānis":["Sporta diena","Zinātnes diena"],
    "Pēteris":["Sporta diena"],
    "Anna":["Sporta diena"],
    "Lauma":["Sporta diena","Zinātnes diena"],
    "Gustavs":["Zinātnes diena"],
    "Loreta":["Zinātnes diena"]
}

skolenu_saraksts["Pēteris"].append("Karjeras diena")
skolenu_saraksts["Gustavs"].append("Karjeras diena")
key = "Ilmārs"
skolenu_saraksts.setdefault(key, [])
skolenu_saraksts[key].append("Karjeras diena")

rezultats = {}
for skolens, pasakumu_saraksts in skolenu_saraksts.items():
    rezultats[skolens] = len(pasakumu_saraksts)
print("Skolēns un pasākumu skaits: ",rezultats)


max_key = max(skolenu_saraksts, key=rezultats.get)
print(max_key)

list =[] # create empty list
for val in skolenu_saraksts.values(): 
  if val in list: 
    continue 
  else:
    list.append(val)

print(list)

for skolens, pasakumu_saraksts in skolenu_saraksts.items():
    if len(pasakumu_saraksts) == 1:
        print("Skolēni, kuru pasākumu skaits ir 1: ",rezultats)