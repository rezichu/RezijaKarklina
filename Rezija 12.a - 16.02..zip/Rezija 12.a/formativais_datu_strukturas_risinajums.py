#funkcijas formatēšanai
def print_un_raksti(rindas,teksts):
    print(teksts)
    rindas.append(teksts)

def atdala(rindas,virsraksts):
    linija="-"*60
    print_un_raksti(rindas,"\n"+linija)
    print_un_raksti(rindas,virsraksts)
    print_un_raksti(rindas,linija)

def saraksts_viena_rinda(vardi):
    return ",".join(vardi) if vardi else "(nav)"

drukat_rindas=[]
sporta_dalibnieki=["Jānis","Pēteris","Anna","Lauma","Rūdolfs","Nikola","Liene","Artūrs"]
sporta_dalibnieki.sort() #kārtošana
dalibniku_skaits=len(sporta_dalibnieki)

atteicies="Anna"
if atteicies in sporta_dalibnieki:
    sporta_dalibnieki.remove(atteicies)

#formatēšana un datu izvade uz ekrāna
print_un_raksti(drukat_rindas,f"Dalībnieku skaits: {dalibniku_skaits}")
print_un_raksti(drukat_rindas,f"Atteicies: {atteicies}")
print_un_raksti(drukat_rindas,f"Visi sporta dalībnieki: {saraksts_viena_rinda(sporta_dalibnieki)}")

atdala(drukat_rindas,"Pasākuma pamatinformācija: ")
pasakums_sporta=("Sporta diena","Skolas stadions",120)
pasakums_zinatnes=("Zinātnes diena","Skola",80)
pasakums_karjeras=("Karjeras diena","Skola",100)

#apvienot visu vienā sarakstā
pasakumi=[pasakums_sporta,pasakums_zinatnes,pasakums_karjeras] #saraksts ar kortežiem
for i,p in enumerate(pasakumi,start=1):
    nosaukums=p[0]
    vieta=p[1]
    limits=p[2]

    print_un_raksti(drukat_rindas,f"\nPasākums {i}")
    print_un_raksti(drukat_rindas,f"Nosaukums {nosaukums}")
    print_un_raksti(drukat_rindas,f"Vieta {vieta}")
    print_un_raksti(drukat_rindas,f"Limits {limits}")

atdala(drukat_rindas,"Dalības: ")

sporta_skoleni=["Jānis","Pēteris","Anna","Lauma","Rūdolfs","Nikola","Liene"]
zinatnes_skoleni=["Jānis","Lauma","Artūrs","Loreta","Gustavs","Evelīna","Atis","Patriks"]

#pārveido par kopām
sporta_diena=set(sporta_skoleni)
zinatnes_diena=set(zinatnes_skoleni)

sporta_diena.add("Bērziņš")
abi_pasakumi=sporta_diena.intersection(zinatnes_diena)
tikai_sports=sporta_diena.difference(zinatnes_diena)
visi_unikalie=sporta_diena.union(zinatnes_diena)

print_un_raksti(drukat_rindas,f"Sporta dienas(unikālie): {saraksts_viena_rinda(sorted(tikai_sports))}")