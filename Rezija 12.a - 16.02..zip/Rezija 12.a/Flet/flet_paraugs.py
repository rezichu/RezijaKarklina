import flet as ft
#sākas ar funkciju, kurai padod page objektu

def main(page: ft.Page):
    page.title="Fish jodeling"
    teksts=ft.Text("Sveika, pasaule!")
    poga=ft.ElevatedButton("Nospied mani!")
    page.add(teksts,poga)

ft.app(target=main) #startē logu, izsauc main(page)