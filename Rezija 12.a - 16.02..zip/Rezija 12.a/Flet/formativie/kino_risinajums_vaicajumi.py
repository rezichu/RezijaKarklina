import flet as ft
import sqlite3

def main(page: ft.Page):
    page.title="Kino seansi"
    page.window_width=900
    page.window_height=650

#savienojums ar datubāzi
    savienojums=sqlite3.connect("skolas_kino_db.db")
    cursor=savienojums.cursor()

#flet elementi: pogas un izvēle
    virsraksts=ft.Text("Kino seansi-vaicājumi",size=22,weight=ft.FontWeight.BOLD)
    #dropdown izvēle - links filmu nosaukumi no db
    filmas_dropdown=ft.Dropdown(
        label="Izvēlies filmu", #txt, ko redz lietotājs
        width=350,
        options=[] #iespējamās izvēles, ko vēlāk nolasit no tabulas filma
    )
    statusa_teksts=ft.Text("",color="red") #teksts kļūdām, ziņojumiem

    #tabula rezultātu attēlošanai
    #kolonnas: filmas nosaukums|zāle|datums|laiks|cena
    #rindas tiks mainītas pēc katra vaicājuma
    rezultatu_tabula=ft.DataTable(
        columns=[
            ft.DataColumn(ft.Text("Filma")),
            ft.DataColumn(ft.Text("Zāle")),
            ft.DataColumn(ft.Text("Datums")),
            ft.DataColumn(ft.Text("Laiks")),
            ft.DataColumn(ft.Text("Cena"))
        ],
        rows=[]
    )

    def paradit_tabula(rezultati): #Šī funkcija saņem SQL rezultātus(sarakstu ar rindām) un ieliek to tabulā
        rezultatu_tabula.rows=[] #sākumā notīra vecās rindas
        #ja nekas nav atrasts, parā'dit paziņojumu(tabulu atstāj tukšu)
        if not rezultati:
            statusa_teksts.value="Nav atbilstošu seansu"
            page.update()
            return
        #ja ir rezultāti, tad noņem paziņojumu
        statusa_teksts.value=""

        #izveidot DataRow katrai rindais
        for rinda in rezultati:
            cells=[
                ft.DataCell(ft.Text(str(rinda[0]))),
                ft.DataCell(ft.Text(str(rinda[1]))),
                ft.DataCell(ft.Text(str(rinda[2]))),
                ft.DataCell(ft.Text(str(rinda[3]))),
                ft.DataCell(ft.Text(str(rinda[4])))
            ]
        rezultatu_tabula.rows.append(ft.DataRow(cells=cells))
        page.update() #atjaunināt lapu

#filmu nosaukumi dropdown izvēlē
#atlasīt filmas sakartotas pēc nosaukuma
    cursor.execute("SELECT nosaukums FROM filmas ORDER BY nosaukums")
    filmas=cursor.fetchall()
    #pārvēst rezultātu par dd opcijām
    option=[]
    for f in filmas:
        option.append(ft.dropdown.Option(f[0]))
    filmas_dropdown.options=option

#vaicājums 2-filtrēt seansus pēc filmas nosaukuma
    def filtret_seansu_pec_filmas(_):
            izveleta_filmas=filmas_dropdown.value
            #ja lietotājs nav izvēlējies filmu, parāda paziņojumu
            if not izveleta_filmas:
                statusa_teksts.value="Izvēlieties filmu, tad spied 'Filtrēt'!"
                rezultatu_tabula.rows=[]
                page.update()
                return
            sql="""
            SELECT filmas.nosaukums,
                zales.nosaukums,
                seansi.datums,
                seansi.sakuma_laiks,
                seansi.cena
            FROM seansi
            JOIN filmas ON seansi.filma_id=filmas.filma_id
            JOIN zales ON seansi.zale_id=zales.zale_id
            WHERE filmas.nosaukums=?"""

            cursor.execute(sql,(izveleta_filmas,))
            rezultati=cursor.fetchall()
            paradit_tabula(rezultati)

#poga rezultātiem
    poga_filtret=ft.ElevatedButton("Filtrēt seansus",on_click=filtret_seansu_pec_filmas)

    page.add(
        virsraksts,
        ft.Row([filmas_dropdown,poga_filtret]),
        statusa_teksts,
        ft.Text("Rezultāti: ",size=16,weight=ft.FontWeight.BOLD),
        ft.Container(rezultatu_tabula,padding=10)
    )
ft.app(target=main)