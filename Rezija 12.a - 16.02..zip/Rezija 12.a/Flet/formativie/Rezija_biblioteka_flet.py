import flet as ft
import sqlite3

def main(page:ft.Page):
    page.title="Bibliotēkas datu ievade ar flet"

    #savienojums ar datubāzi
    savienojums=sqlite3.connect("biblioteka_Rezija.db")
    cursor=savienojums.cursor()

    statuss=ft.Text("Te būs statusa dati")

    gramatas_nosaukums=ft.TextField(label="Grāmatas nosaukums")
    gramatas_autors=ft.TextField(label="Grāmatas autors")
    gramatas_gads=ft.TextField(label="Grāmatas izdošanas gads")
    gramatas_zanrs=ft.TextField(label="Grāmatas žanrs")

    def gramatas(_):
        nosaukums=gramatas_nosaukums.value.strip()
        autors=gramatas_autors.value.strip()
        gads=gramatas_gads.value.strip()
        zanrs=gramatas_zanrs.value.strip()

        if "" in [nosaukums,autors,gads,zanrs]:
            statuss.value="Kļūda: aizpildiet visus laukus!"
        elif gads.isdigit() is False:
            statuss.value="Kļūda: gadam ir jābūt skaitlim!"
        else:
            cursor.execute(
                """INSERT INTO gramatas(nosaukums,autors,gads,zanrs) VALUES(?,?,?,?)""",
                (nosaukums,autors,gads,zanrs)
            )
            savienojums.commit()
            statuss.value="Dati pievienoti!"

            gramatas_nosaukums.value=""
            gramatas_autors.value=""
            gramatas_gads.value=""
            gramatas_zanrs.value=""
        page.update()
    poga_gramatas=ft.ElevatedButton("Saglabāt grāmatu",on_click=gramatas,color="pink")

    lasitaji_vards=ft.TextField(label="Lasītāja vārds")
    lasitaji_uzvards=ft.TextField(label="Lasītāja uzvārds")
    lasitaji_klase=ft.TextField(label="Lasītāja klase")

    def lasitaji(_):
        vards=lasitaji_vards.value.strip()
        uzvards=lasitaji_uzvards.value.strip()
        klase=lasitaji_klase.value.strip()

        if "" in [vards,uzvards,klase]:
            statuss.value="Kļūda: aizpildiet visus laukus!"
        else:
            cursor.execute(
                """INSERT INTO lasitaji(vards,uzvards,klase) VALUES(?,?,?)""",
                (vards,uzvards,klase)
            )
            savienojums.commit()
            statuss.value="Dati pievienoti!"

            lasitaji_vards.value=""
            lasitaji_uzvards.value=""
            lasitaji_klase.value=""
        page.update()
    poga_lasitaji=ft.ElevatedButton("Saglabāt lasītāju",on_click=lasitaji,color="pink")

    gi_gramata=ft.Dropdown(label="Izvēlies grāmatu")
    gi_lasitajs=ft.Dropdown(label="Izvēlies grāmatu")
    gi_datums=ft.TextField(label="Grāmatas izņemšanas datums")
    gi_atdots=ft.Checkbox(label="Grāmata atdota?", value=False)
    def iznemtas_gramatas(_):
        cursor.execute(
            """SELECT lasitaji_id,vards,uzvards,klase
            FROM lasitaji
            ORDER BY uzvards,vards"""
        )
        lasitaji=cursor.fetchall()
        gi_lasitajs.options=[
            ft.dropdown.Option(
            key=str(r[0]),
            text=f"{r[1]}({r[2]},{r[3]})"
            )
            for r in lasitaji
        ]

        cursor.execute(
            """SELECT gramatas_id,nosaukums,autors,gads,zanrs
            FROM gramatas
            ORDER BY nosaukums"""
        )
        gramatas=cursor.fetchall()
        options=[]
        for r in gramatas:
            options.append(
                ft.dropdown.Option(
                    key=str(r[0]),
                    text=f"{r[1]}({r[2]},{r[3]},{r[4]})"
                )
            )
        gi_gramata.options=options
        page.update()
    poga_iznemtas=ft.ElevatedButton("Saglabāt grāmatas izņemšanu",on_click=iznemtas_gramatas,color="pink")

    page.add(
        ft.Text("Grāmatas pievienošana"),
        gramatas_nosaukums,
        gramatas_autors,
        gramatas_gads,
        gramatas_zanrs,
        poga_gramatas,
        ft.Text("Lasītāju pievienošana"),
        lasitaji_vards,
        lasitaji_uzvards,
        lasitaji_klase,
        poga_lasitaji,
        ft.Text("Grāmatas izņemšanas pievienošana"),
        statuss
    )
ft.app(target=main)