import flet as ft
import sqlite3


def main(page: ft.Page):
    page.title="TV šovi:datubāze"

    #savienojums ar datubāzi
    savienojums=sqlite3.connect("testa_dati_tv_sovi.db")
    cursor=savienojums.cursor()
    
    #teksts statusam(vai visi dati ievaditi)
    statuss=ft.Text("")
    
    #lauki datu ievadei
    lauks_nosaukums=ft.TextField(label="Nosaukums")
    lauks_kanals = ft.TextField(label="Kanāls")
    lauks_zanrs = ft.TextField(label="Žanrs")
    lauks_gads = ft.TextField(label="Gads")
    #funkcija datu saglabāšanai
    
    def saglabat(_): #nolasit ievadītas vērtības
        nosaukums=lauks_nosaukums.value.strip()
        kanals=lauks_kanals.value.strip()
        zanrs=lauks_zanrs.value.strip()
        gads_txt=lauks_gads.value.strip()
        
        if "" in [nosaukums,kanals,zanrs,gads_txt]:
            statuss.value="Kļūda: aizpildi visus laukus!"
        else:
            cursor.execute(
                """
                INSERT INTO televizijas_sovi(nosaukums,kanals,zanrs,gads)
                VALUES(?,?,?,?)
                """, 
                (nosaukums,kanals,zanrs,gads_txt)
            )
            savienojums.commit()
            statuss.value="Dati pievienoti!"
            
            #jānotīra ievades lauki
            lauks_nosaukums.value = ""
            lauks_kanals.value = ""
            lauks_zanrs.value = ""
            lauks_gads.value = ""   
        page.update()  #atjaunina statusu
    poga=ft.ElevatedButton("Saglabāt datus",on_click=saglabat)
    

    dal_vards = ft.TextField(label="Vārds")
    dal_uzvards = ft.TextField(label="Uzvārds")
    dal_profesija = ft.TextField(label="Profesija")
    
    def saglabat_dalibnieku(e):
        vards = dal_vards.value.strip()
        uzvards = dal_uzvards.value.strip()
        profesija = dal_profesija.value.strip()
    
        if "" in [vards, uzvards, profesija]:
            statuss.value = "Kļūda: aizpildi visus dalībnieka laukus!"
        else:
            cursor.execute(
                """
                INSERT INTO sovu_dalibnieki (vards, uzvards, profesija)
                VALUES (?, ?, ?)
                """,
                (vards, uzvards, profesija)
            )
            savienojums.commit()

            statuss.value = "Dalībnieks pievienots!"
            dal_vards.value = ""
            dal_uzvards.value = ""
            dal_profesija.value = ""
            
            page.update()
    poga_dalibnieks = ft.ElevatedButton("Saglabāt dalībnieku", on_click=saglabat_dalibnieku
    )
    page.add(lauks_nosaukums,
             lauks_kanals,
             lauks_zanrs,
             lauks_gads,
             poga,
             ft.Text("Dalībnieka pievienošana"),
             dal_vards,
             dal_uzvards,
             dal_profesija,
             poga_dalibnieks,
             statuss)

ft.app(target=main)    