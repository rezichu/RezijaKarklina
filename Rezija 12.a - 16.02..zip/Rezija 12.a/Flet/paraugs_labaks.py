import flet as ft
def main(page:ft.Page):
    page.title="Dažādi piemēri"
    #lielais virsraksts
    virsraksts=ft.Text(
        value="5. janvāra stunda",
        size=27,
        weight=ft.FontWeight.BOLD,
        color="pink"
    )

    #ievades lauki vārdam un uzvārdam
    vards=ft.TextField(
        label="Ievadi vārdu: ",
        width=200, #ievades lauka platums px
        color="pink"
    )

    uzvards=ft.TextField(
        label="Ievadi uzvārdu: ",
        width=200, #ievades lauka platums px
        color="pink"
    )

    #rezultāta teksts(mainīsies nospiežot pogu)
    rezultats=ft.Text(
        value="Te būs rezultāts",
        size=20,
        color="pink"
    )

    #dialoglogs(alert logs)
    dialogs=ft.AlertDialog(
        title=ft.Text("Papildu logs"),
        content=ft.Text("Šis ir teksts!"),
    action = [
        ft.TextButton("Aizvērt",
                      on_click=lambda e:page.close(dialogs))
                      #pogas, kas būs mazajā logā
    ]
    ) #aizvērs logu

    #funkcija, kas parādīs sveicienu
    def paradit_sveicienu(_):
        if vards.value.strip()=="" or uzvards.value.strip()=="":
            rezultats.value="Lūdzu, aizpildīt abus laukus!"
            rezultats.color="pink"
        else:
            rezultats.value=f"Sveiks, {vards.value} {uzvards.value}!"
            rezultats.color="pink"
    #atjaunināt lapu, lai redzētu izmaiņas
        page.update()
    #poga, kas parādīs sveicienu(izsauks f-ju)
    poga_sveiciens=ft.ElevatedButton(
        text="Parādīt sveicienu",
        on_click=paradit_sveicienu
    )

    #funkcija, kas atver dialoga logu
    def atver_logu(_):
        page.open(dialogs)
    #sasaista ar funkciju
    poga_logs=ft.OutlinedButton(
        "Atvērt otro logu",on_click=atver_logu
    )

    page.add(
        virsraksts,
        vards,
        uzvards,
        poga_sveiciens,
        rezultats
    )

ft.app(target=main)