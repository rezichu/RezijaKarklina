#sporta_centrs_skelets_vienkars.py
#skolēnam jāieliek SQL vaicājumi, pogas, jāizvieto elementi lapā(page.add)

import flet as ft
import sqlite3

def main(page: ft.Page):
    page.title = "Sporta centrs (ieraksti savu nosaukumu)"
    page.window_width = 1000
    page.window_height = 700

    #Savienojums ar DB (DB fails tajā pašā mapē)
    savienojums = sqlite3.connect("sporta_centrs_db.db", check_same_thread=False)
    cursor = savienojums.cursor()
    cursor.execute("PRAGMA foreign_keys = ON;")

    #Flet elementi
    virsraksts = ft.Text("Sporta centrs – vaicājumi", size=22, weight=ft.FontWeight.BOLD, color="pink")
    statuss = ft.Text("")

    #Dropdown(trenera izvēlei)
    treneri_dropdown = ft.Dropdown(
        label="Izvēlies treneri (filtram)",
        width=320,
        options=[]
    )

    #rezultātu tabula
    tabula = ft.DataTable(
        columns=[
            ft.DataColumn(ft.Text("Nodarbība")),
            ft.DataColumn(ft.Text("Treneris")),
            ft.DataColumn(ft.Text("Zāle")),
            ft.DataColumn(ft.Text("Datums")),
            ft.DataColumn(ft.Text("Laiks")),
            ft.DataColumn(ft.Text("Cena")),
        ],
        rows=[]
    )

    #funkcija, kas ieliek datus tabulā
    def paradit_tabula(kolonnas, rindas):
        #iestata kolonnas
        tabula.columns = []
        for k in kolonnas:
            tabula.columns.append(ft.DataColumn(ft.Text(k)))

        tabula.rows = [] #Notīra vecās rindas

        #Ja nav datu, parāda paziņojumu
        if len(rindas) == 0:
            statuss.value = "Nav atrasti dati."
            page.update()
            return

        statuss.value = ""

        #Ieliek rindas tabulā
        for rinda in rindas:
            cells = []
            for vertiba in rinda:
                cells.append(ft.DataCell(ft.Text(str(vertiba))))
            tabula.rows.append(ft.DataRow(cells=cells))

        page.update()#neaizmirsti atjaunot lapu

    #dropdown aizpildīšana no datubazes, panemot treneru vardus
    cursor.execute("SELECT vards FROM treneri ORDER BY vards;")
    treneri = cursor.fetchall()  
    treneri_dropdown.options = [ft.dropdown.Option(t[0]) for t in treneri]


    def poga_visas_nodarbibas(_):
        #vaic1-Rādīt visas nodarbības
        sql = """
        SELECT 
            nodarbibas.nosaukums,
            treneri.vards || ' ' || treneri.uzvards AS treneris,
            zales.nosaukums,
            nodarbibas.datums,
            nodarbibas.sakuma_laiks,
            nodarbibas.cena
        FROM nodarbibas
        JOIN treneri ON nodarbibas.trenera_id=treneri.trenera_id
        JOIN zales ON nodarbibas.zales_id=zales.zales_id
        ORDER BY nodarbibas.nosaukums
        """ #tiek visi vajadzīgie dati no tabulām paņemti, lai smuki parādītu un sakārtotu tos
        cursor.execute(sql) #izsauc ar cursor.execute, lai iegūtu noteiktos datus no vaicājuma
        rindas = []
        rindas=cursor.fetchall() #saglabā datus sarakstā

        kolonnas = ["Nodarbība", "Treneris", "Zāle", "Datums", "Laiks", "Cena"]
        paradit_tabula(kolonnas, rindas)

    def poga_filtret_pec_trenera(_):
        #vaic2-Filtrēt pēc trenera (Dropdown)
        izvelets_treneris = treneri_dropdown.value
        if not izvelets_treneris:
            statuss.value = "Izvēlies treneri no Dropdown!"
            page.update()
            return

        sql = """
        SELECT
            nodarbibas.nosaukums,
            treneri.vards || ' ' || treneri.uzvards AS treneris,
            zales.nosaukums,
            nodarbibas.datums,
            nodarbibas.sakuma_laiks,
            nodarbibas.cena
        FROM nodarbibas
        JOIN treneri ON nodarbibas.trenera_id=treneri.trenera_id
        JOIN zales ON nodarbibas.zales_id=zales.zales_id
        WHERE treneri.vards=?"""
        cursor.execute(sql,(izvelets_treneris,))

        rindas = []
        rindas = cursor.fetchall()

        kolonnas = ["Nodarbība", "Treneris", "Zāle", "Datums", "Laiks", "Cena"]
        paradit_tabula(kolonnas, rindas)

    def poga_zales(_):
        #vaic3-Rādīt zāles
        sql = """
        SELECT
            nosaukums,
            vietu_skaits
        FROM zales
        ORDER BY nosaukums"""
        cursor.execute(sql)
        rindas = []
        rindas = cursor.fetchall()

        kolonnas = ["Zāle", "Vietu skaits"]
        paradit_tabula(kolonnas, rindas)

    def poga_treneri(_):
        #vaic4-Rādīt trenerus
        sql = """
        SELECT
            vards,
            uzvards,
            specializacija
        FROM treneri
        ORDER BY vards"""
        cursor.execute(sql)
        rindas = []
        rindas = cursor.fetchall()

        kolonnas = ["Vārds", "Uzvārds", "Specializācija"]
        paradit_tabula(kolonnas, rindas)

    def poga_apmeklejumi(_):
        #vaic5-Rādīt apmeklējumus(JOIN)
        sql = """
        SELECT
            apmeklejumi.apmeklejuma_id,
            nodarbibas.nosaukums,
            apmeklejumi.apmeklejuma_datums
        FROM apmeklejumi
        JOIN nodarbibas ON apmeklejumi.nodarbibas_id=nodarbibas.nodarbibas_id
        ORDER BY apmeklejumi.apmeklejuma_id
            """
        cursor.execute(sql)
        rindas = []
        rindas = cursor.fetchall()

        kolonnas = ["Apmeklējums ID", "Nodarbība", "Datums"]
        paradit_tabula(kolonnas, rindas)

    def poga_skaits(_):
        #vaic5-Apmeklējumu skaits(COUNT + GROUP BY)
        sql = """
        SELECT
            nodarbibas.nosaukums,
            COUNT(apmeklejumi.apmeklejuma_id)
        FROM apmeklejumi
        JOIN nodarbibas ON apmeklejumi.nodarbibas_id=nodarbibas.nodarbibas_id
        GROUP BY nodarbibas.nosaukums""" #GROUP BY lieto, lai programma saskaita datus un nedublē nodarbības
        cursor.execute(sql)
        rindas = []
        rindas = cursor.fetchall()

        kolonnas = ["Nodarbība", "Apmeklējumu skaits"]
        paradit_tabula(kolonnas, rindas)

    #Pogas
    #te saliec pogas, kas norādītas izdrukātajā lapā

    poga_viss=ft.ElevatedButton("Rādīt visas nodarbības", on_click=poga_visas_nodarbibas, color="pink") #pogas, lai varētu izsaukt funkciju
    poga_filtret=ft.ElevatedButton("Filtrēt pēc trenera", on_click=poga_filtret_pec_trenera, color="pink") #rozā, jo smuki :]
    poga_zale=ft.ElevatedButton("Rādīt zāles", on_click=poga_zales, color="pink")
    poga_treneris=ft.ElevatedButton("Rādīt trenerus", on_click=poga_treneri, color="pink")
    poga_apmeklejums=ft.ElevatedButton("Rādīt apmeklētājus", on_click=poga_apmeklejumi, color="pink")
    poga_vietas=ft.ElevatedButton("Apmeklējumu skaits", on_click=poga_skaits, color="pink")

    #Lapas izkārtojums
    page.add(
    #te smuki pievieno visus lapas elementus
        virsraksts,
        poga_viss,
        ft.Row([treneri_dropdown,poga_filtret]), #te izmanto flet Row, lai smuki tiek salikts rindiņā
        ft.Row([poga_zale,poga_treneris,poga_apmeklejums,poga_vietas]),
        statuss,
        ft.Text("Rezultāti: ",size=16,weight=ft.FontWeight.BOLD,color="pink"),
        ft.Container(tabula,padding=10) #parāda rezultātus, kad nospiež jebkuru no pogām
    )

ft.app(target=main) 