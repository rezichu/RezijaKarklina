import sqlite3

savienojums = sqlite3.connect("Rezija_sports.db")
cursor = savienojums.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS sportisti(
    sportisti_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards TEXT NOT NULL,
    uzvards TEXT NOT NULL,
    vecums INTEGER NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS nodarbibas(
    nodarbibas_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sportisti_id TEXT NOT NULL,
    veids TEXT NOT NULL,
    ilgums INTEGER NOT NULL,
    FOREIGN KEY (sportisti_id) REFERENCES sportisti(sportisti_id)
)
""")

def ievade_jn(atbildes): #Pārbauda lietotāja atbildi
    while True:
        atbilde=input(atbildes).lower()
        if atbilde in ["j","n"]:
            return atbilde
        print("Ievadi tikai 'j' vai 'n'!")
def skaitla_parbaude(skaitli): #Pārbauda ievadīto atbildi
    while True:
        skaitlis=input(skaitli)
        if skaitlis.isdigit() and int(skaitlis)>0: #isdigit pārbauda vai atblide ir skaitlis un vai ir ievadīta atbilde
            break
        else:
            print("Ievadiet pozitīvu skaitli!")
def teksta_parbaude(teksti): #Pārbaudo ievadīto atbildi
    while True:
        teksts = input(teksti)
        if teksts.isalpha(): #isalpha pārbauda vai atbilde ir teksts un vai tur ir ievadīta atbilde
            break
        else:
            print("Ievadiet tekstu!")

while True:
    print("---Pievienojiet sportistu---")
    vards = teksta_parbaude("Ievadiet sportista vārdu: ") #Nosūta uz funkciju teksta_parbaude
    uzvards = teksta_parbaude("Ievadiet sportista uzvārdu: ")
    vecums = skaitla_parbaude("Ievadiet sportista vecumu: ") #Nosūta uz funkciju skaitla_parbaude
    cursor.execute("INSERT INTO sportisti(vards,uzvards,vecums) VALUES(?,?,?)",(vards,uzvards,vecums))
    savienojums.commit()
    print("Sportists pievienots!")
    turpinat=ievade_jn("Vai pievienot vēl klientu?(j/n): ")
    if turpinat=="n":
        break

while True:
    print("---Pievienojiet nodarbibu---")
    while True:
        try:
            sportisti_id = skaitla_parbaude("Ievadiet sportista id: ")
            #pārbaudīt,vai pakalpojuma id tabulā eksistē
            cursor.execute("SELECT COUNT(*) FROM nodarbibas WHERE sportisti_id=?",(sportisti_id,))
            if cursor.fetchone()[0]>0:
                break #id pareizs-turpina
            else:
                print("Pakalpojums ar šādu ID neeksistē!")
        except ValueError:
            print("Ievadi skaitli, jo ID ir cipars.")
    veids = teksta_parbaude("Ievadiet nodarbibas veidu: ")
    ilgums = skaitla_parbaude("Ievadiet nodarbibas ilgumu(min): ")
    cursor.execute("INSERT INTO nodarbibas(sportisti_id,veids,ilgums) VALUES(?,?,?)",(sportisti_id,veids,ilgums))
    savienojums.commit()
    print("Nodarbiba pievienota!")
    turpinat=ievade_jn("Vai pievienot vēl klientu?(j/n): ")
    if turpinat=="n":
        break

print("Katra sportista kopējo nodarbību skaits:")
cursor.execute(
    """SELECT
        vards || ' ' || uzvards AS Sportisti,
        COUNT(nodarbibas_id) AS Nodarbibu_skaits
    FROM sportisti JOIN nodarbibas ON sportisti.sportisti_id=nodarbibas.sportisti_id
    GROUP BY vards;"""
)
for rinda in cursor.fetchall():
    print(rinda)

print("Parādīt tos sportistus, kuri kopā pavadījuši 120min trenējoties:")

print("Parādīt TOP 3 sportistus pēc treniņu laika:")