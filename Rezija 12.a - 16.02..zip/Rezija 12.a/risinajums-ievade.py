from collections import deque

#izveido sarakstu ar korteziem
biletes = [
    (1, "Anna", "A12"),
    (2, "Jānis", "B5"),
    (3, "Marta", "C3")
]
aiznemtas_sedvietas = {"A12", "B5", "C3"} #izveido kopu, kur norāda aizņemtās sēdvietas 
rinda = deque() #izveido divvirzienu rindas objektu

#funkcija biļetes meklēšanai pēc ID
def meklet_bileti(biletes_id, biletes_saraksts):
    for bilete in biletes_saraksts:  #iet cauri katrai biļetei sarakstā, pārbaudot vai id sakrīt ar meklēto un atgriež
        if bilete[0] == biletes_id:  #funkcija pārbauda visus saraksta elementus.
            #Kad nonāk pie pirmā elementa(1,Anna,A12), tad redz, ka bilete[0]==biletes_id(abi ir 1).Atgriež
            return bilete           
    return "Biļete nav atrasta" #neatrod atbilstošus datus

#iespēja pievienot jaunu biļeti, ja ID nav aizņemts
def pievienot_bileti(biletes_id, pircēja_vārds, sedvieta, biletes_saraksts, aiznemtas_sedvietas):
    if sedvieta in aiznemtas_sedvietas:
        return "Neizdevās pievienot biļeti: sēdvieta jau ir aizņemta"
    if any(bilete[0] == biletes_id for bilete in biletes_saraksts): #any pārbauda vai jebkurš elements ir TRUE
        return "Neizdevās pievienot biļeti: biļetes ID jau eksistē"
    biletes_saraksts.append((biletes_id, pircēja_vārds, sedvieta))
    aiznemtas_sedvietas.add(sedvieta)
    return "Biļete veiksmīgi pievienota"

#Pārbauda vai konkrētā sēdvieta ir aizņemta(šādā uzdevumā būs aizņemtas tās, kuras ir kopā(set) ieliktas. 
#jāpārbauda vai darbojas, ievadot sēdvietu, kas nav reģistrēta sistēmā
def vai_sedvieta_aiznemta(sedvieta, aiznemtas_sedvietas):
    if sedvieta not in aiznemtas_sedvietas: #ja atrod lietotāja ievadīto tekstu kopā 'aiznemtas_sedvietas',tad atgriež tekstu
        return "Šī sēdvieta nav reģistrēta sistēmā" 
    return sedvieta in aiznemtas_sedvietas 

def ienakt_rinda(vards, rinda, no_priekspuses=True):
    if no_priekspuses:
        rinda.appendleft(vards)
    else:
        rinda.append(vards)

'''def iziet_no_rindas(rinda, no_priekspuses=True):
    if no_priekspuses:
       return rinda.popleft() if rinda else "Rinda ir tukša"
    else:
        return rinda.pop() if rinda else "Rinda ir tukša"'''

def aiznemto_sedvietu_skaits(aiznemtas_sedvietas):
    return len(aiznemtas_sedvietas)


while True:
        print("\n🎵 Koncertzāles pārvaldības sistēma 🎵")
        print("1. Meklēt biļeti")
        print("2. Pievienot jaunu biļeti")
        print("3. Pārbaudīt, vai sēdvieta ir aizņemta")
        print("4. Ienākt rindā")
        #print("5. Iziet no rindas")
        print("5. Skatīt aizņemto sēdvietu skaitu")
        print("6. Iziet no programmas")
        izvele = input("Izvēlies darbību (1-6): ")

        if izvele == "1":   #pie ievadītā cipara izsauc pareizo funkciju, padodot pareizos argumentus
            biletes_id = int(input("Ievadi biļetes ID: "))
            rezultats = meklet_bileti(biletes_id, biletes)
            print(f"Rezultāts: {rezultats}")
        
        elif izvele == "2":
            biletes_id = int(input("Ievadi biļetes ID: "))
            pircēja_vārds = input("Ievadi pircēja vārdu: ")
            sedvieta = input("Ievadi sēdvietas numuru: ")
            rezultats = pievienot_bileti(biletes_id, pircēja_vārds, sedvieta, biletes, aiznemtas_sedvietas)
            print(f"Rezultāts: {rezultats}")
        
        elif izvele == "3":
            sedvieta = input("Ievadi sēdvietas numuru: ")
            rezultats = vai_sedvieta_aiznemta(sedvieta, aiznemtas_sedvietas)
            if rezultats == True:
                print("Sēdvieta ir aizņemta")
            elif rezultats == False:
                print("Sēdvieta nav aizņemta")
            else:
                print(rezultats)  # Parāda ziņu, ka sēdvieta nav reģistrēta
        
        elif izvele == "4":
            vards = input("Ievadi apmeklētāja vārdu: ")
            virziens = input("No kuras puses pievienot? (sākums/beigas): ").strip().lower()
            no_priekspuses = virziens == "priekša"
            ienakt_rinda(vards, rinda, no_priekspuses)
            print(f"Apmeklētājs {vards} pievienots rindā. Rinda: {list(rinda)}") #atgriež rindu kā sarakstu
        
        
        elif izvele == "5":
            rezultats = aiznemto_sedvietu_skaits(aiznemtas_sedvietas)
            print(f"Kopējais aizņemto sēdvietu skaits: {rezultats}")
        
        elif izvele == "6":
            print("Programma beidzas. Uz redzēšanos!")
            break
        
        else:
            print("Nepareiza izvele. Mēģini vēlreiz.")

