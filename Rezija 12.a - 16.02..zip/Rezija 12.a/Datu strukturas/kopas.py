klubsA={"Jānis","Roberts","Romija","Marks","Katrīna"} #futbols
klubsB={"Romija","Evelīna","Jānis","Emīls","Gunārs"} #literatūra
klubsC={"Marks","Ludvigs","Jānis","Elīza","Katrīna"} #gambling

#kuri dalībnieki ir visos 3 klubos
visi_klubi=klubsA.intersection(klubsB,klubsC)
print("Dalībnieki visos klubos: ",*visi_klubi)

#intersection-update: atstāt tikai kopīgos elementus
temp=klubsA.copy()
temp.intersection_update(klubsB)
print("A un B kopīgie elementi: ",temp)

#dalībnieki vizmaz vienā no klubiem
viens=klubsA.union(klubsB,klubsC)
print("Dalībnieki vismaz vienā no klubiem: ",viens)

#metode add-pievionot jaunu elementu kopai A
klubsA.add("Artūrs")
print("Jaunais sastāvs klubam A: ",klubsA)

#metode discard-noņemt vienu elementu kapai C
klubsC.discard("Katrīna")
print("Jaunais sastāvs klubam C: ",klubsC)

#elemti, kas ir A, bet nav B un C
rez=klubsA.difference(klubsB,klubsC)
print("Ir A, bet nav B un C: ",rez)

#izņemt no A to, kas ir B un C
temp2=klubsA.copy()
temp2.difference_update(klubsB,klubsC)
print("Izņem visu no A, kar ir B un C: ",temp2)

#atstāt tikai kopīgos klubsA elementus ar B un C
temp3=klubsA.copy()
temp3.intersection_update(klubsB,klubsC)
print("Kopīgais no A ar B un C: ", temp3)