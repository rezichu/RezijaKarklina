#uzrakstīt funkciju, kas izprintē saraksta garumu un visus elementus ar for ciklu
#pievenot sarakstam elementu
#izņemt 3.elementu
#pēc katras darbības izsaukt funkciju

def drukaSarakstu(saraksts):
    print("Saraksta garums=", len(saraksts))
    for i in saraksts:
        print(i)
    print()

saraksts=["Vārds","Gulbis","Žagata"]
drukaSarakstu(saraksts)

saraksts.append("Kaija")
drukaSarakstu(saraksts)

saraksts.pop(2)
drukaSarakstu(saraksts)

#izveido sarakstu ar 5 pilsētu nosaukumiem un atrast visgarāko nosaukumu
pilsetas=["Sigulda","Rīga","Valmiera","Saulkrasti","Ogre"]
visgarakais=max(pilsetas,key=len)
print("Visgarākais pilsētas nosaukums: ",visgarakais)

#apvienot abus sarakstus
apvienots_saraksts=saraksts+pilsetas
print("Apvienots: ",apvienots_saraksts)