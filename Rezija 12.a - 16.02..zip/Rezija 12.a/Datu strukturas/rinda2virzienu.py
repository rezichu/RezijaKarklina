#divvierziena rinda - autobuss, kur pasažieri var izkāpt pa abām pusēm
from collections import deque

autobuss=deque()

#pasa;zieri kāpj
autobuss.append("Anna")
autobuss.append("Jānis")
autobuss.appendleft("Šoferis") #kāpj pa priekšējām durvīm
autobuss.append("Pēteris")

print("Autobusā: ",autobuss)

print("Izkāpj: ",autobuss.popleft()) #šoferis
print("Izkāpj: ",autobuss.pop()) #Pēteris

#vienvirziena rinda
#Pusdiena rinda skolā
rinda=[]
rinda.append("Anna")
rinda.append("Jānis")
rinda.append("Pēteris")

print(rinda)
#apkalpo 2 skolēnus
apkalpots1=rinda.pop(0)
apkalpots2=rinda.pop(0)

print("Palika rindā: ",rinda)