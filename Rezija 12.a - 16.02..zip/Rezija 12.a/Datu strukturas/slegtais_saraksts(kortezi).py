tukss_tuple=()

#saraksts ar 1 elementu
viens_el=(5,) #1 elements sarakstā, komatam jābūt

vairak_el=(1,2,3)

dati=(10,20,30)
print(dati[0])
print(dati[-1])

#dati[0]=15 #šis nestrādās

#lielotājs ievada datus kortežā
ievade=input("Ievadi korteža elementus: ")
ievaddati=tuple(ievade.split(","))
print("Izveidotai saraksts: ",ievaddati)
