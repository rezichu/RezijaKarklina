import sqlite3
from datetime import datetime

savienojums = sqlite3.connect("Rezija_datubaze.db")
cursor = savienojums.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS pasakumi(
    pasakumi_id INTEGER PRIMARY KEY AUTOINCREMENT,
    nosaukums TEXT NOT NULL,
    datums INTEGER NOT NULL,
    vieta TEXT NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS dalibnieki(
    dalibnieki_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards TEXT NOT NULL,
    uzvards TEXT NOT NULL,
    vecums INTEGER NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS registracijas(
    registracijas_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pasakumi_id INTEGER NOT NULL,
    dalibnieki_id INTEGER NOT NULL,
    statuss TEXT NOT NULL,
    FOREIGN KEY (pasakumi_id) REFERENCES pasakumi(pasakumi_id) ON DELETE CASCADE,
    FOREIGN KEY (dalibnieki_id) REFERENCES dalibnieki(dalibnieki_id) ON DELETE CASCADE
)
""")

def ievade_jn(atbildes): #Pārbauda lietotāja atbildi
    while True:
        atbilde=input(atbildes).lower()
        if atbilde in ["j","n"]:
            return atbilde
        print("Ievadi tikai 'j' vai 'n'!")
def ievadi_teksts(teksts):
    while True:
        ievade=input(teksts).strip()
        if ievade=="":
            print("Kļūda: nevar būt tukšs!")
        else:
            return ievade
def ievadi_skaitli(teksts):
    while True:
        try:
            ievade=int(input(teksts))
            if ievade<0:
                print("Kļūda: jāievada pozitīvs skairlis!")
            else:
                return ievade
        except ValueError:
            print("Kļūda: jāievada vesels skaitlis!")
def ievadi_datumu(ievade):
    while True:
        datums_txt=input(ievade)
        try:
            datums = datetime.strptime(datums_txt,"%Y-%m-%d").date()
            if datums<datetime.now().date():
                print("Kļūda: datums nedrīks būt pagātnē!")
            else:
                break
        except ValueError:
            print("Kļūda: nepareizs datums formāts!")
def pasakuma_id_eksiste(pasakuma_id):
    cursor.execute(
        """SELECT COUNT(*) FROM pasakumi WHERE pasakumi_id=?""",
        (pasakuma_id,))
    return cursor.fetchone()[0]>0
def dalibnieka_id_eksiste(dalibnieka_id):
    cursor.execute(
        """SELECT COUNT(*) FROM dalibnieki WHERE dalibnieki_id=?""",
        (dalibnieka_id,))
    return cursor.fetchone()[0]>0


while True:
    turpinat=ievade_jn("Vai vēlaties pievienot datus?(j/n): ")
    if turpinat=="n":
        break

    pasakumu_skaits=0
    while True:
        nosaukums = ievadi_teksts("Ievadiet pasākuma nosaukumu: ")
        datums=input("Ievadi pieraksta datumu(YYYY-MM-DD): ")
        vieta = ievadi_teksts("Ievadiet pasākuma vietu: ")
        cursor.execute(
            """INSERT INTO pasakumi(nosaukums,datums,vieta) VALUES(?,?,?)""",
            (nosaukums,datums,vieta))
        savienojums.commit()
        pasakumu_skaits+=1
        print("Pasākums pievienots!\n")
        if pasakumu_skaits>1:
            turpinat=ievade_jn("Vai pievienot vēl pasākumus?(j/n): ")
            if turpinat=="n":
                break
            else:
                pasakumu_skaits=0
                continue

    dalibnieku_skaits=0
    while True:
        vards = ievadi_teksts("Ievadiet dalībnieka vārdu: ")
        uzvards = ievadi_teksts("Ievadiet dalībnieka uzvārdu: ")
        vecums = ievadi_skaitli("Ievadiet dalībnieka vecumu: ")
        cursor.execute(
            """INSERT INTO dalibnieki(vards,uzvards,vecums) VALUES(?,?,?)""",
            (vards,uzvards,vecums))
        savienojums.commit()
        dalibnieku_skaits+=1
        print("Dalībnieks pievienots!\n")
        if dalibnieku_skaits>1:
            turpinat=ievade_jn("Vai pievienot vēl dalībniekus?(j/n): ")
            if turpinat=="n":
                break
            else:
                dalibnieku_skaits=0
                continue

    registraciju_skaits=0
    while True:
        while True:
            pasakuma_id = ievadi_skaitli("Ievadiet pasākuma ID: ")
            if pasakuma_id_eksiste(pasakuma_id):
                break
            else:
                print("Kļūda: tāda pasākuma ID nav!")
        while True:
            dalibnieka_id = ievadi_skaitli("Ievadiet dalībnieka ID: ")
            if dalibnieka_id_eksiste(dalibnieka_id):
                break
            else:
                print("Kļūda: tāda dalībnieka ID nav!")
        statuss = ievadi_teksts("Ievadiet reģistrācijas statusu: ")
        cursor.execute(
            """INSERT INTO registracijas(pasakumi_id,dalibnieki_id,statuss) VALUES(?,?,?)""",
            (pasakuma_id,dalibnieka_id,statuss))
        savienojums.commit()
        registraciju_skaits+=1
        print("Dalībnieks pievienots!\n")
        if registraciju_skaits>1:
            turpinat=ievade_jn("Vai pievienot vēl reģistrācijas?(j/n): ")
            if turpinat=="n":
                break
            else:
                registraciju_skaits=0
                continue

print("\nVisi pasākumi:") #1)
cursor.execute("SELECT*FROM pasakumi")
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"ID:{r[0]} - Pasākums:{r[1]}, Datums:{r[2]}, Vieta:{r[3]}")

print("\nVisi dalībnieki, kas vecāki par 17:") #2)
cursor.execute(
    """SELECT*FROM dalibnieki
    WHERE vecums>=17"""
)
rezultati=cursor.fetchall()
if len(rezultati)==0:
    print("Nav datu!")
else:
    for r in rezultati:
        print(f"ID:{r[0]} - Dalībnieks:{r[1]} {r[2]}, Vecums:{r[3]}")

print("\nVisi pasākumu uz kuriem ir reģistrējušies dalībnieki:") #3)
cursor.execute(
    """SELECT
        vards, uzvards, nosaukums
    FROM registracijas
    JOIN dalibnieki ON registracijas.dalibnieki_id=dalibnieki.dalibnieki_id
    JOIN pasakumi ON registracijas.pasakumi_id=pasakumi.pasakumi_id
    ORDER BY vards ASC"""
)
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"Dalībieks:{r[0]} {r[1]}, Pasākums:{r[2]}")

print("\nDalībnieku skaits pie katra pasākuma:") #4)
cursor.execute(
    """SELECT
        nosaukums, COUNT(vards) AS dalibnieku_sk
    FROM registracijas
    JOIN dalibnieki ON registracijas.dalibnieki_id=dalibnieki.dalibnieki_id
    LEFT JOIN pasakumi ON registracijas.pasakumi_id=pasakumi.pasakumi_id
    GROUP BY nosaukums"""
)
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"Pasākums:{r[0]} Dalībnieku skaits:{r[1]}")

print("\nVisi pasākumi uz kuriem pieteikušies vairāk nekā 3 dalībnieki:")
cursor.execute(
    """SELECT
        nosaukums, COUNT(registracijas.dalibnieki_id) AS dalibnieku_sk
    FROM registracijas
    JOIN dalibnieki ON registracijas.dalibnieki_id=dalibnieki.dalibnieki_id
    JOIN pasakumi ON registracijas.pasakumi_id=pasakumi.pasakumi_id
    GROUP BY nosaukums
    HAVING dalibnieku_sk>3"""
)
rezultati=cursor.fetchall()
if len(rezultati)==0:
    print("Nav datu!")
else:
    for r in rezultati:
        print(f"Pasākums:{r[0]} Dalībnieku skaits:{r[1]}")

print("\nPasākumu skaits, kas ir vairāk par 2:")
cursor.execute(
    """SELECT
        vieta, COUNT(registracijas.pasakumi_id) AS pasakumu_sk
    FROM registracijas
    JOIN dalibnieki ON registracijas.dalibnieki_id=dalibnieki.dalibnieki_id
    JOIN pasakumi ON registracijas.pasakumi_id=pasakumi.pasakumi_id
    GROUP BY vieta
    HAVING pasakumu_sk>1"""
)
rezultati=cursor.fetchall()
if len(rezultati)==0:
    print("Nav datu!")
else:
    for r in rezultati:
        print(f"Vieta:{r[0]} Pasākumu skaits:{r[1]}")