import sqlite3

savienojums = sqlite3.connect("sports_risinajums.db")
cursor = savienojums.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS sportisti(
    sportisti_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards TEXT NOT NULL,
    uzvards TEXT NOT NULL,
    vecums INTEGER NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS nodarbibas(
    nodarbibas_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sportisti_id TEXT NOT NULL,
    veids TEXT NOT NULL,
    ilgums INTEGER NOT NULL,
    FOREIGN KEY (sportisti_id) REFERENCES sportisti(sportisti_id) ON DELETE CASCADE
)
""")

#papildfunkcijas datu pārbaudei(lai nav tukšs teksts, lai ir skaitlis un lai eksistē id)
#neļauj atstāt tukšu lauku pie teksta ievades
def ievade_jn(atbildes): #Pārbauda lietotāja atbildi
    while True:
        atbilde=input(atbildes).lower()
        if atbilde in ["j","n"]:
            return atbilde
        print("Ievadi tikai 'j' vai 'n'!")
def ievadi_teksts(teksts):
    while True:
        ievade=input(teksts).strip()
        if ievade=="":
            print("Kļūda: nevar būt tukšs!")
        else:
            return ievade
def ievadi_skaitli(teksts):
    while True:
        try:
            ievade=int(input(teksts))
            return ievade
        except ValueError:
            print("Kļūda: jāievada vesels skaitlis!")
#pārbauda vai sportista id eksistē
def sportista_id_eksiste(sportista_id):
    cursor.execute(
        """SELECT COUNT(*) FROM sportisti WHERE sportisti_id=?""",
        (sportista_id,))
    return cursor.fetchone()[0]>0

sportistu_skaits=0
while sportistu_skaits<5:
    turpinat=ievade_jn("Vai pievienot vēl klientu?(j/n): ")
    if turpinat=="n":
        break
    print("---Pievienojiet sportistu---")
    vards = ievadi_teksts("Ievadiet sportista vārdu: ") #Nosūta uz funkciju ievadi_teksts
    uzvards = ievadi_teksts("Ievadiet sportista uzvārdu: ")
    vecums = ievadi_skaitli("Ievadiet sportista vecumu: ") #Nosūta uz funkciju ievadi_skaitli
    cursor.execute(
        """INSERT INTO sportisti(vards,uzvards,vecums) VALUES(?,?,?)""",
        (vards,uzvards,vecums))
    savienojums.commit()
    sportistu_skaits+=1
    print("Sportists pievienots!\n")

nodarbibu_skaits=0
while nodarbibu_skaits<=5:
    turpinat=ievade_jn("Vai pievienot vēl klientu?(j/n): ")
    if turpinat=="n":
        break
    print("---Pievienojiet nodarbibu---")
    while True:
        sportista_id = ievadi_skaitli("Ievadiet sportista id: ")
        if sportista_id_eksiste(sportista_id):
            break
        else:
            print("Kļūda: tāda sportista ID nav!")
    veids = ievadi_teksts("Ievadiet nodarbibas veidu: ")
    ilgums = ievadi_skaitli("Ievadiet nodarbibas ilgumu(min): ")
    cursor.execute("INSERT INTO nodarbibas(sportisti_id,veids,ilgums) VALUES(?,?,?)",(sportista_id,veids,ilgums))
    savienojums.commit()
    nodarbibu_skaits+=1
    print("Nodarbiba pievienota!\n")

print("\nKatra sportista kopējo nodarbību skaits:")
cursor.execute(
    """SELECT
        sportisti.vards,
        sportisti.uzvards,
        COUNT(nodarbibas.nodarbibas_id) AS Nodarbibu_skaits
    FROM sportisti LEFT JOIN nodarbibas ON sportisti.sportisti_id=nodarbibas.sportisti_id
    GROUP BY sportisti.sportisti_id;""") #left join ir lai atgriež pat ja sportistam nav nodarbības (nav datu)
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"{r[0]} {r[1]} - nodarbību skaits: {r[2]}")

print("\nParādīt tos sportistus, kuri kopā pavadījuši 120min trenējoties:")
cursor.execute(
    """SELECT
        sportisti.vards,
        sportisti.uzvards,
        SUM(nodarbibas.ilgums) AS Nodarbibas_ilgums_min
    FROM sportisti JOIN nodarbibas ON sportisti.sportisti_id=nodarbibas.sportisti_id
    GROUP BY sportisti.sportisti_id
    HAVING Nodarbibas_ilgums_min>=120;""")
rezultati=cursor.fetchall()
if len(rezultati)==0:
    print("Nav datu!")
else:
    for r in rezultati:
        print(f"{r[0]} {r[1]} - kopā {r[2]} minūtes")

print("\nParādīt TOP 3 sportistus pēc treniņu laika:")
cursor.execute(
    """SELECT
        sportisti.vards,
        sportisti.uzvards,
        SUM(nodarbibas.ilgums) AS Nodarbibas_ilgums_min
    FROM sportisti LEFT JOIN nodarbibas ON sportisti.sportisti_id=nodarbibas.sportisti_id
    GROUP BY sportisti.sportisti_id
    ORDER BY Nodarbibas_ilgums_min DESC LIMIT 3;""")
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"{r[0]} {r[1]} - kopā {r[2]} minūtes")