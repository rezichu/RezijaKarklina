# Funkcija, kas ļauj lietotājam ievadīt prasītos datus un saglabā tos vārdnīcā
def ievads():
    liet_info = {} # Tiek izveidota tukša vārdnīca
    print(" Informācija par lietotāju! ")
    print(" * * * * * * * *")
    liet_info['vards'] = input("Ievadiet savu vārdu: ")
    
    while True:
        
        try:
            liet_info['vecums']= int(input("Ievadiet savu vecumu: "))
            break 
        except ValueError: # Pārbauda vai ievadīta pareiza vērtība
            print("Ievadiet pareizu vecumu!") # Ja ievadīta nepareiza vērtība, tad konkrētais jautājums tiek uzdots vēlreiz līdz ievadīta atbilstoša vērtība
    while True:
        try:
            liet_info['svars'] = float(input("Ievadiet savu svaru (kg): "))
            break
        except ValueError:
            print("Ievadiet pareizu svaru!")
    while True:
        try:
            liet_info['augums'] = float(input("Ievadiet savu augumu (m): "))
            break
        except ValueError:
            print("Ievadiet pareizu augumu!")
    print(liet_info)
ievads()

# Funkcija, kas pēc lietotāja iepreikš ievadītās informācijas, aprēķina lietotāja ĶMI (Ķermeņas masas indekss)
#def kmi_aprekins():
   
def liet_merkis():
    while True:
        print(" * * * * * * * *")
        print(" Lietotāja mērķi! ")
        print(" * * * * * * * *")
        try:
            merka_info = {}
            merkis = int(input('Ievadiet savu mērķi(soļu skaits): '))
            kalorijas = int(input('Ievadiet savu mērķi(kaloriju skaits): '))
            udens = int(input('Ievadiet savu mērķi(ūdens daudzums/l): '))
            print(" * * * * * * * *")
            merka_info.update({"Jūsu soļu mērķis": merkis, "Mērķa kalorijas": kalorijas, "Mērķa ūdens daudzums": udens})
            print(str(merka_info).replace("{","").replace("}", "").replace("'","").replace("'", ""))
            print('\n ')
            izvele = input('Vai vēlaties saglabāt datus failā?(j/n): ')
            if izvele == 'j':
                with open('merkis.txt','w',encoding='utf-8') as fails:
                    fails.write(str(merka_info).replace("{","").replace("}", "").replace("'","").replace("'", ""))
                    print('Dati ir saglabāti failā!\n')
                    break
            elif izvele == 'n':
                print('Faili netiek saglabāti failā!\n')
                break
            else:
                print('Nav ievadīti pareizie dati!\n')
                continue
        except ValueError:
            print('Nav ievadīti pareizie dati!\n')
            continue
    
liet_merkis()
            
def akt_datu_saglabasana(svars):
    while True:
        try:
            noietais = int(input('Cik km jūs esat jau veikuši?: '))
            laiks = int(input('Cik ilgā laikā jūs to veicāt?: '))
            izdzertais = int(input('Cik ūdeni jūs izdzērāt veicot aktivitāti?: '))
            soli_uz_km = noietais*(1/1500)
            met = 3.2*3.5*svars/200
            print('\n ')
            with open('aktivitates_dati.txt','w',encoding='utf-8') as fails:
                fails.write({'Noietie km':soli_uz_km,'Zaudētās kalorijas':met, 'Laiks': laiks, 'Izlietotais ūdens daudzums': izdzertais })
                print('Dati saglabāti failā!')
                break
        except ValueError:
            print('Nav ievadīti pareizie dati!\n')
            continue

akt_datu_saglabasana()
#1 kcal/kg/hour


def iestaditie_koki():
    noietie_km = 23
    jauni_km = 12
    for i in range(noietie_km):
        koku_skaits = noietie_km*i 
    print("Jūsu iestādītais koku skaits: ", koku_skaits )
    if noietie_km >= 100:
        print("* * * * * * * *")
        print("Jūsu noietie km ir vairāk par 100km vai tieši 100km. . .")
        print("Jums ir iespēja nosaukt kādu no iestādītajiem kokiem!")
        koka_vards = input("Ievadiet sev vēlamo koka vārdu: ")
        print("Lieliski!", koka_vards, "sūta jums sveicienus. ")
    fails = input('Vai vēlaties saglabāt info failā? (J/N): ')    
    if fails == "J":
        f = open("iestaditie_koki.txt", "w", encoding="utf-8")
        f.write("Koku skaits: " + str(koku_skaits))
        f.write("KM atjaunināti: ", noietie_km + jauni_km)

iestaditie_koki()
