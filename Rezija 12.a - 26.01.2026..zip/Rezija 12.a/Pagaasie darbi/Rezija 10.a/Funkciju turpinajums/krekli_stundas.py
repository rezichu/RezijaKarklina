try:
    skaits = int(input('Skaits: '))
    apdruka = int(input('Apdruka: \n1 - Teksts(5 EUR) \n2 - Zīme (7 EUR) \n3 - Foto(20 EUR) \n:'))
except ValueError:
    print('Jāievada skaitlis.')
    exit()
piegade = input('Ar piegādi? (j/n): ')
if piegade not in ['j','n'] or apdruka not in [1,2,3] or skaits < 0: #pārbauda ievadi
    print('Ievadīt pareizus datus.')
    exit()

if piegade == 'j':
    piegade = True
else:
    piegade = False

def pasuti_tkreklus(skaits,apdruka,piegade):
    krekli = skaits * [5,7,20] [apdruka - 1] #aprēķina cenu bez atlaides
    #aprēķina piegādes maksu
    if krekli >= 50 and piegade == True:
        piegade = 0
    elif krekli < 50 and piegade == True:
        piegade = 15
    else:
        piegade = 'Nav.'
    #aprēķina atlaidi
    if krekli >= 100:
        atlaide = round(krekli*0.05,2)
    else:
        atlaide = 0

    kopsumma = krekli - atlaide
    if type(piegade) != str:
        kopsumma = kopsumma + piegade
    if type(piegade) != int:
        piegade(str(float(piegade)) + 'EUR')
    return [krekli,piegade,atlaide,kopsumma]

rez = pasuti_tkreklus(skaits,apdruka,piegade)
print('------IZMAKSAS------')
print('Kōpējā cena - ', rez[3], 'EUR \n', 'Krekli -', float(rez[0]), 'EUR \nPiegāde - ', rez[1], 'Atlaide - ', rez[2], 'EUR')