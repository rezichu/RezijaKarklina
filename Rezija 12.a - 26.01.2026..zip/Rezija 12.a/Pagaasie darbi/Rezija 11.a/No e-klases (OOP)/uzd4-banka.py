class BankasKonts:
    def __init__(self, vards, atlikums): #konstruktors ar 2 parametriem
        self.vards=vards #lauki
        self.atlikums=atlikums
        
    #metode iemaksai
    def iemaksat(self,summa):
        self.atlikums+=summa #palielina atlikumu
        return f"Iemaksāti {summa} EUR. Jaunais atlikums: {self.atlikums} EUR."
    
    def iznemt(self,summa):
        #pārbauda vai kontā pietiek līdzekļu
        if summa>self.atlikums:
            return "Nepietiek līdzekļu!"
        self.atlikums-=summa #samazina konta alikumu
        return f"Izņemti {summa} EUR. Jaunais atlikums: {self.atlikums} EUR."

konts=BankasKonts("Laura",100)#izveido objektu klasei BankasKonts

print(konts.iemaksat(50))
print(konts.iznemt(30))
print(konts.iznemt(200))