#bāzes Transportlidzeklis
class Transportlidzeklis:
    def parvietoties(self):
        print("Transportlīdzklis pārvietojas")  # Noklusētā metode


#atvasinātā klase
class Auto(Transportlidzeklis):
    def parvietoties(self):
        print("Auto brauc pa ceļu")  #Pārraksta metodi, lai atbilstu auto(manto no bāzes klases)


#atvasinātā klase
class Velosipēds(Transportlidzeklis):
    def parvietoties(self):
        print("Velosipēds brauc pa taku")  #Pārraksta metodi, lai atbilstu auto(manto no bāzes klases)


#atvasinātā klase
class Lidmašīna(Transportlidzeklis):
    def parvietoties(self):
        print("Lidmašīna lido pa gaisu")  #Pārraksta metodi, lai atbilstu auto(manto no bāzes klases)


#izveido sarakstu ar transportlidzekliem
transportlidzekli = [Auto(), Velosipēds(), Lidmašīna()]

#ar for ciklu izsauc metodes
for Transportlidzeklis in transportlidzekli:
    Transportlidzeklis.parvietoties()

#Auto brauc pa ceļu
#Velosipēds brauc pa taku
#Lidmašīna lido pa gaisu