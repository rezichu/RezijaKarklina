nosaukums = "pilsetas.txt"
def iegut_datus():
    print("Lūdzu ievadiet 10 Latvijas pilsētas.")
    with open(nosaukums,"w",encoding='utf8')as fails:
        for i in range(1,11): #Atļauj lietotājam ievadīt 10 pilsētas ar for ciklu
            pilseta = input(f"Ievadiet {i}. pilsētu: ")
            fails.write(pilseta+"\n")
iegut_datus()

def paradit_datus():
    try:
        with open(nosaukums,"r",encoding='utf8')as fails:
            print("\nFaila saturs: ")
            for i in fails:
                print(i.strip()) #Izprintē datus konsolē, strip noņem liekās atstarpes
            print("----------------------")
    except FileNotFoundError:
        print(f"Fails {nosaukums} nav atrasts!")
paradit_datus()

def sakartoti_dati():
    try:
        with open(nosaukums,"r",encoding='utf8')as fails:
            saturs = fails.read()
        kartot = sorted(saturs+"\n") #Sakārto datus un izvada konsolē
        print(kartot)
    except FileNotFoundError:
        print(f"Fails {nosaukums} nav atrasts!")
sakartoti_dati()

def papildus_pievienot():
    print("Lūdzu ievadiet vēl papildus 3 Latvijas pilsētas.")
    try:
        with open(nosaukums,"a",encoding='utf8')as fails:
            for i in range(1,4):
                pilseta = input(f"Ievadiet {i}. pilsētu: ")
                fails.write(pilseta)
    except FileNotFoundError:
        print(f"Fails {nosaukums} nav atrasts!")
#papildus_pievienot()