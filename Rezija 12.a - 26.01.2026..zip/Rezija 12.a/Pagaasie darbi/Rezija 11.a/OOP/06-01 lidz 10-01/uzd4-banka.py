#izveidot klasi BankasKonts
#ielikt 2 atribūtus-klienta vārds un atlikums
#klasē ir 2 metodes-iemaksat(summa)-palielinās konta atlikumu ar norādīto summu
#metode iznemt (summa)-samazina konta atlikumu par norādīto summu, ja pieliek līdzekļu
#objekti-klienta Laura sākumā ir 100 eiro |
#iemaksā 50, pārbauda atlimuku |
#izņem 30, pēc tam izņem 200, lai notestētu gadījumu, kad nav līdzekļu

class BankasKonts:
    def __init__(self,vards,atlikums):
        self.vards = vards
        self.atlikums = atlikums
    
    def iemaksas_un_izmaksas(self):
        return f"{self.vards} kontā ir {self.atlikums} eiro!"

while True:
    vards = "Laura"
    