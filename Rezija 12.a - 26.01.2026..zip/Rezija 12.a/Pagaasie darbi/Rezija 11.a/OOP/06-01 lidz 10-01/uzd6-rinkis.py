class Rinkis:
    def __init__(self,radiuss): #konstruktors ar parametru rādiuss
        self.radiuss = radiuss

    def istatit_radiusu(self): #uzstāda jaunu radiusu, ja rādiuss ir nulle vai negatīvs, tad uzstāda noklusējuma rādiusu
        pass

    def izvadit_radiusu(self): #izvada rādiusu
        pass

    def diametrs(self): #aprēķina diametru un izrēķina to
        pass

