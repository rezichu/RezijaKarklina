class Trijsturis(): #vienkāršs konstruktors
    def __init__(self):
        self.mala = 6
    def drukat_perimetru(self):
        print("Perimetrs:", self.mala * 3)

objekts = Trijsturis()
objekts.drukat_perimetru()