class Persona: #bāzes klase
    def __init__(self,vards,uzvards,epasts):
        self.vards = vards
        self.uzvards = uzvards
        self.epasts = epasts
    def druka_vardu(self):
        print("Šo personu sauc: ", self.vards)

class Skolens(Persona): #atvasinātā klase
    def __init__(self,vards,uzvards,epasts,vid_atzime = 0):
        super().__init__(vards,uzvards,epasts) #automātiski izsauc bāzes klases konstruktoru
        self.vid_atzime = vid_atzime
    def macities(self):
        self.vid_atzime += 0.1

class Skolotajs(Persona):
    def __init__(self,vards,uzvards,epasts,mac_prieksmets):
        super().__init__(vards,uzvards,epasts)
        self.mac_prieksmets = mac_prieksmets
    def macit(self):
        print(f"Mācu {self.mac_prieksmets}!")

#izveidot objektus abām atvasinātajām klasēm
skolens1 = Skolens("Jānis","Bērziņš","janis.berzins@svg.lv",vid_atzime=8.5)
print(skolens1.epasts)

skolens1.macities()
print(skolens1.vid_atzime)

skolotajs = Skolotajs("Jēkabs","Ābele","jekabs.abele@svg.lv","latviešu valodu")
print(skolotajs.vards)
skolotajs.macit()