import csv #importē csv

def parbaudit_vardu(vards): #pārbauda 
    return vards.isalpha()

def parbaudit_epastu(epasts):
    return "@" in epasts and "." in epasts

def parbaudit_skaitli(vertiba):
    return vertiba.isdigit() and int(vertiba) >= 0

def parbaudit_jane(vertiba):
    return vertiba.lower() in ["jā", "nē"]

class Klients:
    def __init__(self):
        self.vards = ""
        self.uzvards = ""
        self.epasts = ""
        self.apmekl_biez = 0
        self.pavad_laiks = 0
        self.socialie_medij = False
        self.jauni_klienti = 0
        self.kop_punkti = 0
        self.atlaide = 0
        self.nosaukums = ""
        self.davanas_saraksts = []

    def klienta_info(self, vards, uzvards, epasts):
        self.vards = vards
        self.uzvards = uzvards
        self.epasts = epasts
        self.nosaukums = f"{vards}_{uzvards}.csv"

    def klienta_apmekl_biez(self, apmekl_biez):
        self.apmekl_biez = int(apmekl_biez)

    def klienta_pavad_laiks(self, pavad_laiks):
        self.pavad_laiks = int(pavad_laiks)

    def klienta_socialie_medij(self, socialie_medij):
        self.socialie_medij = socialie_medij.lower() == "jā"

    def jaun_sporta_kluba_klient(self, skaits):
        self.jauni_klienti = int(skaits)

    def punktu_aprek(self):
        punkti_apmeklejumi = self.apmekl_biez * 10
        punkti_laiks = self.pavad_laiks * 1
        punkti_socialie = 100 if self.socialie_medij else 0
        punkti_jauns = 200 if self.jauni_klienti >= 1 else 0
        punkti_papildus = self.jauni_klienti * 100 if self.jauni_klienti > 1 else 0

        self.kop_punkti = punkti_apmeklejumi + punkti_laiks + punkti_socialie + punkti_jauns + punkti_papildus


    def atlaides(self):
        self.atlaide = round(self.kop_punkti / 40, 3)

    def piedava_davanas(self):
        davanu_piedavajumi = {
            "Pudele": 500,
            "Sporta soma": 750,
            "Termoss": 910,
            "Vingrošanas paklājs": 1000
        }
        saraksts = list(davanu_piedavajumi.items())

        while True:
            print("\nPieejamās dāvanas:")
            for i in range(len(saraksts)):
                nosaukums, punkti = saraksts[i]
                print(f"{i + 1}. {nosaukums} - {punkti} punkti")
            print("0. Neko neizvēlēties")

            izvele = input("Izvēlies dāvanu (ievadi numuru): ")
            if izvele.isdigit():
                izvele = int(izvele)
            else:
                print("Lūdzu, ievadiet derīgu skaitli.")
                continue

            if izvele == 0:
                self.davanas_saraksts.append("nav")
                print("Jūs neizvēlējāties nevienu dāvanu.")
                break
            elif 1 <= izvele <= len(saraksts):
                nosaukums, punkti = saraksts[izvele - 1]
                if self.kop_punkti >= punkti:
                    self.kop_punkti -= punkti
                    self.davanas_saraksts.append(nosaukums)
                    print(f"{nosaukums} piešķirta! Atlikušie punkti: {self.kop_punkti}")
                else:
                    print(f"Nepietiek punktu priekš {nosaukums}. Atlikušie punkti: {self.kop_punkti}")
                    self.davanas_saraksts.append(f"{nosaukums} (nav piešķirta)")
            else:
                print("Šāda izvēle nav pieejama.")
                continue

            if input("Vai vēlaties izvēlēties vēl kādu dāvanu? (jā/nē): ").strip().lower() != "jā":
                break

    def saglabat_csv(self):
        try:
            if not self.davanas_saraksts:
                self.davanas_saraksts.append("nav")
            with open(self.nosaukums, 'w', newline='', encoding='utf-8') as fails:
                writer = csv.writer(fails)
                writer.writerow(["Vārds", "Uzvārds", "Epasts", "Punkti", "Atlaide", "Dāvanas"])
                writer.writerow([self.vards, self.uzvards, self.epasts, self.kop_punkti, f"{self.atlaide} %", "; ".join(self.davanas_saraksts)])
            print(f"Tika izveidots fails: {self.nosaukums}")
        except Exception as e:
            print(f"Kļūda faila veidošanā: {e}")

# ====== GALVENAIS ======

def ievadit_klientu():
    klients = Klients()

    while True:
        vards = input("Ievadiet Jūsu vārdu: ")
        if parbaudit_vardu(vards): 
            break
        print("Vārdā drīkst būt tikai burti.")

    while True:
        uzvards = input("Ievadiet Jūsu uzvārdu: ")
        if parbaudit_vardu(uzvards): 
            break
        print("Uzvārdā drīkst būt tikai burti.")

    while True:
        epasts = input("Ievadiet Jūsu epastu: ")
        if parbaudit_epastu(epasts): 
            break
        print("Nederīgs epasta formāts.")

    klients.klienta_info(vards, uzvards, epasts)

    while True:
        apmeklejums = input("Cik bieži apmeklējat klubu mēnesī: ")
        if parbaudit_skaitli(apmeklejums):
            klients.klienta_apmekl_biez(apmeklejums)
            break
        else:
            print("Nepareiza vērtība! Lūdzu, ievadiet pozitīvu skaitli.")

    while True:
        laiks = input("Cik ilgu laiku pavadāt sporta klubā (minūtes): ")
        if parbaudit_skaitli(laiks):
            klients.klienta_pavad_laiks(laiks)
            break
        else:
            print("Nepareiza vērtība! Lūdzu, ievadiet pozitīvu skaitli.")

    while True:
        soc = input("Vai Jūs sekojat mūsu kluba sociālajiem mēdijiem? (jā/nē): ")
        if parbaudit_jane(soc):
            klients.klienta_socialie_medij(soc)
            break
        else:
            print("Ievadiet 'jā' vai 'nē'.")


    while True:
        piesaiste = input("Vai Jūs piesaistījāt jaunu klientu?(jā/nē): ")
        if parbaudit_jane(piesaiste):
            if piesaiste.lower() == "jā":
                while True:
                    skaits = input("Cik?: ")
                    if parbaudit_skaitli(skaits):
                        klients.jaun_sporta_kluba_klient(skaits)
                        break
            else:
                klients.jaun_sporta_kluba_klient(0)
            break

    klients.punktu_aprek()
    klients.atlaides()

    print(f"\nJūsu punktu skaits: {klients.kop_punkti}")
    print(f"Jūsu atlaide ir: {klients.atlaide} %")

    klients.piedava_davanas()
    klients.saglabat_csv()
    print("********************************\n")

# ====== PALAIŠANA ======

while True:
    ievadit_klientu()
    atk = input("Vai vēlaties pievienot vēl vienu klientu? (jā/nē): ")
    if atk.lower() != "jā":
        print("Programma beidzas.")
        break