import flet as ft


def main(page: ft.Page):
    def button_clicked(e):
        t.value = f"Checkboxes values are:  {c1.value}, {c2.value}, {c3.value}, {c4.value}, {c5.value}."
        page.update()

    t = ft.Text()
    c1 = ft.Checkbox(label="Unchecked by default checkbox", value=False)
    c2 = ft.Checkbox(label="Undefined by default tristate checkbox", tristate=True)
    c3 = ft.Checkbox(label="Checked by default checkbox", value=True)
    c4 = ft.Checkbox(label="Disabled checkbox", disabled=True)
    c5 = ft.Checkbox(
        label="Checkbox with rendered label_position='left'",
        label_position=ft.LabelPosition.LEFT,
    )
    b = ft.ElevatedButton(text="Submit", on_click=button_clicked)

    def checkbox_changed(e):
        page.add(ft.Text(f"Checkbox value changed to {c.value}"))
        page.update()

    c = ft.Checkbox(label="Checkbox with 'change' event", on_change=checkbox_changed)

    page.add(c1, c2, c3, c4, c5, b, t, c)

ft.app(main)

gi_gramata=ft.Dropdown(label="Izvēlies grāmatu")
gi_lasitajs=ft.Dropdown(label="Izvēlies grāmatu")
gi_datums=ft.TextField(label="Grāmatas izņemšanas datums")
def iznemtas_gramatas(_):
    cursor.execute(
        """SELECT lasitaji_id,vards,uzvards,klase
        FROM lasitaji
        ORDER BY uzvards,vards"""
    )
    lasitaji=cursor.fetchall()
    gi_lasitajs.options=[
        ft.dropdown.Option(
        key=str(r[0]),
        text=f"{r[1]}({r[2]},{r[3]})"
        )
        for r in lasitaji
    ]

        cursor.execute(
            """SELECT gramatas_id,nosaukums,autors,gads,zanrs
            FROM gramatas
            ORDER BY nosaukums"""
        )
        gramatas=cursor.fetchall()
        options=[]
        for r in gramatas:
            options.append(
                ft.dropdown.Option(
                    key=str(r[0]),
                    text=f"{r[1]}({r[2]},{r[3]},{r[4]})"
                )
            )
        gi_gramata.options=options
        page.update()



        gi_atdots=ft.Checkbox(label="Grāmata atdota?", value=False)
        if gi_atdots==False:
            atdots=0
        else:
            atdots=1