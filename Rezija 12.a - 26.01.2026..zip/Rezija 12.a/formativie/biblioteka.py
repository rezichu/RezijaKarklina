import flet as ft
import sqlite3

DB = "biblioteka.db"

def iegut_gramatas_pec_autora(autors: str):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    cur.execute("""
        SELECT nosaukums, autors, gads, zanrs
        FROM gramatas
        WHERE autors = ?
        ORDER BY gads DESC
    """, (autors,))
    dati = cur.fetchall()
    conn.close()
    return dati

def main(page: ft.Page):
    page.title = "Biblioteka"
    tf_autors = ft.TextField(label="Autors")