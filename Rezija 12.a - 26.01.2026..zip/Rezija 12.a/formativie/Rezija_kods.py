import sqlite3
from datetime import datetime

#Datubāzes izveide – pareiza
savienojums = sqlite3.connect("Rezija_sutijumi.db")
cursor = savienojums.cursor()

#tabulas ir pieteikami korektas, lai Tev nebūtu jālabo

cursor.execute("""
CREATE TABLE IF NOT EXISTS klienti(
    klienta_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards TEXT NOT NULL,
    telefons TEXT NOT NULL
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS sutijumi(
    sutijuma_id INTEGER PRIMARY KEY AUTOINCREMENT,
    klienta_id INTEGER NOT NULL,
    svars_kg REAL NOT NULL CHECK(svars_kg > 0),
    kategorija TEXT NOT NULL,
    FOREIGN KEY (klienta_id) REFERENCES klienti(klienta_id) ON DELETE CASCADE
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS statusi(
    statusa_id INTEGER PRIMARY KEY AUTOINCREMENT,
    sutijuma_id INTEGER NOT NULL,
    apraksts TEXT NOT NULL,
    datums TEXT NOT NULL,
    FOREIGN KEY (sutijuma_id) REFERENCES sutijumi(sutijuma_id) ON DELETE CASCADE
)
""")
savienojums.commit()

#sākumā pārliecināmies, vai tabulā jau ir dati(ja ir, tad neliek, lai šie testa dati netiku dublēti)
cursor.execute("SELECT COUNT(*)FROM klienti")
if cursor.fetchone()[0] == 0:
    klienti = [
        ("Anna", "22334455"),
        ("Jānis", "29998877"),
        ("Laura", "24445566"),
        ("Mārtiņš", "27776655"),
        ("Zane", "25553322")
    ]
    cursor.executemany(
        "INSERT INTO klienti(vards, telefons) VALUES (?, ?)", klienti
    )

cursor.execute("SELECT COUNT(*)FROM sutijumi")
if cursor.fetchone()[0] == 0:
    sutijumi = [
        (1, 2.5, "elektronika"),
        (2, 1.0, "apģērbi"),
        (3, 4.2, "kosmētika"),
        (4, 0.8, "elektronika"),
        (5, 3.6, "apģērbi")
    ]
    cursor.executemany(
        "INSERT INTO sutijumi(klienta_id, svars_kg, kategorija) VALUES (?, ?, ?)",
        sutijumi
    )

cursor.execute("SELECT COUNT(*)FROM statusi")
if cursor.fetchone()[0] == 0:
    statusi = [
        (1, "Pieņemts", "2025-01-10"),
        (2, "Ceļā", "2025-01-11"),
        (3, "Izsniegts", "2025-01-15"),
        (4, "Ceļā", "2025-01-16"),
        (5, "Pieņemts", "2025-01-17")
    ]
    cursor.executemany(
        "INSERT INTO statusi(sutijuma_id, apraksts, datums) VALUES (?, ?, ?)",
        statusi
    )

savienojums.commit()

def ievadi_teksts(teksts):
    while True:
        ievade=input(teksts).strip()
        if ievade=="": #pārbauda vai atbilde ir tukša
            print("Kļūda: nevar būt tukšs!")
        else:
            return ievade
def ievadi_skaitli(teksts):
    while True:
        try:
            ievade=int(input(teksts)) #pārbauda vai ievadītais skaitlis ir skaitlis un vesels
            if ievade<0: #pārbauda vai atbildē ir ievadīts pozitīvs skaitlis
                print("Kļūda: jāievada pozitīvs skaitlis!")
            else:
                return ievade
        except ValueError:
            print("Kļūda: jāievada vesels skaitlis!")
def ievadi_svaru(teksts):
    while True:
        try:
            ievade=float(input(teksts)) #pārbauda vai ievadītais skaitlis ir skaitlis
            if ievade<0: #pārbauda vai atbildē ir ievadīts pozitīvs skaitlis
                print("Kļūda: jāievada pozitīvs skaitlis!")
            else:
                return ievade
        except ValueError:
            print("Kļūda: jāievada skaitlis!")
def ievadi_telefona_nr(teksts):
    while True:
        if len(str(teksts))>12 or len(str(teksts))<8: #pārbauda ievadītā skaitļa garumu
            print("Kļūda: telefona numura garumam jābūt starp 8 un 12!")
        else:
            break
def ievadi_kategoriju(teksts):
    while True:
        kategorija=input(teksts).lower()
        if kategorija in ["elektronika","apģērbi","kosmētika"]: #parbauda, vai atbilde iekļaujas dotajās opcijās
            return kategorija
        print("Kļūda: jāievada viena no dotajām kategorijām!")
def ievadit_statusu(teksts):
    while True:
        status=input(teksts).lower()
        if status in ["ceļā","saņemts","izsniegts"]: #parbauda, vai atbilde iekļaujas dotajās opcijās
            return status
        print("Kļūda: jāievada viena no dotajām kategorijām!")
def ievadi_datumu(ievade):
    while True:
        datums_txt=input(ievade)
        try:
            if datums_txt != datetime.strptime(datums_txt, "%Y-%m-%d").strftime('%Y-%m-%d'): #pārbauda vai datums ir pareizi noformatēts
                print("Kļūda: nepareizs datums formāts!")
            else:
                return str(datums_txt)
        except ValueError:
            print("Kļūda: nepareizs datums formāts!")
def ievade_jn(atbildes): #Pārbauda lietotāja atbildi
    while True:
        atbilde=input(atbildes).lower()
        if atbilde in ["j","n"]: #parbauda, vai atbilde iekļaujas dotajās opcijās
            return atbilde
        print("Ievadi tikai 'j' vai 'n'!")

#uzrakstīt funkcijas pēc noteiktajiem kritērijeim
def ievadi_klientu():
    print("\n***Klienta datu ievade***")
    vards = ievadi_teksts("Ievadiet klienta vārdu: ")
    while True:
        telefona_nr = ievadi_skaitli("Ievadiet klienta telefona numuru: ")
        if len(str(telefona_nr))>12 or len(str(telefona_nr))<8: #pārbauda vai telefona numura garums ir starp 8 un 12
            print("Kļūda: telefona numura garumam jābūt starp 8 un 12!")
        else:
            break
    cursor.execute(
            """INSERT INTO klienti(vards,telefons) VALUES(?,?)""",
            (vards,telefona_nr))
    savienojums.commit() #saglabā izmaiņas datubāzē
    print("Klients pievienots!\n")
def ievadi_sutijumu():
    print("\n***Sūtijuma datu ievade***")
    while True: #ievadītā ID validēšana
        try:
            klienta_id = ievadi_skaitli("Ievadiet klienta ID: ")
            cursor.execute("SELECT COUNT(*) FROM klienti WHERE klienta_id=?",(klienta_id,))
            if cursor.fetchone()[0]>0:
                break #id pareizs-turpina
            else:
                print("Kļūda: jāievada ID, kas eksistē!")
        except ValueError:
            print("Kļūda: jāievada skaitlis!")   
    svars = ievadi_svaru("Ievadiet pasūtijuma svaru(kg): ")
    print('Dotās kategorijas: "elektronika", "apģērbi", "kosmētika"')
    kategorija = ievadi_kategoriju("Ievadiet sūtijuma kategoriju: ") #pārbauda vai lietotājs ievada vienu no 3 dotajām opcijām

    cursor.execute(
            """INSERT INTO sutijumi(klienta_id,svars_kg,kategorija) VALUES(?,?,?)""",
            (klienta_id,svars,kategorija))
    savienojums.commit() #saglabā izmaiņas datubāzē
    print("Sūtijums pievienots!\n")
def ievadi_statusu():
    print("\n***Statusa datu ievade***")
    while True: #ievadītā ID validēšana
        try:
            sutijuma_id = ievadi_skaitli("Ievadiet sūtijuma ID: ")
            cursor.execute("SELECT COUNT(*) FROM sutijumi WHERE sutijuma_id=?",(sutijuma_id,))
            if cursor.fetchone()[0]>0:
                break #id pareizs-turpina
            else:
                print("Kļūda: jāievada ID, kas eksistē!")
        except ValueError:
            print("Kļūda: jāievada skaitlis!")
    print('Dotie statusi: "Ceļā", "Saņemts", "Izsniegts"')
    status = ievadit_statusu("Ievadiet sūtijuma statusu: ") #pārbauda vai lietotājs ievada vienu no 3 dotajām opcijām
    datums = ievadi_datumu("Ievadiet sūtijuma datumu(YYYY-MM-DD): ")

    cursor.execute(
            """INSERT INTO statusi(sutijuma_id,apraksts,datums) VALUES(?,?,?)""",
            (sutijuma_id,status,datums))
    savienojums.commit() #saglabā izmaiņas datubāzē
    print("Sūtijuma statuss pievienots!\n")

#zemāk dotas nepareizi uzrakstītas funkcijas datu dzēšanai un atjaunināšanai
#ieraksti komentāros, kas tika labots
def dzest_klientu(cursor, savienojums):
    print("\n***Klienta datu dzēšana***")
    while True: #ievadītā ID validēšana
        try:
            klienta_id = ievadi_skaitli("Ievadiet klienta ID: ") #pārbauda vai izvēlētais ID eksistē datubāzē
            cursor.execute("SELECT COUNT(*) FROM klienti WHERE klienta_id=?",(klienta_id,))
            if cursor.fetchone()[0]>0:
                break #id pareizs-turpina
            else:
                print("Kļūda: jāievada ID, kas eksistē!")
        except ValueError:
            print("Kļūda: jāievada skaitlis!")   

    cursor.execute("SELECT COUNT(*) FROM klienti WHERE klienta_id=?", (klienta_id,)) #izlabotas sintakses kļūdas
    dati=cursor.fetchone()

    if dati==[]:
        print("Nav atrasts! Tiks dzēsts tāpat!")
    while True: #ieliek while ciklā, jai ja izvēlas nedzēst datus, var ieiet arā no funkcijas un saglabāt datus
        apstiprinajums=ievade_jn("Dzēst?(j/n): ")
        if apstiprinajums == 'n':
            print("\n")
            break #pārtrauc funkciju, ja lietotājs, tomēr negrib dzēst datus
        else:
            cursor.execute("DELETE FROM klienti WHERE klienta_id =?", (klienta_id,))
            savienojums.commit() #pievieno funkciju savienojums.commit(), lai izmaiņas parādītos datubāzē
            print("Dzēsts!\n")
            break
def labot_klientu_datus(cursor, savienojums):
    print("\n***Klienta datu labošana***")
    while True: #ievadītā ID validēšana
        try:
            klienta_id = ievadi_skaitli("Ievadiet klienta ID: ") #pārbauda vai izvēlētais ID eksistē datubāzē
            cursor.execute("SELECT COUNT(*) FROM klienti WHERE klienta_id=?",(klienta_id,))
            if cursor.fetchone()[0]>0:
                break #id pareizs-turpina
            else:
                print("Kļūda: jāievada ID, kas eksistē!")
        except ValueError:
            print("Kļūda: jāievada skaitlis!")

    cursor.execute("SELECT vards FROM klienti WHERE klienta_id=?",(klienta_id,)) #programma nestrādāja, jo tur bija sintakses errors
    dati=cursor.fetchone() #pie ID ir tikai 1 vārds, tāpēc nomainīt vajdzēja no fetchall uz fetchone

    print(f"Pašreizējais:{dati}")
    jaunais_vards=ievadi_teksts("Jaunais vārds: ") #neļauj ievadīt tukšu tekstu

    cursor.execute(f"UPDATE klienti SET vards='{jaunais_vards}' WHERE klienta_id={klienta_id}")
    savienojums.commit() #pievieno funkciju savienojums.commit(), lai izmaiņas parādītos datubāzē
    print("Labots!\n")

#nepieciešams nodrošināt arī izvēlni
def izvelne():
    while True:
        print("1 - Pievienot klientu\n2 - Pievienot sūtījumu\n3 - Pievienot statusu\n4 - Dzēst klientu\n5 - Labot klienta datus\n0-iziet")
        izvele = input("Izvēlies darbību: ").strip()

        if izvele == "1":
            ievadi_klientu()
        elif izvele == "2":
            ievadi_sutijumu()
        elif izvele == "3":
            ievadi_statusu()
        elif izvele == "4":
            dzest_klientu(cursor, savienojums)
        elif izvele == "5":
            labot_klientu_datus(cursor, savienojums)
        elif izvele == "0":
            print("Programma beidzas.")
            break
        else:
            print("Nederīga izvēle! Mēģini vēlreiz.\n")

izvelne()

print("\n***Vaicājumi***")
print("\nAtrast un parādīt cik sūtijumu ir katram klientam(pat tam kam ir 0)")
cursor.execute(
    """SELECT 
        vards, COUNT(sutijuma_id) AS sutijumu_sk
    FROM sutijumi
    LEFT JOIN klienti ON sutijumi.klienta_id=klienti.klienta_id
    GROUP BY sutijumi.klienta_id"""
)
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"Klients:{r[0]}, Sūtijumu skaits:{r[1]}")


print("\nAtrast un parādīt vidējo sūtijumu svaru katram klientam")
cursor.execute(
    """SELECT
        vards, AVG(svars_kg) AS videjais_svars
    FROM klienti
    JOIN sutijumi ON klienti.klienta_id=sutijumi.klienta_id
    GROUP BY vards"""
)
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"Klients:{r[0]}, Vidējais svars:{r[1]} kg")


print("\nAtrast un parādīt klienta sūtījuma statusu un informāciju")
cursor.execute(
    """SELECT
        statusa_id, apraksts, vards, AVG(svars_kg) AS videjais_svars
    FROM klienti
    JOIN sutijumi ON klienti.klienta_id=sutijumi.klienta_id
    JOIN statusi ON sutijumi.sutijuma_id=statusi.sutijuma_id
    ORDER BY apraksts"""
)
rezultati=cursor.fetchall()
for r in rezultati:
    print(f"Statusa ID:{r[0]}, Statuss:{r[1]}, Klients:{r[2]}, Svars:{r[3]} kg")