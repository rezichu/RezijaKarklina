class Skolotajs: #izveidot klasi
    #konstruktors
    def __init__(self,vards,prieksmets):
        self.vards = vards
        self.prieksmets = prieksmets

    def iepazistinatArSevi(self):
        print(f"Sveiki, mani sauc {self.vards}!")
    
    def izlikt_vertejumu(self,punkti):
        if punkti > 5:
            return f"Priekšmets {self.prieksmets} ir nokārtots!"
        else:
            return f"Priekšmets {self.prieksmets} nav nokārtots!"

#objekti izveidošana - instancēšana
rinalds = Skolotajs("Rinalds","Ģeogrāfija")
sandra = Skolotajs("Sandra", "Matemātika")

rinalds.iepazistinatArSevi() #izsauc metodi objektam
print(rinalds.izlikt_vertejumu(8))
sandra.iepazistinatArSevi()
print(sandra.izlikt_vertejumu(4))