dienaa = 0,37
nakti = 0,77
gaidisana = 0,15
izsaukums = 2,5
noligt = 2
         

pasazieri = int(input('Cik pasažieru grib braukt vienā laikā? (skaits): '))
if pasazieri > 3 or pasazieri < 0:
    exit()
elif pasazieri <= 3:
    pulkstens = int(input('Cik ir pulkstens? (veselas stundas): '))
    if pulkstens <= 6 or pulkstens >= 21:
        print('Par katru nobraukto km jāmaksā: ', nakti)
        taksis = input('Vai taksis ir firmas stāvvietā? (j/n): ')
        if taksis == 'j':
            print('Taksis ir firmas stāvvietā! Jāmaksā tikai par nolīgšanu!')
            veikals1 = input('Vai Jūs vēlētos ieiet veikalā? (j/n): ')
            if veikals1 == 'n':
                print('Nevaig maksāt par gaidīšanu!')
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Kopējā maksa ir: ', )
            elif veikals1 == 'j':
                print('Par par katru minūti jāmaksā: ' , gaidisana)
                veikals2 = int(input('Cik ilgi? (min): '))
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Par ceļu jāmaksā: ', )
        elif taksis == 'n':
            print('Taksis nav firmas stāvvietā! Jāmaksā par nolīgšanu un izsaukšanu!')
            veikals1 = input('Vai Jūs vēlētos ieiet veikalā? (j/n): ')
            if veikals1 == 'n':
                print('Nevaig maksāt par gaidīšanu!')
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Kopējā maksa ir: ', )
            elif veikals1 == 'j':
                print('Par par katru minūti jāmaksā: ' , gaidisana)
                veikals2 = int(input('Cik ilgi? (min): '))
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Kopējā maksa ir: ', )
    pulkstens = int(input('Cik ir pulkstens? (veselas stundas): '))
    if pulkstens > 6 or pulkstens < 21:
        print('Par katru nobraukto km jāmaksā: ', dienaa)
        taksis = input('Vai taksis ir firmas stāvvietā? (j/n): ')
        if taksis == 'j':
            print('Taksis ir firmas stāvvietā! Jāmaksā tikai par nolīgšanu!')
            veikals1 = input('Vai Jūs vēlētos ieiet veikalā? (j/n): ')
            if veikals1 == 'n':
                print('Nevaig maksāt par gaidīšanu!')
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Kopējā maksa ir: ', )
            elif veikals1 == 'j':
                print('Par par katru minūti jāmaksā: ' , gaidisana)
                veikals2 = int(input('Cik ilgi? (min): '))
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Par ceļu jāmaksā: ', )
        elif taksis == 'n':
            print('Taksis nav firmas stāvvietā! Jāmaksā par nolīgšanu un izsaukšanu!')
            veikals1 = input('Vai Jūs vēlētos ieiet veikalā? (j/n): ')
            if veikals1 == 'n':
                print('Nevaig maksāt par gaidīšanu!')
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Kopējā maksa ir: ', )
            elif veikals1 == 'j':
                print('Par par katru minūti jāmaksā: ' , gaidisana)
                veikals2 = int(input('Cik ilgi? (min): '))
                km = int(input('Cik km jābrauc līdz galapunktam?: '))
                print('Kopējā maksa ir: ', )
    pulkstens = int(input('Cik ir pulkstens? (veselas stundas): '))
else:
    print('Ievadi pareizus datus!')