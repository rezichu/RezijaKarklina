import math

print("Ābola ievārījuma recepte: \n3kg āboli (18 āboli), \n1,5kg cukura, \n200ml ūdens, \n")

aboli = int(input("Ievadiet ābolu daudzumu: "))
abolasvars = 0.176
abolusvars = (aboli * abolasvars)
abolucena = (1.50 * abolusvars)

if aboli < 18:
    print("Āboli kopā sver: ", "{:.2f}".format(abolusvars), "kg", ", Jums jānopērk vēl āboli!")
elif aboli >= 18:
    print("Āboli kopā sver: ", "{:.2f}".format(abolusvars), "kg")
    ir = input('Vai cukurs Jums ir? (j/n): ')
    if ir == 'n':
        print('Jums jānopērk cukurs!')
    elif ir == 'j':
        cukurs = input('Cik kg cukura jums ir?: ')
        if cukurs < 1:
            print('Jums jānopērk vēl cukurs!')



else:
    print('Nevar vārīt ievārījumu!')

'''1 abola svars = 176 g
1kg ābolu maksā €1,50
1kg cukura maksā €2'''