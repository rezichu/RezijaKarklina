#izveidot tukšu vārdnīcu
vardnica = {
    "a":1,
    "b":2
}

ievade_atsl = input('Ievadiet atslēgu:')
ievade_vert = input('Ievadiet vērtību:')

#pārbaudiet lietotāja ievadi un rediģē vārdnīcu
if ievade_atsl in vardnica:
    vardnica[ievade_atsl] = ievade_vert
    print('Vārnīca tika atjaunināta!')

else:
    vardnica[ievade_atsl] = ievade_vert
    print('Jauns pāris tika pievienots vārdnīcai!')

print('Atjauninātā vārdnīca:', vardnica)