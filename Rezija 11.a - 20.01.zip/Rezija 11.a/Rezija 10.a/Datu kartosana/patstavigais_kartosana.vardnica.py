#-Izveidot vārdnīcu 'students',kur katrs atslēgas elements ir skolēnu ID numurs, un vērtība ir vārdnīca,
#kas satur informāciju par katru studentu-vārdu,vecumu,atzīmi #nemainīt secību

#-Definēt funkciju get_age, kas saņem 1 argumentu-studenta datus;
#-Veikt vārdnīcas 'students' sakārtošanu pēc vecuma;
#-Izmantojot ieprieš definēto get_age funkciu, rezultāts
#tiek saglabāts sorted_students_by_age mainīgajā;
#-Izdrukātie dati parāda studentus sakārtotus pēc vecuma;

students = {
    222:{'vārds':'Jānis','vecums':16,'atzīme':9},
    125:{'vārds':'Emīlija','vecums':18,'atzīme':7},
    135:{'vārds':'Jēkabs','vecums':18,'atzīme':8},
    201:{'vārds':'Marta','vecums':16,'atzīme':10},
    167:{'vārds':'Pēteris','vecums':17,'atzīme':6}
}

print(students)

for key in sorted(students):
    print(students)

