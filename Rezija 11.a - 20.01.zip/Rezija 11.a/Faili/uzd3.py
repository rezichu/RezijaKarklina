#pārbaudīt vai alga ir ieliksts kā derīgs skaitlis
#ja nav derīgs skaitlis, tad izdrukāt brīdinājumu
#ja fails darbinieki.csv neeksistē, tad izdrukāt kļūdas paziņojumu

#uzd3 - jaunā failā
#no faila skoleni.csv noteikt, kurš skolēns ieguvis visaugstāko vērtējumu, parādīt skolēna vārdu
