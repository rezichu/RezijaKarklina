import csv #Vaig importēt, lai csv faili strādātu

nosaukums = "pilsetas.csv"
iedzivotaji = {}
def iegut_datus():
    print("Ievadiet pilsētas nosaukumu un iedzīvotāju skaitu.")
    with open(nosaukums,"w",newline='',encoding='utf8')as fails:
        writer = csv.writer(fails)
        writer.writerow(["Pilsēta","Iedzīvotāju skaits"])
        for i in range(1,3):
            pilseta = input("Pilsētas nosaukums: ")
            iedz_sk = input("Iedzīvotāju skaits: ")
            writer.writerow([[pilseta,iedz_sk]])
iegut_datus()

def paradit_datus():
    try:
        with open(nosaukums,"r",newline='',encoding='utf8')as fails:
            reader = csv.reader(fails)
            for rinda in reader:
                print(rinda)
    except FileNotFoundError:
        print(f"Fails {nosaukums} nav atrasts!")
paradit_datus()
