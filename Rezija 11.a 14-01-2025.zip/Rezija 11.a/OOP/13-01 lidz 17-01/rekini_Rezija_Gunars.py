from datetime import datetime #lai var iegūt laiku
import csv #lai varētu atvēr csv failu

class Rekins:
    def __init__(self,klients,veltijums,izmers,materials): #konstruktors
        self.klients = klients
        self.veltijums = veltijums
        self.izmers = izmers
        self.materials = materials
        self.laiks = datetime.now().strftime("%Y-%m-%d %H:%M:%S") #paņem šī brīža laiku

    def izdrukat(self,cena):
        print("Rēķins: \nKlients:",self.klients,"\nVeltījums:",self.veltijums,"\nIzmēri(cm):",self.izmers,"\nMateriāla cena(EUR/cm^3):",self.materials,"\nRēķina izveidošanas laiks:",self.laiks)
        print("Apmaksas summa(EUR):",cena)

    def aprekins(self):
        darba_samaksa = 15
        PVN = 21
        platums,augstums,garums = self.izmers.split()
        platums = int(platums) #pārtaisa mainīgos uz int
        augstums = int(augstums)
        garums = int(garums)
        produkta_cena = len(self.veltijums)*1.2+(platums/100*garums/100*augstums/100)/3*self.materials #aprēķins
        PVN_summa = (produkta_cena+darba_samaksa)*PVN/100
        rekina_summa = produkta_cena+darba_samaksa+PVN_summa
        return round(rekina_summa,2) #noapaļo iegūto rezultātu

    def saglabat(self,cena):
        laiks,laiks2 = self.laiks.split() #sadala lai varētu izveidot faila nosaukumu
        faila_nosaukums = self.klients+'_'+laiks+'.csv' #faila nosaukums
        with open(faila_nosaukums, 'w', newline="",encoding='utf8') as file: #izveido csv failu
            writer=csv.writer(file)
            writer.writerow(["Klients","Veltījums","Izmēri","Materiālu cena","Laiks","Apmaksas summa"])
            writer.writerow([self.klients,self.veltijums,self.izmers,self.materials,self.laiks,cena])

print("Programma apŗēkina koka lādītes lielumu pēc lietotāja ievadītajiem datiem.") #programmas apraksts
while True: #iegūst datus
    print("\nLūdzu ievadiet rēķina datus!")
    klients = input("Klients: ")
    veltijums = input("Veltījus: ")
    izmers = input("Izmēri (trīs veseli skaitļi atdalīti ar atstarpēm): ")
    materials = float(input("Materiāla cena(EUR/cm^3): "))
    klients1 = Rekins(klients,veltijums,izmers,materials)
    cena = klients1.aprekins()
    klients1.saglabat(cena)
    klients1.izdrukat(cena)

    turpinat = input('vai gribat turpināt(j/n):') #vai grib turpināt, jāieliek n lai beigtu
    if turpinat == 'n':
        break
