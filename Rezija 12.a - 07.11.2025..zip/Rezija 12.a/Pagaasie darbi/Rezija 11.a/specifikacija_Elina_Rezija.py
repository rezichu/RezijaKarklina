kop_algas = []
def ievadiet_datus():
    darb_sk = int(input('Ievadiet darbinieku skaitu (vesels skaitlis): '))
    for i in range(darb_sk):
        vards = input('Ievadiet ', i+1,' darbinieka vārdu: ')
        alga = input('Ievadiet ', i+1,' darbinieka algu: ')
    kop_algas.append({'vards': vards, 'alga' : alga})

def alga_videja():
    print(len(kop_algas))

ievadiet_datus()