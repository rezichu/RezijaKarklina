#ierakstīt teksta failā(no programmas) vārdu, uzvārdu un vecumu
#konsolē parādīt sakārtotus datus pēc vecuma(nospiežot 3)
'''dot iespēju izvēlēties: 
1-pievienot datus, 
2-parādīt sakārtotus datus pēc vecuma
3-sakārtot datus
4-iziet'''
#apstrādāt kļūdas

while True:
    print("\nIzvēlieties opciju:")
    print("1 - Pievienot datus")
    print("2 - Parādit datus")
    print("3 - Iziet")

    izvele = input("Izvēle: ")
    if izvele == '1':
        vards = input("Ievadiet vārdu: ")
        uzvards = input("Ievadiet uzvārdu: ")
        vecums = int(input("Ievadiet vecumu: "))
        #dati tiek saglabāti teksta failā
        with open("dati.txt", "a", encoding='utf8') as file:
            file.write(f"{vards} {uzvards} {vecums}\n")
        print("Dati ir pievienoti!")

    elif izvele == '2': #nolasa datus no faila ar ciklu
        try:
            with open("dati.txt", "r", encoding='utf8') as file:
                dati=file.readlines()
            if not dati: #Pārbauda vai failā ir dati
                print("Fails ir tukšs. Pievienojiet datus.")
            else:
                print("\nDati no faila: ")
                for ieraksts in dati():
                    print(ieraksts.strip())
        except FileNotFoundError:
            print("Fails nepastāv!")

    elif izvele == '3':
        print("Izvēle tiek pārtraukta.")
        break

    else:
        print("Nepareiza izvēle. Mēģiniet vēlreiz.")