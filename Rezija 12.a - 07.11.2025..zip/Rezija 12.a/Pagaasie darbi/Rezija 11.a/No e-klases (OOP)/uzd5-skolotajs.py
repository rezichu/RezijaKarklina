class Skolotajs: #izveido klasi
    #konstruktors
    def __init__(self,vards,prieksmets):
        self.vards=vards
        self.prieksmets=prieksmets
        
    def iepazistinat_ar_sevi(self):
        print(f"Sveiki,mani sauc {self.vards}")
        
    def izlikt_vertejumu(self,punkti):
        if punkti>5:
            return f"Priekšmets {self.prieksmets} ir nokārtots!"
        else:
            return f"Priekšmets {self.prieksmets} nav nokārtots!"

#objektu izveidošana
rinalds=Skolotajs("Rinalds","Ģeogrāfija")
sandra=Skolotajs("Sandra","Matemātika")

rinalds.iepazistinat_ar_sevi() #izsauc metodi objektam
print(rinalds.izlikt_vertejumu(8))
sandra.iepazistinat_ar_sevi() #izsauc metodi objektam
print(sandra.izlikt_vertejumu(2))


