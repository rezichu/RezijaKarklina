#1.uzd - Produkti
class Product: #A
    def __init__(self,name,price,quantity):
        self.name = name
        self.price = price
        self.quantity = quantity
    
    def get_total_price(self): #B
        print("The total price:",self.price * self.quantity)

tomato = Product("Tomato",0.42,20) #C
patato = Product("Patato",0.62,12)
tomato.get_total_price()
patato.get_total_price()
#print("The total price: ", tomato.get_total_price()) #ja nav prints ieliekts jau metodē
print("-------------------------------------------")
#2.uzd - Iepirkuma grozs
class ShoppingCart: #D
    def add_product_to_cart(self,product): #E
        print("Product: ", product.name, "is added to the shopping cart.")

    def remove_product_from_cart(self,product):
        print("Product: ", product.name, "is removed from the shopping cart.")

    def get_total_price(self,product):
        print(product.get_total_price())

shopping_cart = ShoppingCart() #F
shopping_cart.add_product_to_cart(tomato)
shopping_cart.get_total_price(tomato)
shopping_cart.remove_product_from_cart(tomato)
print("-------------------------------------------")

class SystemUser: #G
    def __init__(self,username,password,email):
        self.username = username
        self.password = password
        self.email = email

    def set_user_info(self,newusername,newpassword,newemail):
        self.username = newusername
        self.password = newpassword
        self.email = newemail
        print("Informācija ir nomainīta!")

    def get_user_info(self):
        print(f"Username:{self.username}")
        print(f"Password:{self.password}")
        print(f"Email:{self.email}")

user = SystemUser("maryberry231","**mary**belle**","mary.willson@gmail.com") #K
user.get_user_info()
print("\n")
user.set_user_info("maryberryperry1","**mary**belle**jack**","mary.potter@gmail.com")
user.get_user_info()
print("-------------------------------------------")

class Customer(SystemUser):
    def __init__(self,username,password,email,customer_id,purchase_history,membership_status):
        super().__init__(username, password, email)
        self.customer_id = customer_id
        self.purchase_history = purchase_history
        self.membership_status = membership_status
    
    def set_user_info(self,newusername,newpassword,newemail,newcustomer_id,newpurchase_history,newmembership_status): #M
        super().set_user_info(newusername,newpassword,newemail)
        self.customer_id = newcustomer_id
        self.purchase_history = newpurchase_history
        self.membership_status = newmembership_status

    def get_user_info(self):
        super().get_user_info()
        print(f"Customer ID:{self.customer_id}")
        print(f"Purchase history:{self.purchase_history}")
        print(f"Membership status:{self.membership_status}")

poppy = Customer("poppyflower421","**PoppySeedsForSale**","poppy.carry@gmail.com",23,"","")
poppy.get_user_info()
print("\n")
poppy.set_user_info("poppytime283","**PoppyPlaytime**","poppy.carry@gmail.com",23,"Banāns","Klients")
poppy.get_user_info()
print("-------------------------------------------")