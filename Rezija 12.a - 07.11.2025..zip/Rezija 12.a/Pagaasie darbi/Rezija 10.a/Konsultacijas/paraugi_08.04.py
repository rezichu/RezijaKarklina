import datetime
#lietotājs ievadīs datumu
def iegut_datumu():
    while True:
        try:
            date_str = input('Ievadiet datumu YYYY-MM-DD: ')
            #pārbauda vai datums ir nākotnē
            #pārvērš par datetime objektu
            ievada_datums = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
            if ievada_datums > datetime.date.today():
                print('Lielāks par šodienu!')
            else:
                return ievada_datums
        except ValueError:
            print('Nepareizs formāts. Mēģiniet vēlreiz!')

iegut_datumu()

def masinas_dati():
    try:
        gads = int(input('Ievadiet gadu: '))
        if(gads < 2012 or gads > 2024):
            print('Vajag pareizus datus!')
        else:
            print('Paldies! ')
    except ValueError:
        print('Pareizus datus (vaig skaitli!)')

masinas_dati()

#failam ievadīto datu nosaukumu var iestatīt
#filename = f'{masina}_{gads}.txt'
'''def saglabat_faila(datums,temats,klase,skolenu_atz):
    filename = f"{temats}_{klase}.txt"
    #izveidos failu, pārbaudīs vai eksistē. Ja eksistē, pieliks info klāt
    try:
        with open(filename, "r", encoding = "utf-8") as file:
            existing_data = file.read().strp()
        except FileNotFoundError:
            existing_data"" '''
    #šeit jāturpina ar faila izveidi
    #if existing_data:
        #file.write
