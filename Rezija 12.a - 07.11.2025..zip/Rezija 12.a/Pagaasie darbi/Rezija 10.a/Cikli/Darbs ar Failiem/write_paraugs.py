
fails = open('dati.txt', 'w', encoding = 'utf-8') #w izveido failu
fails.write('Mācos rakstīt failā!\n')
fails.write('Tattletail looks like a Furby!\n')

fails = open('dati.txt', 'r', encoding='utf-8')
fails.seek(0) #aizstāj fails = open #sākumā ir jāatver #nestrādā ༼ つ ◕_◕ ༽つ
print(fails.read()) #datus nolasa un parāde konsolē

fails.write('Ziema\n')
