'''izdevums = input("Grāmata vai žurnāls: ") #ievadiet izdevuma veids

persona = input("Personāls vai students: ") #ievadiet personas pozīciju
dienas = int(input("Cik dienas: ")) #cik dienas grāmatu paturēs pirms nodos atpakaļ'''


paradi = input("Vai grāmatas nodotas: ")
if paradi == 'j':
    print('Nebūs')
    exit()

veids = input("Pieprasīta vai nepieprasīts: ") #ievadiet izdevuma pieprasījuma veidu

'''if veids == 'pieprasīts':
    if izdevums == 'grāmata' or izdevums == 'žurnāls':
        if paradi == 'jā':
            if dienas == 2 or dienas < 2:
                print('Izdevumu izsniedz!')
elif veids == 'nepieprasīts':
    if izdevums == 'grāmata':
        if persona == 'personāls':
            if paradi == 'jā':
                if dienas == 28 or dienas < 28:
                    print('Izdevumu izsniedz!')
        elif persona == 'students':
            if paradi == 'jā':
                if dienas == 14 or dienas < 14:
                    print('Izdevumu izsniedz!')
    elif izdevums == 'žurnāls':
        if persona == 'students' or persona == 'personāls':
            if paradi == 'jā':
                if dienas == 7 or dienas < 7:
                    print('Izdevumu izsniedz!')'''
