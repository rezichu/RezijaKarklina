import sqlite3

savienojums = sqlite3.connect("spa_sistema.db")
cursor = savienojums.cursor()


cursor.execute("""
CREATE TABLE IF NOT EXISTS klienti(
    klienti_id INTEGER PRIMARY KEY AUTOINCREMENT,
    vards TEXT NOT NULL,
    uzvards TEXT NOT NULL,
    telefons TEXT NOT NULL
)
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS pakalpojumi(
    pakalpojumi_id INTEGER PRIMARY KEY AUTOINCREMENT,
    nosaukums TEXT NOT NULL,
    ilgums INTEGER NOT NULL,
    cena REAL NOT NULL
)
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS pieraksti(
        pieraksti_id INTEGER PRIMARY KEY AUTOINCREMENT,
        klients_id INTEGER NOT NULL,
        pakalpojums_id INTEGER NOT NULL,
        datums TEXT NOT NULL,
        FOREIGN KEY (klients_id) REFERENCES klienti(klienti_id),
        FOREIGN KEY (pakalpojums_id) REFERENCES pakalpojumi(pakalpojumi_id)
)
""")

while True:
    print("--Pievienot klientu: ")
    vards=input("Ievadi vārdu: ")
    uzvards=input("Ievadi uzvārdu: ")
    telefons=input("Ievadi telefona nr: ")

    cursor.execute("""
        INSERT INTO klienti(vards,uzvards,telefons) VALUES(?,?,?)""",
        (vards,uzvards,telefons))
    savienojums.commit()
    print("Klients pievienots!")
    turpinat = input("Vai pievieot vēl klientu?(j/n): ".lower())
    if turpinat !="j":
        break

#tabula pakalpojumi
while True:
    print("--Pievieno pakalpojumu: ")
    nosaukums=input("Ievadi pakalpojuma nosaukumu: ")
    ilgums=int(input("Ievadi pakalpojuma ilgumu: "))
    cena=float(input("Ievadi pakalpojuma cenu: "))

    cursor.execute("""
        INSERT INTO pakalpojumi(nosaukums,ilgums,cena) VALUES (?,?,?)
        """,(nosaukums,ilgums,cena))
    savienojums.commit()
    print("Klients pievienots!")
    turpinat = input("Vai pievieot vēl pakalpojumu?(j/n): ".lower())
    if turpinat !="j":
        break

#pārbaudīt kādi klienti (un id) jau eksistē
while True:
    print("Pieejamie klienti: ")
    cursor.execute("SELECT klienti_id, vards FROM klienti")
    for klients in cursor.fetchall():
        print(f"ID {klients[0]} - {klients[1]} - {klients[2]}")

    #klienta ievade ar id pārbaudi
    while True:
        try:
            klients_id=int(input("Ievadi klienta id: "))
            #pārbaudīt, vai klienta id tabulā eksistē
            cursor.execute("SELECT COUNT(*) FROM klienti WHERE klienti_id=?",(klients_id))
            if cursor.fetchone()[0]>0:
                break #id pareizs-turpina
            else:
                print("Klients ar šādu ID neeksistē")
        except ValueError:
            print("Ievadi skaitli, jo ID ir cipars.")

    #pārbaudīt pakalpojuma id un nodrošināt ievadi
    print("Pieejamie pakalpojumi: ")
    cursor.execute("SELECT pakalpojumi_id, nosaukums, cena FROM pakalpojumi")
    for p in cursor.fetchall():
        print(f"ID {p[0]} - {p[1]} - {p[2]}$")

    while True:
        try:
            pakalpojums_id=int(input("Ievadi pakalpojuma id: "))
            #pārbaudīt, vai klienta id tabulā eksistē
            cursor.execute("SELECT COUNT(*) FROM pakalpojumi WHERE pakalpojumi_id=?",(pakalpojums_id))
            if cursor.fetchone()[0]>0:
                break #id pareizs-turpina
            else:
                print("Pakalpojums ar šādu ID neeksistē")
        except ValueError:
            print("Ievadi skaitli, jo ID ir cipars.")
    datums = input("Ievadi pieraksta datumu (YYYY-MM-DD): ")
    cursor.execute("""
    INSERT INTO pieraksti (klienti_id, pakalpojumi_id, datums) VALUES (?, ?, ?)
    """, (klients_id, pakalpojums_id, datums))
    savienojums.commit()
    print("Klients pievienots!")
    turpinat = input("Vai pievieot vēl pierakstu?(j/n): ".lower())
    if turpinat !="j":
        break

print("Pieraksts pievienots!")

#parādīt tabulās esošos datus
print("Visi apmeklētāji: ")
cursor.execute("SELECT*FROM klienti")
for rinda in cursor.fetchall():
    print(rinda)





    #tabula pieraksti
#while True:
    #print("--Pievieno pierakstu: ")
    #klients_id = int(input("Ievadi klienta ID: "))
    #pakalpojums_id = int(input("Ievadi pakalpojuma ID: "))
    #datums = input("Ievadi pieraksta datumu (YYYY-MM-DD): ")

    #cursor.execute("""
    #INSERT INTO pieraksti (klienti_id, pakalpojums_id, datums) VALUES (?, ?, ?)
    #""", (klients_id, pakalpojums_id, datums))
    #savienojums.commit()
    #print("Klients pievienots!")
    #turpinat = input("Vai pievieot vēl pierakstu?(j/n): ".lower())
    #if turpinat !="j":
        #break