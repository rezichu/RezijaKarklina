#ļaut ievadīt tekstu, ierakstīt to failā "teksta_fails.txt" ievadiet skaitli
#papildināt failu ar šo skaitli, katru rindu sākot ar 'papildus rindas nr'

def ierakstit_faila():
    teksts = input('Ievadiet tekstu:')

    with open('teksta_fails.txt', 'w', encoding='utf-8') as fails:
        fails.write(teksts)


def papildus_skaitlis():
    skaitlis = int(input('Ievadiet veselu skaitli:'))

    with open('teksta_fails.txt', 'a', encoding='utf-8') as fails:
        for i in range(skaitlis):
            fails.write(f"\nPapildus rinda nr. {i+1}")


ierakstit_faila()