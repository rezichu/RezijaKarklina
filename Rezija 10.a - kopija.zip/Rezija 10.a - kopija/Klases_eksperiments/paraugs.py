from datetime import datetime

iziesana = ["stop","iziet","exit"] #pārbaudes ieliek sarakstā

def pareizs_vards(vards):
    simboli = [] #tukšs saraksts, kur glabās vārda burtus
    for i in vards:
        simboli.append(i) #iziet cauri katram simboli 'vards' un pievieno sarakstam
    fiksets = "" #šeit glabās pārveidoto vārdu
    while True:
        if " " in simboli:
            simboli.remove(" ") #noņem atstarpes no vārda
        else:
            break
        #pārliecinās, ka pirmais burts ir lielais
    simboli[0] = simboli[0].upper()
    for i in simboli: #latru elementu no simboliem pievieno
        fiksets = fiksets + i
    return fiksets #atgriež virkni ar lielo burtu un bez atstarpēm

'''vards= vards.replace(" ","")
vards= vards.capitalize() #nomaina primo burtu uz lielo'''

def iegut_datus():#funkcija, kas iegūstot nosaukumu, vārdu un vietu un pārbauda vai iziet no funkcijas
    eksperimenta_nosaukums = input('Ievadiet eksperimenta nosaukumu: ')
    if eksperimenta_nosaukums in iziesana:
        exit() #iziet, ja nosaukums ir sarakstā 'iziešana'

    laiks = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    vards = input('Ievadiet jūsu vārdu: ')
    if vards in iziesana:
        exit()
    vieta = input('Ievadiet eksperimenta norises vietu: ')
    if vieta in iziesana:
        exit()

    return [eksperimenta_nosaukums, laiks, pareizs_vards(vards), vieta]

def saglabat_datus(dati):
    pilns = f"\nVārds:{dati[2]} - eksperiments:{dati[0]} - vieta:{dati[3]} - laiks:{dati[1]}"
    #šādā formātā un secībā dati būs failā
    file = open('eksperimenta_dati.txt','a',encoding='utf8')
    file.write(pilns)
    file.close()

def galvena():
    print('Sveicināti eksperimenta programmā!🎉')
    while True: #nodrošina atkārtošanos
        saglabat_datus(iegut_datus())
        while True:
            izvele = input("Turpināt?(Y/N): ").upper()
            if izvele == 'N':
                exit()
            elif izvele not in ['Y', 'N']: #jāievada vēlreiz
                print('Nepareiza izvade!')
            else:
                break
galvena()