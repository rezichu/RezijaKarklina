import datetime #lai varētu iegūt datumu

def iegut_gadu():
    now = datetime.datetime.now()
    return now.year

def saglabat_faila(fails, dati):
    try:
        with open(fails, 'w', encoding = 'utf-8') as file:
            for masina in dati:
                file.write('Mašīnas marka: ', masina['Nosaukums'])
                file.write('\nGads: ', masina['gads'])
                file.write('\Modelis: ', masina['modelis'])
                file.write('\Cena: ', masina['cena'])
        print('Dati ir veiksmīgi ierakstīti failā ', fails)
    except Exception as e:
        print('Kļūda ierakstot datus failā: ', e)

masinas_sk = int(input('Mašīnas skaits: ')) #par cik auto būs info
tag_gads = iegut_gadu()
#saraksts, lai glabātu auto info
masinas = [] #sākumā tukšs saraksts

for i in range(masinas_sk):
    print("\nIevadiet info par ", i+1, ". mašīnu.")
    nosaukums = input('Ievadiet mašīnas nosaukumu: ')
    gads = input('Gads: ')
    #pārbauda vai ir skaitlis un vai ir lielāks par tagadējais gadu
    while not gads.isdigit() or int(gads) > tag_gads:
        print('Ievadiet pareizus datus!')
        gads = input('Gads: ')
    modelis = input('Modelis: ')
    cena = input('Cena: ')
    masinas.append({'Marka' : nosaukums, 'Gads' : gads, 'Modelis' : modelis, 'Cena' : cena})

for masina in masinas:
    fails = masina["nosaukums"] + ".txt"
    saglabat_faila(fails, [masinas])