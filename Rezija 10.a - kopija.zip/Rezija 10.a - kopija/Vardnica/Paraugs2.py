#izveidot vārdnīcu, kas satur sarakstu
valstis = {
    'Somija': ['Helsinki', 'Tampere', 'Rovaniemi', 'Kemijarvi', 'Jyvaskyle'],
    'Norvēģija': ['Oslo', 'Bergena', 'Trumse', 'Arendāla', 'Molde'],
    'Dānija': ['Kopenhāgena', 'Ronne', 'Odense', 'Esbjerga', 'Aarhus']
}

#izdrukāt vārdnīcas elementus, piekļūstot vārdnīcā konkrētai darbībai
for i in valstis['Dānija']:
    print(i)

for i in valstis['Norvēģija']:
    print(i)

for i in valstis['Somija']:
    print(i)

#izdrukāt pirmās 3 pilsētas no Somijas
print(valstis['Somija'][:3])

#iegūt pēdējās 2 pilsētas no Norvēģijas
print(valstis['Norvēģija'][-2:])

#Visas pilsētas no Somija, izņemot 3 pēdējās
print(valstis['Somija'][:2])
print(valstis['Somija'][:-3])

#iegūt no 2.-5. pilsētas no Dānija
print(valstis['Dānija'][1:6])
print(valstis['Dānija'][1:5])

