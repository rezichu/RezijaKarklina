import sqlite3
savienojums=sqlite3.connect("spa_sistema.db")
cursor=savienojums.cursor()

cursor.execute("DROP TABLE IF EXISTS klienti")
cursor.execute("DROP TABLE IF EXISTS pakalpojumi")
cursor.execute("DROP TABLE IF EXISTS pieraksti")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS klienti (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        vards TEXT NOT NULL,
        uzvards TEXT NOT NULL,
        telefons TEXT NOT NULL
    )
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS pakalpojumi (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nosaukums TEXT NOT NULL,
        ilgums INTEGER NOT NULL,
        cena REAL NOT NULL
    )
""")

cursor.execute("""
    CREATE TABLE IF NOT EXISTS pieraksti (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        klients TEXT NOT NULL,
        pakalpojums TEXT NOT NULL,
        datums TEXT NOT NULL
    )
""")

cursor.execute("INSERT INTO klienti(vards,uzvards,telefons) VALUES (?,?,?)",("Liene","Liepa","298734552"))
cursor.execute("INSERT INTO klienti(vards,uzvards,telefons) VALUES (?,?,?)",("Artūrs","Ozols","203654386"))
cursor.execute("INSERT INTO klienti(vards,uzvards,telefons) VALUES (?,?,?)",("Mārtiņš","Lācis","235475309"))

cursor.execute("INSERT INTO pakalpojumi(nosaukums,ilgums,cena) VALUES (?,?,?)",("Liene","Liepa","298734552"))
cursor.execute("INSERT INTO pakalpojumi(nosaukums,ilgums,cena) VALUES (?,?,?)",("Liene","Liepa","298734552"))
cursor.execute("INSERT INTO pakalpojumi(nosaukums,ilgums,cena) VALUES (?,?,?)",("Liene","Liepa","298734552"))

cursor.execute("INSERT INTO pieraksti(klients,pakalpojums,datums) VALUES (?,?,?)",("Liene","Liepa","298734552"))