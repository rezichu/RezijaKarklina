--a
SELECT*FROM gramatas;

--b
SELECT nosaukums,izdosanas_gads FROM gramatas;

SELECT nosaukums AS "Grāmatas nosaukums", izdosanas_gads AS "Izdošanas gads"
FROM gramatas;

--c
SELECT*FROM autori;

SELECT vards FROM autori;

--d
SELECT vards,dzimsanas_gads FROM autori;

SELECT vards AS "Autora vārds", dzimsanas_gads AS "Dzimšanas gads"
FROM autori;

--e
SELECT*FROM zanri;

SELECT zanrs_nosaukums FROM zanri ORDER BY zanrs_nosaukums;

--f
SELECT*FROM izdeveji;

SELECT izdevejs_nosaukums AS "Izdevējs" FROM izdeveji;

--g
SELECT*FROM gramatas WHERE izdosanas_gads>=1950;

SELECT nosaukums,izdosanas_gads FROM gramatas
WHERE izdosanas_gads>=1950;

--h
SELECT*FROM autori WHERE autori.dzimsanas_gads>=1950;

SELECT vards,dzimsanas_gads FROM autori
WHERE dzimsanas_gads>=1950;

--i
SELECT*FROM gramatas ORDER BY gramatas.izdosanas_gads ASC;

SELECT nosaukums, izdosanas_gads FROM gramatas ORDER BY izdosanas_gads;

--j
SELECT*FROM gramatas WHERE gramatas.zanrs_id=1;

SELECT gramatas.nosaukums, zanri.zanrs_nosaukums AS Žanrs
FROM gramatas
JOIN zanri ON gramatas.zanrs_id=zanri.zanrs_id
WHERE zanri.zanrs_nosaukums='Fantāzija';

--k
SELECT
    gramatas.nosaukums AS Grāmatu_nosaukumi,
    autori.vards AS Autoru_vārdi
FROM gramatas
JOIN autori ON gramatas.autors_id=autori.autors_id
GROUP BY gramatas.nosaukums;

SELECT gramatas.nosaukums AS Grāmatas, autori.vards AS Autors
FROM gramatas
INNER JOIN autori ON gramatas.autors_id=autori.autors_id;

--l
SELECT
    gramatas.nosaukums AS Grāmatu_nosaukumi,
    autori.vards AS Autoru_vārdi,
    izdeveji.izdevejs_nosaukums AS Izdevēju_nosaukumi
FROM gramatas
JOIN autori ON gramatas.autors_id=autori.autors_id
JOIN izdeveji ON gramatas.izdevejs_id=izdeveji.izdevejs_id
GROUP BY gramatas.nosaukums;

--m
SELECT
    autori.vards AS Autoru_vārdi,
    COUNT(gramatas.gramatas_id) AS Grāmatu_skaits
FROM autori
JOIN gramatas ON autori.autors_id=gramatas.autors_id
GROUP BY autori.vards;

--n
SELECT
    autori.vards AS Autoru_vārdi,
    autori.valsts AS Autora_valsts_nosaukums
FROM autori
JOIN gramatas ON autori.autors_id=gramatas.autors_id
WHERE gramatas.zanrs_id=2;

SELECT
    autori.vards AS Autoru_vārdi,
    autori.valsts AS Autora_valsts_nosaukums
FROM autori
JOIN gramatas ON autori.autors_id=gramatas.autors_id
JOIN zanri ON autori.zanrs_id=zanri.zanrs_id
WHERE zanri.zanrs_nosaukums='Detektīvi'

--o
SELECT
    gramatas.nosaukums AS Grāmatu_nosaukumi,
    gramatas.izdosanas_gads AS Grāmatas_izdošanas_gads
FROM gramatas
WHERE izdosanas_gads=(SELECT MIN(izdosanas_gads)FROM gramatas)
OR izdosanas_gads=(SELECT MAX(izdosanas_gads) FROM gramatas);