#pieslēgties esošajai datubāzei
#jāuzraksta programma, kur lietotājs var izvēlēties opcijas no 0-5
#katra opcija atgriež vaicājuma rezultātus, bet 0-iziet no programmas
#nevar ievadīt neko citu kā tikai no 0-5
#1-visi klienti
#2-visi pakalpojumi
#3-visi pieraksti (ar klienta vārdu un pakalpojuma nosaukumu)
#4-tuvāko 7 dienu pieraksti
#5-lietotājs norāda cenu->parādīt pakalpojumus, kas ir dārgāki
import sqlite3
from datetime import datetime

savienojums=sqlite3.connect("spa_sistema.db")
cursor = savienojums.cursor()

while True:
    print("\n1 - Parāda visus klientus \n2 - Parāda visus pakalpojumus\n3 - Parāda visus pierakstus\n4 - Parāda tuvāko 7 dienu pierakstus\n5 - Parāda pakalpojumus, kas ir dārgāki par klienta norādīto cenu\n0 - Iziet")
    while True:
        try:
            izvele = int(input("Ko jūs vēlētos darīt?: "))
            if izvele>5:
                print("Ievadiet skaitli starp 1 un 5!\n")
            else:break
        except ValueError:
            print("Ievadiet skaitli!\n")
    if izvele==1:
        print("Visi klienti:")
        cursor.execute("SELECT*FROM klienti\n")
        for rinda in cursor.fetchall():
            print(rinda)
    elif izvele==2:
        print("Visi pakalpojumi:")
        cursor.execute("SELECT * FROM pakalpojumi\n")
        for rinda in cursor.fetchall():
            print(rinda)
    elif izvele==3:
        print("Visi pieraksti:")
        cursor.execute("""
            SELECT vards,uzvards,nosaukums FROM pieraksti 
            JOIN klienti ON pieraksti.klients_id=klienti.klienti_id 
            JOIN pakalpojumi ON pieraksti.pakalpojums_id=pakalpojumi.pakalpojumi_id GROUP BY pieraksti.pakalpojums_id\n""")
        for rinda in cursor.fetchall():
            print(rinda)
    elif izvele==4:
        print("Visi pieraksti tuvāko 7 dienu laikā:")
        cursor.execute("SELECT vards,uzvards,nosaukums FROM pieraksti JOIN klienti ON pieraksti.klients_id=klienti.klienti_id JOIN pakalpojumi ON pieraksti.pakalpojums_id=pakalpojumi.pakalpojumi_id GROUP BY pieraksti.pakalpojums_id\n")
    elif izvele==5:
        while True:
            try:
                cena = float(input("Ievadiet jūsu izvēlēto cenu: "))
                if izvele<0:
                    print("Ievadiet pozitīvu skaitli!")
                else:
                    break
            except ValueError:
                print("Ievadiet skaitli!")
        print("Pakalpojumi, kas ir dārgāki par norādīto cenu: ")
    else:
        print("Nope!")