import csv
from datetime import datetime

class Rekins:
    def __init__(self,klients,veltijums,izmers,materials):
        self.klients = klients
        self.veltijums = veltijums
        self.izmers = izmers #platums,garums,augstums
        self.materials = materials
        self.laiks = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.darba_samaksa = 15
        self.PVN = 21
        #self.summa = 0 #aprēķina vēlāk, izsaucot aprekins()
        self.summa = self.aprekins() #aprēķinās pēc objekta izveidošanas, pamatojot uz citiem

    def izdrukat(self):
        print("\nRĒĶINS")
        print(f"Izveidošanas laiks: {self.laiks}")
        print(f"Klients: {self.klients}")
        print(f"Veltījums: {self.veltijums}")
        print(f"Izmērs (mm): plutums={self.izmers[0]}, garums={self.izmers[1]}, augstums={self.izmers[2]}")
        print(f"Kokmateriāla cena (EUR/m^2): {self.materials}")
        print(f"Darba samaksa: {self.darba_samaksa} EUR")
        print(f"PVN: {self.PVN}%")
        print(f"Kopējā summa: {self.summa} EUR")

    def aprekins(self): #self atsaucas uz pašreizējo objektu
        platums,garums,augstums = self.izmers
        produkta_cena = len(self.veltijums)*1.2+(platums/100*garums/100*augstums/100)/3*self.materials #aprēķins
        PVN_summa = (produkta_cena+self.darba_samaksa)*self.PVN/100
        rekina_summa = produkta_cena+self.darba_samaksa+PVN_summa
        return round(rekina_summa,2)

    def saglabat(self):
        datnes_nosaukums = f"rekins_{self.klients}_{datetime.now().strftime('%Y-%m-%d')}.csv"
        with open(datnes_nosaukums,"w",newline="",encoding='utf8') as fails:
            rakstitajs = csv.writer(fails)
            rakstitajs.writerow(["Izveidošanas laiks", "Klients", "Veltījums", "Izmērs", "Cena (EUR/m^2)", "PVN (%)", "Summa (EUR)"])
            rakstitajs.writerow([self.laiks, self.klients, self.veltijums, 
                                 f"{self.izmers[0]}x{self.izmers[1]}x{self.izmers[2]}", 
                                 self.materials, self.PVN, self.summa])
            print(f"Rēķins saglabāts failā: {datnes_nosaukums}!")

print("Programma aprēķina kastītes cenu, pēc prasītajiem un lietotāja dotajiem datiem.")
while True:
    print("Lūdzu ievadiet rēķina datus!")
    klients = input("Klients: ")
    veltijums = input("Veltījus: ")
    platums = int(input("Platums: "))
    garums = int(input("Garums: "))
    augstums = int(input("Augstums: "))
    materials = float(input("Materiāla cena(EUR/cm^3): "))
    #jauna rēķina objekta izveidošana
    klients1 = Rekins(klients,veltijums,[platums,garums,augstums],materials)
    #saglabā un aprēķina rezultātu
    klients1.saglabat()
    klients1.izdrukat()
    #klients1.aprekins() - ja pie laukiem liek, summa = 0

    turpinat = input('vai gribat turpināt(j/n):') #vai grib turpināt, jāieliek n lai beigtu
    if turpinat == 'n':
        break
