class Viesis:
    def __init__(self,vards,parole):
        self.vards = vards
        self.parole = parole

    #izdrukā info par izveidotu lietotāju
    def druka_vardu(self):
        print(f"Lietotājs {self.vards} izveidots!")

    def parbauda_paroli(self,parole):
        #pārbauda, vai parole sakrīt
        if self.parole == parole:
            print(f"Lietotāja {self.vards} parole ir pareiza!")
        else:
            print("Parole nav pareiza!")

#klase Darbinieks manto no Viesis
#metode druka_vardu izprintē info par administratoru
class Darbinieks(Viesis):
    def __init__(self,vards,parole):
        super().__init__(vards,parole)

    def druka_vardu(self):
        print(f"Administrators {self.vards} izveidots!")

#Testa dati
vards1 = "Valdis"
parole1 = "parole2"

vards2 = "Daina"
parole2 = "monitors2"

#izveido objektu klasei Viesis un izsauc metodi
lietotajs1 = Viesis(vards1,parole1)
lietotajs1.druka_vardu()
lietotajs1.parbauda_paroli(parole1)

lietotajs2 = Darbinieks(vards2,parole2)
lietotajs2.druka_vardu()
lietotajs2.parbauda_paroli(parole2)