#saglabāt datus sarakstā
'''names = []
for i in range(3):
    names.append(input("What's your name?: "))
#atgriež sakārtotus
for names in sorted(names):
    print(f"Hello, {names}.")'''

#informāciju no konsoles ieraksta failā
'''name = input("What's your name?: ")
file = open("names.txt", "a", encoding='utf8') #w izveido failu un ieraksta datus'''
#a režīmā arī izveido failu, bet informāciju pieliek klāt
'''file.write(f"{name}\n")
file.close() #ja izmanro file=open, tad aizved ciet failu'''

'''#lieto context manager-fails nav jāaizver
name = input("What's your name?: ")
with open('names.txt', 'a', encoding='utf8') as file:
    file.write(f"{name}\n")'''

'''#nolasīt informāciju no faila
with open("names.txt", encoding='utf8') as file:
    for line in file:
        print("Hello,", line.rstrip())'''

#Atgriezt sakārtotus datus no faila
name = []
with open("names.txt", encoding='utf8') as file:
    for line in file:
        name.append(line.rstrip())
for name in sorted(name):
    print(f"Hello, {name}")