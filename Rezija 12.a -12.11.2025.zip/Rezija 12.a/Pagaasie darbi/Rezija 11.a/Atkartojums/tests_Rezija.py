#1(0-10%)   2(11-20%)   3(21-30%)   4(31-40%)   5(41-53%)   6(54-66%)   7(67-76%)   8(77-86%)   9(87-94%)   10(95-100%)


def noteikt_vertejumu_un_atzimi(rezultats):
    if rezultats >= 95:
        vertejums = 'Izcili'
        atzime = 10
    elif rezultats >= 87:
        vertejums = 'Ļoti labi'
        atzime = 9
    elif rezultats >= 77:
        vertejums = 'Labi'
        atzime = 8
    elif rezultats >= 67:
        vertejums = 'Vidēji'
        atzime = 7
    elif rezultats >= 54:
        vertejums = 'Apmierinoši'
        atzime = 6
    elif rezultats >= 41:
        vertejums = 'Viduvēji'
        atzime = 5
    elif rezultats >= 31:
        vertejums = 'Gandrīz apmierinoši'
        atzime = 4
    elif rezultats >= 21:
        vertejums = 'Vāji'
        atzime = 3
    elif rezultats >= 11:
        vertejums = 'Ļoti vāji'
        atzime = 2
    elif rezultats >= 0:
        vertejums = 'Slikti'
        atzime = 1
    return vertejums, atzime

def ievadit_rezultatu():
    while True:
        try:
            rezultats = float(input('Testa rezultāts(0-100): '))
            if rezultats >= 0 and rezultats <= 100:
                return rezultats
            else:
                print('Ievadiet no 0 - 100')
        except ValueError:
            print('Nederīga ievade.')

def galvena_programma():
    while True:
        rezultats = ievadit_rezultatu()
        vertejums, atzime = noteikt_vertejumu_un_atzimi(rezultats)
        print(f"Rezultāts: {rezultats}% - {vertejums} (atzime: {atzime})\n")

        turpinat = input('Vai ievadīsiet citu rezultātu?(jā/nē): ').lower()
        if turpinat != 'jā':
            print('Programma beigusies!')
            break

galvena_programma()