#for cikls
for i in range(10):
    print(str(i) * i)
print()
print('---------------------------------')
for i in range(9,10,1):
    print(i)