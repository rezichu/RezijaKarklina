import math
print('Faktoriāla aprēķināšana')

def zvaigznites():
    for i in range(55,56,1):
        print(i*'*')

try:
    skaitlis = int(input('Ievadiet veselu pozitīvu skaitli (mazāk par 13): '))
except ValueError:
    print('Jaievada skaitlis!')
    exit()

def faktoriala_rekn(skaitlis):
    if skaitlis > 13:
        print('Faktoriāls: ', math.factorial(skaitlis))
    else:
        print('Ievadītais skaitlis ir pārāk liels!')










for i in range(10,11,1):
    print(i*'*')
print('Paldies!')