print('Divciparu skaitļa ciparu summas aprēķins')
x = int(input('Ievadiet divciparu skaitli: ')) #x ir ievadītais skaitlis
print(x)
print('Divciparu skaitlis =', x)
print('Pirmais cipars:', x//10)
print('Otrais cipars:', x%10)
print(x//10 + x%10)