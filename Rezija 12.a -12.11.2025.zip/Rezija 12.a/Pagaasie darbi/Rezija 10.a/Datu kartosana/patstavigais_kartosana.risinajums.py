students = {
    101:{
        'Vārds:':'Alise',
        'Vecums:':25,
        'Atzīme:':10
    },
    102:{
        'Vārds:':'Jānis',
        'Vecums:':29,
        'Atzīme:':8
    },
    103:{
        'Vārds:':'Anna',
        'Vecums:':24,
        'Atzīme:':7
    },
    104:{
        'Vārds:':'Jēkabs',
        'Vecums:':21,
        'Atzīme:':9
    },
    105:{
        'Vārds:':'Justs',
        'Vecums:':30,
        'Atzīme:':6
    }
}

def get_age(student_data):
    return student_data[1]['Vecums']

#veikt vārdnīcas sakārtošanu, izmantojot definēto funkciju, rezultātu saglabāt mainīgajā
#sorted_students_by_age
sorted_students_by_age = dict(sorted(students.items(), key = get_age))


print('Sakārtota vārdnīca pēc vecuma:')
for id, dati in sorted_students_by_age.items():
    print(f'ID:{id},Dati:{dati}')