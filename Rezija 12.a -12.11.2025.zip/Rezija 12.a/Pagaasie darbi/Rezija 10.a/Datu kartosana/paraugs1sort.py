darzeni = ['gurķi','kartupeļi','burkāni','redīsi']
#ar sorted() izveido jaunu sakārtotu sarakstu, neaiztiekot esošo
print('Oriģināls:', darzeni)
print('Ar sorted sārtot:', sorted(darzeni))

darzeni.sort() #maina saraksta struktūru

skaitli = [5,2,1,3,8,9]
print(sorted(skaitli)) #atgriež jaunu sakārtotu sarakstu, nemainot oriģinālo
print(skaitli)

darzeni_apgriezts = sorted(darzeni, reverse = True) #kārto sarakstu dilstošā secībā
print('Apgriezta secība dārzeņiem:', darzeni_apgriezts)