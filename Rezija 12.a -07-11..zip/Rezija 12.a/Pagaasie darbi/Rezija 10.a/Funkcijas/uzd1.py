#izveidot funkciju ar nosaukumu ar myfunction, kurai nav parametru
#Šī funkcija pie izteiksmes izdrukā 'Hello world'

#izsaukt funkciju tad, ja lietotāja ievadītie veseļi skaitļi(a un b) ir vienādi
#pretējā gadījumā parādi uz ekrāna tekstu 'Nesanāca'

def myfunction():
    print('Hello world!')

a = int(input('Ievadiet 1. skaitli: '))
b = int(input('Ievadiet 2. skaitli: '))

if a == b:
    print('Hello world!')
else:
    print('Nesanāca.')
print('-------------------------')


def info(vards, vecums, darbs):
    print('Vārds:', vards,)
    print('Vecums:', vecums,)
    print('Darbs:', darbs,)
    return

info(vards = 'Žaklīna', vecums = '102', darbs = 'Pensionārs')
print('-------------------------')


#Uzraksti programmā funkcija, kas saskaita visus skaitļus sarakstā
list = [1,2,4,6,9,12]

def summa():
    print(sum(list))
summa()
print('-------------------------')