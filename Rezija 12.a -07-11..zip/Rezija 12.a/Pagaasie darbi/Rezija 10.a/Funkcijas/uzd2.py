import math
#izstrādāt programmu, kas ar funkciju palīdzību pavērš uz celsija grādus uz fārenheita grādus
#grādus ievada lietotājs

'''def cg_uz_fg(gradi):
    print()
    gradi * (9/5) + 32

cg_uz_fg'''

'''celsiusD = float(input('input the degrees(celsius)'))
def celsius(c):
    print('degrees in farenheit are: ',c*1.8+32)
celsius(celsiusD)'''



svars = input('Ievadiet svaru (kg): ')
augums = input('Ievadiet augumu (m):')
