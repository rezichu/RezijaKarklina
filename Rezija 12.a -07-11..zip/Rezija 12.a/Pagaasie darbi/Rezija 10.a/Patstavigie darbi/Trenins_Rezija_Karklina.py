faila_nosaukums = 'eksperimenta_dati'


def iegut_datus():
    datu_kopa = {}
    while True:
        print('Lai izietu, raksties "exit" vai "iziet", vai "stop".')
        eksperimenta_nosaukums = input('Eksperimenta nosaukums: ')
        if eksperimenta_nosaukums == 'exit' or eksperimenta_nosaukums == 'iziet' or eksperimenta_nosaukums == 'stop':
            break
        laiks = str(input('Ievadiet šodienas datumu: ')) #datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if laiks == 'exit' or laiks == 'iziet' or laiks == 'stop':
            break
        vards = input('Lūdzu ievadiet savu vārdu: ')
        if vards == 'exit' or vards == 'iziet' or vards == 'stop':
            break
        vieta = input('Ievadiet eksperimenta veikšanas vietu: ')
        if vieta == 'exit' or vieta == 'iziet' or vieta == 'stop':
            break
            
        datu_kopa[eksperimenta_nosaukums] = vards
        datu_kopa[vards] = vieta
        datu_kopa[vieta] = laiks

        with open(faila_nosaukums.txt, 'r+', encoding='utf-8') as fails:
            for eksperimenta_nosaukums, vards, vieta, laiks in datu_kopa.items():
                fails.write(f'{eksperimenta_nosaukums}, {vards}, {vieta}, {laiks}\n')


def saglabat_datus():
    print()
    

def galvena():
    print('Sveiki, lietotāj! \nLūdzu ievadiet savus eksperimenta failus!')
    print('***')
    iegut_datus()


galvena()
