for i in range(1,21):
    print(str(i))

'''for i in range(1, 21):
    print(str(i) + ".autobusa pietura")'''