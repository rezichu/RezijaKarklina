stop = '0'
ceks = 'Iepirkšanās čeks' #izveidots, lai nebūtu katrreiz jā
summa_bez_atlaides = 0.0
kopsumma = 0.0 #galējā summa

while stop == '0':
    (ceks)

    precu_skaits = int((input("Ievadiet preču skaitu: ")))
    if precu_skaits < 0: #ja mazāk par 0, tad iziet
        exit()
    produkts = input('Ievadiet preces nosaukumu: ')
    produkta_cena = round(float(input('Ievadiet 1 gab. cenu: ')),2) #formatē ar 2sk aiz komata

    #atlaides var izvēlēties, ierakstot skaitli no 1 - 5
    print('\n1 - Maxima: 30% atlaide \n2 - Elvi: 40%, ja ir klienta karte \n3 - Rimi: 20%, bet 50%, ja ir klienta karte \n4 - Mego:30%, ja pērk 3+ preces \n5 - Aibe:Katra 2 prece pa brīvu')
    atlaides_veids = input('Izvēlieties, kurā veikalā iepirksieties(rakstiet ciparu no 1 - 5): ')

    cena_bez_atlaides = produkta_cena * precu_skaits #iegūst cenu bez atlaides
    pirkuma_cena = cena_bez_atlaides #no pirkuma_cenas rēķinās atlaides

    #sākas atlaižu aprēķināšana
    if atlaides_veids == "1": #atlaide Maximā
        #pirkuma_cena = pirkuma_cena * 0,7
        pirkuma_cena*=0,7 #izmanto salikto operatoru
    elif atlaides_veids == "2": #atlaide Elvī
        klienta_karte = input('Ievadiet 1, ja ir klienta karte, bet ja nav tad 0: ')
        if klienta_karte == '1':
            pirkuma_cena*=0,6 #atlaide 40%

    elif atlaides_veids == "3": #atlaide Rimī
        klienta_karte = input('Ievadiet 1, ja ir klienta karte, bet ja nav tad 0: ')
        if klienta_karte == '1':
            pirkuma_cena*=0,5 #atlaide 50%
        else:
            pirkuma_cena*=0,8 #atlaide 20%