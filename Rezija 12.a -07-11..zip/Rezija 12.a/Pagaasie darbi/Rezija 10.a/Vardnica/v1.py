d = {1: 1,
     2: '2',
     '1':3,
     '2':3}
print(d['1']) #answer = 3
print('-------------------------------')

d = {1: {'A':{1:"A"}, 2:"B"},
     3:"C",
     'B':'D',
     "D":'E'}
print(d[1]) #answer = {'A':{1:"A"}, 2:"B"}
print('-------------------------------')

vardnica = dict()
for i in range(3):
    for j in range(2):
        vardnica[i] = j
print(vardnica) #answer = {0:1, 1:1, 2:1}
print('-------------------------------')

burti = {}
burti.fromkeys(['a','b','c','d'], 98)
print(burti) #answer = {}