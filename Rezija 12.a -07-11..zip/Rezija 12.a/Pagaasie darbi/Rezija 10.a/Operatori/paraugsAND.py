a = int(input('Ievadiet a:'))
b = int(input('Ievadiet b:'))
c = int(input('Ievadiet c:'))

if a > 0 and b > 0 and c > 0:
    print('Viens skaitlis ir lielāks par 0!')
else:
    print('Neviens nav lielāks par 0!')
