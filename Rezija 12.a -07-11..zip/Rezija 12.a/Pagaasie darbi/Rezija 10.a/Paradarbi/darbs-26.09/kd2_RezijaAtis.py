#Lieotājam jāievada skaitlis 1
skaitlis1 = int(input('Ievadiet skaitli1:'))
#Lieotājam jāievada skaitlis 2
skaitlis2 = int(input('Ievadiet skaitli2:'))

#Atkarībā no ievadītajiem skaitļiem izprintē
if skaitlis1 == 3:
    print("Skaitlis1 ir vienāds ar 3 to summa ir:",skaitlis2 + skaitlis1)
else:
    print("Skaitlis1 nav 3 to starpība ir:",skaitlis1 - skaitlis2)