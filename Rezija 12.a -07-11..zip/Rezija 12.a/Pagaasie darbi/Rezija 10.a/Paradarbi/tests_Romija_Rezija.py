#30dienas Python programmēšanas valodā
vards = 'Anna'
uzvards = 'Bērziņa'
vardsUzvards = vards + uzvards
valsts = 'Latvija'
pilseta = 'Sigulda'
vecums = 16
gads = 2023
x, y = 5, 9
print('\n',vards ,'\n',uzvards ,'\n',vardsUzvards, '\n',valsts, '\n',pilseta, '\n', vecums,'\n',gads ,'\n',x, '\n',y) 
print(vards, type(vards), uzvards, type(uzvards), vardsUzvards, type(vardsUzvards), valsts, type(valsts), pilseta, type(pilseta), vecums, type(vecums),
      gads, type(gads), x, type(x), y, type(y))