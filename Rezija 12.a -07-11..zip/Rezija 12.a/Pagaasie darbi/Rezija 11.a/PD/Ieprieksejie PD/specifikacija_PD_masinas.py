print("-------------------------------------------") #Lai vieglāk pārskatīt konsolē izvadīto infomāciju :]
class Masina: #A uzdevums - bāzes klases izveide
    def __init__(self,marka,modelis,gads):
        self.marka = marka
        self.modelis = modelis
        self.gads = gads
    
    def uzsakt(self):#B uzdevums - 3 metožu izveide - uzsakt(), kas parāda ka konkrēta mašīna sāk darboties
        print(f"{self.marka} {self.modelis} sāk darboties.")

    def apstaties(self):#B uzdevums - 3 metožu izveide - apstaties(), kas parāda ka konkrēta mašīna ir apstādināta
        print(f"{self.marka} {self.modelis} ir apstādināta.")

    def info_par_auto(self): #B uzdevums - 3 metožu izveide - info_par_auto(), kas parāda infomāciju par konkrētu mašīnu
        print(f"Marka: {self.marka}, Modelis: {self.modelis}, Gads: {self.gads}")

masina1 = Masina("Toyota","Corolla",2010) #C uzdevums - izveido objektu klasei Masina
masina1.info_par_auto()
masina1.uzsakt()
masina1.apstaties()
print("-------------------------------------------")

class Elektro_Auto(Masina): #D uzdevums - 
    def __init__(self, marka, modelis, gads, akumulatora_ietilp):
        super().__init__(marka, modelis, gads)
        self.akumulatora_ietilp = akumulatora_ietilp
        self.uzlades_limenis = 100

    def uzsakt(self):
        if self.uzlades_limenis >= 20: 
            print(f"{self.marka} {self.modelis} sāk darboties. Akumulators: {self.uzlades_limenis}%")
        else:
            print(f"{self.marka} {self.modelis} nevar sākt darboties, jo akumulators ir pārāk zems: {self.uzlades_limenis}%")

    def info_par_auto(self):
        super().info_par_auto()
        print(f"Akumulators: {self.akumulatora_ietilp}kWh")

masina2 = Elektro_Auto("Tesla","Model 3",2022,75)
masina2.info_par_auto()
masina2.uzsakt()

masina2.uzlades_limenis = 15
masina2.uzsakt()
print("-------------------------------------------")

class Degvielas_Auto(Masina):
    def __init__(self, marka, modelis, gads, bakas_tilpums):
        super().__init__(marka, modelis, gads)
        self.bakas_tilpums = bakas_tilpums
        self.degvielas_limenis = 100

    def uzsakt(self):
        if self.degvielas_limenis >= 10:
            print(f"{self.marka} {self.modelis} sāk darboties. Degvielas līmenis: {self.degvielas_limenis}%")
        else:
            print(f"{self.marka} {self.modelis} nevar sākt darboties, jo degvielas līmenis ir pārāk zems: {self.degvielas_limenis}%")
    
    def info_par_auto(self):
        super().info_par_auto()
        print(f"Bākas līmenis: {self.bakas_tilpums} litri")

masina3 = Degvielas_Auto("Audi","A7",2022,85)
masina3.info_par_auto()
masina3.uzsakt()

masina3.degvielas_limenis = 5
masina3.uzsakt()
print("-------------------------------------------")