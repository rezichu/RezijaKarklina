def parbaudit_vardu(vards):
    if not vards.isalpha():
        print("Vārdā drīkst būt tikai burti (bez cipariem vai simboliem).")# Pārbauda, vai vārds satur tikai burtus un nav tukšs.
        return False #atgriešanas vērtība(ja nebūs, tad atgriezīs None)
    #funkcija secināja, ka ievade ir nepareiza.Atgriež informāciju tai daļai, kur to izsauc,lai var apstrādāt(kā apstrādā?)
    return True #atgriešanas vērtība, ja ievade ir patiesa-vārds ir derīgs

def parbaudit_vecumu(vecums):
    if not vecums.isdigit():
        print("Vecumam jābūt skaitlim.")
        return False
    if int(vecums) <= 0:
        print("Vecumam jābūt lielākam par 0.")
        return False
    return True 

def parbaudit_atzimi(atzime):
    if not atzime.isdigit():
        print("Atzīmei jābūt skaitlim.")
        return False
    if int(atzime) <= -1:
        print("Atzīmei jābūt pozitīvam skaitlim.")
        return False
    if int(atzime) >= 11:
        print("Atzīmei jābūt vienādam vai mazākam par 10.")
        return False
    return True 

def normalizet_vardu(vards):
    return vards.strip().capitalize()

def dublikats(vards, uzvards, vecums, atzime):
    try:
        with open("dati.txt", "r", encoding='utf8') as file:
            dati = file.readlines()
        ieraksts = f"{vards},{uzvards},{vecums},{atzime}\n"
        return ieraksts in dati
    except FileNotFoundError:
        return False #fails nav izveidots, tātad dublikātu nav

def iegut_datus():
    print("Ievadiet jaunu ierakstu vai ievadiet 'STOP', lai pārtrauktu.")
    while True:
        vards = input("Ievadiet vārdu: ")
        if parbaudit_vardu(vards):
            vards = normalizet_vardu(vards)
            break
    while True:
        uzvards = input("Ievadiet uzvārdu: ")
        if parbaudit_vardu(uzvards):
            uzvards = normalizet_vardu(uzvards)
            break
    while True:
        vecums = input("Ievadiet vecumu: ")
        if parbaudit_vecumu(vecums):
                break
    while True:
        atzime = input("Ievadiet gala atzīmi (1-10): ")
        if parbaudit_atzimi(atzime):
            if atzime == 0:
                atzime = 'nv'
                break
            break
        
    if dublikats(vards, uzvards, vecums, atzime):
        print("Šis ieraksts jau pastāv. Dati netika pievienoti.")
        return
    turpinat_iegut_datus()

def turpinat_iegut_datus():
    while True:
        try:
            turpinat = input("Vai vēlaties ievadīt vēl vienu ierakstu? (j/n): ")
        except ValueError:
            print("Ievadiet pareizus datus!")
        if turpinat == 'j':
            iegut_datus()
        elif turpinat == 'n':
            break
        else:
            print("Ievadiet pareizus datus!")
        
'''def saglabat_faila(vards, uzvards, vecums, atzime, faila_nosaukums):
    with open("kontroldarbs.txt", "a", encoding='utf8') as fails:
        fails.write(f"{vards} {uzvards} {vecums} {atzime}\n")
    print(f"Dati ir pievienoti pie {faila_nosaukums}!")'''

def galvena():
    faila_nosaukums = "kontroldarbs.txt"

    while True:
        print("Izvēlieties darbību:")
        print("1 - Iegūt datus")
        print("2 - Saglabāt datus failā")
        print("3 - Parādīt datus sakārtotus pēc gala atzīmes (augošā secībā)")
        print("4 - Iziet no programmas")

        try:
            izvele = input("Jūsu izvēle: ")
            if izvele == '1':
                iegut_datus()
            elif izvele == '2':
                print()
            elif izvele == '3':
                print()
            elif izvele == '4':
                print()
            else:
                print("Ievadiet pareizus datus!")
        except ValueError:
            print('Ievadiet pareizus datus!')
    
iegut_datus()
galvena()