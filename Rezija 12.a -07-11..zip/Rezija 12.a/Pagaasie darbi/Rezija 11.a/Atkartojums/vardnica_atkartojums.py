algas_dakteris =  {
    'Anna' : 1000,
    'Atis' : 500,
    'Elīna' : 3500,
    'Katrīna' : 10000
}

algas_jauns = {
    'Atis' : 800,
    'Ludvigs' : 1200
}
algas_dakteris.update(algas_jauns)
print(algas_dakteris)