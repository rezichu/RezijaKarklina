class Rinkis:
    def __init__(self,radiuss):
        self.radiuss=radiuss
    def iestatit_radiusu(self,radiuss):
        #ja 0 vai negatīvs, tad uzstāda noklusējumā 1
        if radiuss<=0:
            self.radiuss=1
        else:
            self.radiuss=radiuss
    def izvadit_radiusu(self):
        return self.radiuss
    def diametrs(self):
        return self.radiuss*2 

radiuss=float(input("Ievadiet rādiusu:"))
rinkis=Rinkis(radiuss) 
print("Riņķa rādiuss",rinkis.izvadit_radiusu())
print("Riņķa diametrs",rinkis.diametrs())
