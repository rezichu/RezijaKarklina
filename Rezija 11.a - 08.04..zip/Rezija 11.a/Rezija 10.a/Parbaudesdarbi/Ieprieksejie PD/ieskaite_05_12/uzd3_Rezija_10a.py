saraksts = {'numurs':[], 'skaitlis':[]}

skaits = int(input())