skaitlis1 = 10 #int tipa mainīgais
skaitlis2 = 20

summa = skaitlis1 + skaitlis2
print('Summa ir:',summa)

MansVards = 'Rezija'
print('Mans vārds ir:', MansVards)

cipars = int(input("Ievadi skaitli:"))
print(cipars)

uzvards = input("Ievadi uzvārdu:")
'''python input metodes datus uztver
kā teksta(str) tipa mainīgos'''