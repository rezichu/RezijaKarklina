import csv
#izveidot cvs failu un ļaut rakstīt datus
with open('students0.csv', 'a', newline="") as file:
    writer=csv.writer(file)
    writer.writerow(["Name", "House"]) #pievieno kolonnu nosaukumus
    #iegūt datus no lietotāja
    while True:
        name=input("Enter name and house(type 'ok' to finish): ")
        if name.lower()=="ok":
            break
        student_house = input(f"Enter {name}'s house: ")
        writer.writerow([name,student_house])
        print(f"{name} has been added.\n")

#nolasīt informāciju no csv faila
students = []
with open('students0.csv', encoding='utf8') as file:
    for line in file: #cikla mainīgais katrā literācijā iegūst rindiņas saturu kā txt virkni
        name, house = line.rstrip().split(",") #noņem leikos simbolus rindas beigās, ar split sadala tekstu
        '''#izvada uz ekrāna formatētu tekstu
        print(f"{row[0]} is in {row [1]}.")'''
        students.append(f"{name} in in {house}.")
for student in sorted(students):
    print(student)
