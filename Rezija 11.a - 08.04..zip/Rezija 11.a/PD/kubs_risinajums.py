class Kubs: #definēt klasi kubs
    def __init__(self,malas_garums,krasa):
        if malas_garums >= 2 and malas_garums <= 10:
            self.malas_garums = malas_garums
        else:
            print("Malas garums neatbilst!")
            self.malas_garums = 2
        self.krasa = krasa

    #metode kuba tilpuma aprēķināšanai
    def aprekinat_tilpumu(self):
        tilpums = self.malas_garums ** 3
        return tilpums

class Bloks(Kubs):
    def __init__(self,malas_garums,krasa,kubu_skaits,forma):
        super().__init__(malas_garums,krasa)
        if kubu_skaits >= 1 and kubu_skaits <= 4:
            self.kubu_skaits = kubu_skaits
        else:
            print("Nepareiza kubu skaita vērtība!")
            self.kubu_skaits = 1 #uzstāda kubu skaitu uz 1
            #izveido nosaukumu - 9.uzd
        self.nosaukums = self.krasa + str(self.kubu_skaits)
        #atļautās vērtības ieliek sarakstā
        formas_vertibas = [11,12,13,14,22]
        if forma not in formas_vertibas:
            print("Forma neatbilst nosacījumiem")
            self.derigums = "nederīgs 0"
        else:
            self.derigums = "derīgs 1"
    
    def tilpums(self):
        kuba_tilpums = self.malas_garums*3
        bloka_tilpums = kuba_tilpums*self.kubu_skaits
        return bloka_tilpums
    
    def mainit_formu(self,jauna_forma):
        formas_vertibas = [11,12,13,14,22]
        if jauna_forma not in formas_vertibas:
            print("Forma neatbilst nosacījumiem")
            self.derigums = "nederīgs 0"
        else:
            self.derigums = "derīgs 1"


print("Dati par kubg objektu: ")
kubg = Kubs(10,"Zaļa")
print("Kubg krāsa un tilpums: ", kubg.krasa, kubg.aprekinat_tilpumu())
print("Kubg malas garums: ", kubg.malas_garums,"\n***")

print("Dati par kubr objektu: ")
kubr = Kubs(1,"Sarkana")
print("Kubr krāsa un tilpums: ", kubr.krasa, kubr.aprekinat_tilpumu())
print("Kubr malas garums: ", kubr.malas_garums,"\n***")

print("Oranžš objekts: ")
orange3 = Bloks(5,"Oranža",3,13)
print(orange3.nosaukums,orange3.tilpums(),orange3.derigums, "\n***")

print("Zils objekts: ")
blue5 = Bloks(7,"Zila",5,23)
print(blue5.nosaukums,blue5.derigums, "\n***")

print("Mainīta forma: ")
blue5.mainit_formu(12)
print(blue5.nosaukums,blue5.malas_garums,blue5.derigums, "\n***")