import requests
#sīkākus nosacīumus skatīt izdales lapā

#Reģioni ar valstīm (nemainīt)
regions = {
    "Baltijas valstis": ["Latvia", "Lithuania", "Estonia"],
    "Ziemeļeiropa": ["Denmark", "Finland", "Iceland", "Norway", "Sweden"],
    "Centrāleiropa": ["Poland", "Czech Republic", "Slovakia", "Austria", "Hungary"]
}
'''
url = f"http://universities.hipolabs.com/search?country={country}"
'''

#Funkcija: reģiona izvēle
def select_region():
    #funkcija, kas ļauj izvēlēties 1 no 3 reģioniem, atpazīst kļūdu
    while True:
        print(
            "Pieejamie reģioni:\n"
            "1 - Baltijas valstis\n"
            "2 - Ziemeļeiropa\n"
            "3 - Centrāleiropa\n"
        )

        choice = input("Ievadi reģiona numuru: ")
        if choice == "1":
            region_name = "Baltijas valstis"        #izvēlēties reģions mainīgajā
            countries = regions[region_name]        #pēc reģiona nosaukuma paņem attiecīgo valstu sarakstu no vārdnīcas
            return region_name, countries     #atgriež 2 vērtības: reģiona nosaukumu un valsts sarakstu

        elif choice == "2":
            region_name = "Ziemeļeiropa"
            countries = regions[region_name]
            return region_name, countries
        
        elif choice == "3":
            region_name = "Centrāleiropa"
            countries = regions[region_name]
            return region_name, countries

        else:
            print("Nav tāda pieejama izvēle. Mēģiniet vēlreiz.💔\n")

#Funkcija: universitāšu datu iegūšana 
def get_universities(countries):
    #saraksts glabās visas, atrastās universitātes
    universities = []
    for country in countries:
        url = f"http://universities.hipolabs.com/search?country={country}"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            universities.extend(data)
        else:
            print("Neizdevās iegūt datus par valsti: ", country, "💔")
    return universities


#Funkcija: universitāšu kārtošana
def sort_universities(universities): #var kļūdīties 2x
    meginajumi = 0
    while meginajumi < 3:
        print(
            "\nIzvēlis kārtošanas veidu:\n"
            "1 - Alfabētiski pēc universitātes nosaukuma\n"
            "2 - Pēc valsts nosaukuma\n"
            "3 - Pēc universitātes nosaukuma garuma\n"
        )

        izvele = input("Ievadi izvēli (1-3): ")
        if izvele == "1":
            return sorted(universities, key=get_name)

        elif izvele == "2":
            return sorted(universities, key=get_country)

        elif izvele == "3":
            return sorted(universities, key=get_name_length)

        else:
            print("Nepareiza izvēle. Mēģiniet vēlreiz.💔")
            meginajumi += 1

    print("Pārsniegts kļūdu skaits. Noklusēta kārtošana: pēc nosaukuma.")
    #noklusējumā kārto pēc universitātes nosaukuma
    return sorted(universities, key=get_name)

#university['name'] paņem universitātes nosaukumu no API datiem
def get_name(university):
    return university["name"]

def get_country(university):
    
    return university["country"] #university["country"] paņem valsts nosaukumu

def get_name_length(university):
    return len(university["name"])


def display_results(universities,region_name):
    print(f'\n\nPirmās 20 universitātes reģionā "{region_name}":')

    for uni in universities[:20]:
        #uni ir 1 universitāte-vārdnīca ar dažādiem laukiem
        print(
            "\nValsts: ", uni["country"],
            "\nNosaukums: ", uni["name"],
            "\nMājaslapa(s): ", ','.join(uni['web_pages'])
        )  
    print(f"Kopējais skaits: {len(universities)}")

#izsauc visu funkciju
region_name, countries = select_region()
universities = get_universities(countries)
kartot = sort_universities(universities)
display_results(kartot,region_name)