import requests

gramatu_url = "https://pro2025.azurewebsites.net/books"

def get_data():
    try:
        response=requests.get(gramatu_url)
        if response.status_code == 200:
            data = response.json()
            name = data['name']
            year = data['year_published']
            pages = data['page']
            print(f'\nGrāmatas "{name}"({year}), {pages}lpp.')
#4.2. uzdevums
            return data['name']
        else:
            print("Kļūda: nav datu! ")
    except:
        print("Kļūda: nav datu! ")
get_data()