import requests
vards = input("Ievadi vārdu: ")

url = f"https://api.agify.io/?name={vards}&country_id=LV"
atbilde = requests.get(url)

if atbilde.status_code == 200:
    dati = atbilde.json()

    #json pārveido par vārdnīcu
    print(f"\nVārds: {dati['name']}")
    print(f"\Iespējamais becums: {dati['age']}")
    print(f"\Skaits: {dati['count']} cilvēki ar šo vārdu.")

else:
    print("Nav datu!")