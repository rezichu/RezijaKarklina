import requests
skaititaji = {
    "padomi":0,
    "joki":0,
    "kaķi":0 
}

def saglabat(teksts):
    with open("mana_izvele.txt","a") as file:
        file.write(teksts+"\n")

def iegut_padomu():
    url = "https://api.adviceslip.com/advice"
    try:
        response=requests.get(url)
        if response.status_code == 200:
            #pārvērš json par python vārdnīcu
            advice = response.json()['slip']['advice']
            print(f"💡Padoms: {advice}")

            if input("Saglabāt pie izlases?(j/n): ").lower()=="j":
                saglabat("Padoms: "+advice)
        
        else:
            print("Neizdevās saņemt padomu.💔")
    except:
        print("Kļūda!😡")

#iegūt joku un izvēlēties, vai likt to failā
def iegut_joku():
    url = "https://v2.jokeapi.dev/joke/Any?type=single"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            joke = response.json().get("joke")
            print(f"🤡Joks: {joke}")

            if input("Saglabāt pie izlases?(j/n): ").lower()=="j":
                saglabat("Joks: "+joke)

        else:
            print("Neizdevās saņemt joku.💔")
    except:
        print("Kļūda!😡")

def iegut_faktu():
    url = "https://catfact.ninja/fact"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            fact = response.json().get("fact")
            print(f"😺Fakts: {fact}")

            if input("Saglabāt pie izlases?(j/n): ").lower()=="j":
                saglabat("Joks: "+fact)

        else:
            print("Neizdevās saņemt faktu.💔")
    except:
        print("Kļūda!😡")

iegut_padomu()
iegut_joku()
iegut_faktu()