#bankas sistemas simulācija
class BankasKonts:
    def __init__(self,numurs,ipasnieks,atlikums=0.0):
        self.konta_numurs = numurs
        self.konta_ipasnieks = ipasnieks
        self.konta_atlikums = atlikums
    #atribūts kas tiek izveidots katram objektam
        self.darijuma_vesture=[]
    
    #metode, kas parāda konta informāciju
    def paradit_info(self):
        print(f"Bankas konta īpašnieks: {self.konta_ipasnieks} \nBankas konta numurs: {self.konta_numurs} \nBankas konta pašreizējais atlikums: {self.konta_atlikums} EUR")

    #metode, kas palielina konta atlikumu un nedrīkst iemaksāt atlikumu, kas ir mazāks par 0
    def iemaksa(self,summa):
        if summa > 0:
            self.konta_atlikums += summa
            #pieraksti darījumu
            self.darijuma_vesture.append(f"Iemaksa: +{summa} EUR")
        else:
            print("Kļūda: Iemaksai ir jābūt lielākam par 0!")

    #metode, kas samazina konta atlikumu un nedrīkst izņemt atlikumu, kas ir mazāks par 0
    def iznemt(self,summa):
        if 0 < summa <= self.konta_atlikums:
            self.konta_atlikums -= summa
            self.darijuma_vesture.append(f"Izmaksa: -{summa} EUR")
        else:
            print("Kļūda: Izmaksai nedrīkst pārsniegt konta atlikumu!")
    #
    def parskaitit(self,merka_konts,summa):
        if 0 < summa <=self.konta_atlikums:
            self.konta_atlikums -= summa
            merka_konts.iemaksa(summa)
            self.darijuma_vesture.append(f"Pārskaitīja: +{summa} EUR uz kontu {merka_konts.konta_numurs}")
        else:
            print("Kļūda: Pārskaitīšana nedrīkst pārsniegt konta atlikumu!")

    #metode, kas parāda visu darijuma vēsturi
    def paradit_darijuma_vesturi(self):
        print(f"Transakciju vēsture:")
        #pārbaudīt, vai nav tukšs saraksts
        if len(self.darijuma_vesture)==0:
            print("Nav neviena darījuma.")
        else:
            for darijums in self.darijuma_vesture:
                print(darijums)

#--------------------------------------------------
class Banka:
    def __init__(self,nosaukums):
        self.bankas_nosaukums = nosaukums
        self.konti = {}
    
    def pievienot_kontu(self,konts):
        #atslēga = konta nr
        #vērtība = pats konta objekts
        #var atrast kontu pēc numura
        self.konti[konts.konta_numurs]=konts

    def nonemt_kontu(self,konta_numurs):
        #pārbauda, vai tāds konts ir vārdnīcā
        if konta_numurs in self.konti:
            del self.konti[konta_numurs]

    def paradit_visus_kontus(self):
        print(f"Banka: {self.bankas_nosaukums}")
        for konta_numurs, konts in self.konti.items():
            print(f"Konts: {konta_numurs}")
            konts.paradit_info()
            print()

#izveido banku un kontus
banka = Banka("Banka ABC")
konts1 = BankasKonts("001","Jānis Bērziņš")
konts2 = BankasKonts("002","Anna Liepiņa")

banka.pievienot_kontu(konts1)
banka.pievienot_kontu(konts2)

#izveidot izvēli
while True:
    print("\n1 - Parādīt konta informāciju \n2 - Veikt iemaksu \n3 - Veikt izmaksu \n4 - Veikt pārskaitījumu \n5 - Parādīt darījumu vēsturi \n6 - Iziet no programmas")
    izvele = input("Izvēlaties darbību: ")
    if izvele.strip() == "1": #paŗadīs konta nr, ja eksistē
        konta_numurs = input("\nIevadi konta nr: ")
        if konta_numurs in banka.konti:
            banka.konti[konta_numurs].paradit_info()
        else:
            print("Kļūda: Tāda konta numura neeksistē!")

    #jāmēģina iemaksāt kontā konkrēta summa(float)
    #nedrīkst nebūt skaitlis
    elif izvele.strip() == "2":
        konta_numurs = input("\nIevadi konta nr: ")
        if konta_numurs in banka.konti:
            try:
                summa=float(input("Ievadiet summu iemaksai: "))
                banka.konti[konta_numurs].iemaksa(summa)
            except ValueError:
                print("Kļūda: Jāievada skaitlis!")
        else:
            print("Kļūda: Tāda konta numura neeksistē!")

    elif izvele.strip() == "3":
        konta_numurs = input("\nIevadi konta nr: ")
        if konta_numurs in banka.konti:
            try:
                summa=float(input("Ievadiet summu izmaksai: "))
                banka.konti[konta_numurs].iznemt(summa)
            except ValueError:
                print("Kļūda: Jāievada skaitlis!")
        else:
            print("Kļūda: Tāda konta numura neeksistē!")

    elif izvele.strip() == "4":
        konta_numurs = input("\nIevadi konta nr: ")
        merka_konta_numurs = input("Ievadiet mērķa konta nr: ")
        if konta_numurs in banka.konti and merka_konta_numurs in banka.konti:
            try:
                summa=float(input("Ievadiet summu izmaksai: "))
                banka.konti[konta_numurs].parskaitit(merka_konta_numurs,summa)
            except ValueError:
                print("Kļūda: Jāievada skaitlis!")
        else:
            print("Kļūda: Tāda konta numura neeksistē!")

    elif izvele.strip() == "5":
        konta_numurs = input("\nIevadi konta nr: ")
        if konta_numurs in banka.konti:
            banka.konti[konta_numurs].paradit_darijuma_vesturi()
        else:
            print("Kļūda: Tāda konta numura neeksistē!")

    elif izvele.strip() == "6":
        exit()

    else:
        print("Kļūda: Ievadiet skaitli starp 1 un 6!")