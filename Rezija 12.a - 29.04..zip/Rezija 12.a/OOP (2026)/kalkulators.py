class Kalkulators:
    def saskaitisana(self,skaitlis1,skaitlis2):
        summa = skaitlis1+skaitlis2
        print(f"Summa: {summa}")
    def atnemsana(self,skaitlis1,skaitlis2):
        atlikums = skaitlis1-skaitlis2
        print(f"Summa: {atlikums}")
    def reizinasana(self,skaitlis1,skaitlis2):
        rezinajums = skaitlis1*skaitlis2
        print(f"Summa: {rezinajums}")
    def dalisana(self,skaitlis1,skaitlis2):
        dalijums = skaitlis1/skaitlis2
        print(f"Summa: {dalijums}")

while True:
    try:
        print("1 - saskaitīšana \n2 - atņemšana \n3 - reizināšana \n4 - dalīšana")
        izvele = int(input("Ko jūs vēlētos darīt(1-4): "))
        if izvele == 1:
            skaitlis1 = float(input("Ievadiet 1. skaitli: "))
            skaitlis2 = float(input("Ievadiet 2. skaitli: "))
            summa = Kalkulators()
            print(summa.saskaitisana(skaitlis1,skaitlis2))
        elif izvele == 2:
            skaitlis1 = float(input("Ievadiet 1. skaitli: "))
            skaitlis2 = float(input("Ievadiet 2. skaitli: "))
            atlikums = Kalkulators()
            print(atlikums.atnemsana(skaitlis1,skaitlis2))
        elif izvele == 3:
            skaitlis1 = float(input("Ievadiet 1. skaitli: "))
            skaitlis2 = float(input("Ievadiet 2. skaitli: "))
            rezinajums = Kalkulators()
            print(rezinajums.reizinasana(skaitlis1,skaitlis2))
        elif izvele == 4:
            skaitlis1 = float(input("Ievadiet 1. skaitli: "))
            skaitlis2 = float(input("Ievadiet 2. skaitli: "))
            dalijums = Kalkulators()
            print(dalijums.dalisana(skaitlis1,skaitlis2))
        else:
            break
    except ValueError:
        print("Kļūda!")