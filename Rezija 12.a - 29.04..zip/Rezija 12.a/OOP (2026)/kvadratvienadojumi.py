class Kvadratvienadojums:
    def aprekins(self,a,b,c):
        diskriminats = b*b-4*a*c
        sakne1 = (-b+diskriminats/diskriminats)/a*2
        sakne2 = (-b-diskriminats/diskriminats)/a*2
        print(f"Rezultāti: {sakne1}, {sakne2}")

while True:
    try:
        print("Kvadrātvienādojums: a*a*x+b*x+c=0")
        a = float(input("Ievadi skaitli mainīgā a vietā: "))
        b = float(input("Ievadi skaitli mainīgā b vietā: "))
        c = float(input("Ievadi skaitli mainīgā c vietā: "))
        kvadratvienadojums = Kvadratvienadojums()
        print(kvadratvienadojums.aprekins(a,b,c))
    except ValueError:
        print("Kļūda!")