#bankas sistemas simulācija
class BankasKonts():
    def __init__(self,konta_numurs, ipasnieks, atlikums=0.0):
      self.konta_numurs=konta_numurs
      self.ipasnieks=ipasnieks
      self.atlikums=atlikums
    
      self.darijumu_vesture=[]

  #metode izvada konta informaciju
    def paradit_info(self):
        print(f"Konta numurs: {self.konta_numurs}")
        print(f"Īpašnieks: {self.ipasnieks}")
        print(f"Atlikums: {self.atlikums} EUR")
    
    def iemaksat(self, summa):
      if summa>0:
        self.atlikums+=summa
        self.darijumu_vesture.append(f"Iemaksa: +{summa} EUR")
      else:
        print("Kļūda: summai jābūt lielākai par nulli")
        
    def iznemt(self,summa): #pārbaudīt, vai summa nav mazāka par < un =atlikumu
      #pievienot darijumu sarakstam
      if 0<summa<=self.atlikums:
        self.atlikums-=summa
        self.darijumu_vesture.append(f"Izņemšana-{summa} EUR")
      print("Kļūda: nepietiek līdzekļu!")
    
    def parskaitit(self,merka_konts, summa):
      if 0<summa<=self.atlikums:
        self.atlikums-=summa
        merka_konts.iemaksat(summa)
        self.darijumu_vesture.append(f"Pārskaitījums uz kontu {merka_konts.konta_numurs} :-{summa} EUR")
      else:
        print("Kļūda: nepietiek līdzekļu/nepareiza summa")  
    
    def paradit_darijumu_vesturi(self):
      pass
#----------------

class Banka():
    def __init__(self,nosaukums):
      self.nosaukums=nosaukums
      self.konti={}
      
    def pievienot_kontu(self, konts):
      #atslēga=konta nr
      #vērtība=pats konta objekts
      #var atrast kontu pēc numura
      self.konti[konts.konta_numurs]=konts
    
    def nonemt_kontu(self,konta_numurs):
      #pārbauda,vai konts ir vārdnīcā
      if konta_numurs in self.konti:
        del self.konti[konta_numurs] 
  
    def paradit_visus_kontus(self):
      print(f"Banka: {self.nosaukums}")
      for konta_numurs, konts in self.konti.items():
        print(f"Konts: {konta_numurs}")
        konts.paradit_info()
        print()        