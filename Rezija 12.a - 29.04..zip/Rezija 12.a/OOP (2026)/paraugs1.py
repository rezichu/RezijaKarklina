#definēt clase Printeris ar vienu metodi drukat(), kas izdrukā tekstu
class Printeris:
    def drukat(self, teksts):
        print(teksts)

#objekts
printeris=Printeris()
printeris.drukat("\nKā iet?😉")
print("\n","-"*50,"\n")

#definēt klases ar vienu īpašību (piemēram - vārds) un izveido 2 objektus klasei
class Spele:
    def drukat(self,magija):
        print("Maģijas tips: ",magija)

speletajs = Spele()
speletajs.drukat("Melnā maģija")
npc = Spele()
npc.drukat("Dziedējošā maģija")
print("\n","-"*50,"\n")

#definēt klasi Gramata, jābūt 3 laukiem. Metode info - izdrukā informāciju par grāmatu. Izveidot 2 objektus.
class Gramata:
    def __init__(self,nosaukums,zanrs,autors):
        self.nosaukums = nosaukums
        self.zanrs = zanrs
        self.autors = autors

    def info(self):
        print(f"Grāmatas nosaukums: {self.nosaukums} \nGrāmatas žanrs: {self.zanrs} \nGrāmatas autors: {self.autors}\n")

gramata1 = Gramata("Harijs Poters", "Fantāzija", "Džoanna Ketlīna Roulinga")
gramata1.info()

gramata2 = Gramata("Pazudušais dēls", "Novele", "Rūdolfs Blaumanis")
gramata2.info()

gramata3 = Gramata("Vinnijs Pūks un viņa draugi", "Fantāzija", "Alans Aleksandrs Milns")
gramata3.info()