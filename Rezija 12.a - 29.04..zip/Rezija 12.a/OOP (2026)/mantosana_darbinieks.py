class Persona:
    def __init__(self,vards,uzvards):
        self.vards = vards
        self.uzvards = uzvards

    def info(self):
        return f"Vārds: {self.vards}, Uzvārds: {self.uzvards}" 

#bērna clase, kas manto no vecāka klases - Persona
class Darbinieki(Persona):
    def __init__(self,vards,uzvards,alga):
        super().__init__(vards,uzvards)
        self.alga = alga #šis pieder tikai klasei darbinieks
    
    #pārraksti metodi info, paņemot tekstu no bāzes klases
    #pievienojot darbinieku algu
    def info(self):
        pamata_info = super().info()
        return f"{pamata_info}, Alga: {self.alga} EUR"

#izveidot objektu
darbinieks1 = Darbinieki("Anna","Bērziņa", 2000)
print(darbinieks1.info())       