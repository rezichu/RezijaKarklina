print("-"*20,"3. uzd", "-"*20)
class Printeris:
    def darbiba(self):
        print("Printeris izprintē darba lapu")
class Skeneris:
    def darbiba(self):
        print("Skeneris noskenē darba lapu")
class Kamera:
    def darbiba(self):
        print(f"Kamera nofotogrāfē darba lapu")

def izpildi_darbibu(obj):
    obj.darbiba()

printeris1 = Printeris()
izpildi_darbibu(printeris1)
skeneris1 = Skeneris()
izpildi_darbibu(skeneris1)
kamera1 = Kamera()
izpildi_darbibu(kamera1)



print("\n","-"*20,"4. uzd", "-"*20)
class Produkts:
    def __init__(self,nosaukums,cena):
        self.nosaukums = nosaukums
        self.cena = cena
    def galiga_cena(self):
        return f"galīgā cena: {self.cena}€"

class Elektronika(Produkts):
    def __init__(self,nosaukums,cena,PVN):
        super().__init__(nosaukums,cena)
        self.PVN = PVN
        self.gala_cena = self.cena + self.cena/100*self.PVN
    def galiga_cena(self):
        return f"{self.nosaukums} galīgā cena ar PVN {self.PVN}%: {self.gala_cena}€"
class Apgerbs(Produkts):
    def __init__(self,nosaukums,cena,atlaide):
        super().__init__(nosaukums,cena)
        self.atlaide = atlaide
        self.gala_cena = self.cena - self.cena/100*self.atlaide
    def galiga_cena(self):
        return f"{self.nosaukums} galīgā cena ar atlaidi {self.atlaide}%: {self.gala_cena}€"
class Partika(Produkts):
    def __init__(self,nosaukums,cena):
        super().__init__(nosaukums,cena)
    def galiga_cena(self):
        mantotais = super().galiga_cena()
        return f"{self.nosaukums} {mantotais}"
    
ierice1 = Elektronika("Telefons",234,21)
ierice2 = Elektronika("Dators",500,20)
drebes1 = Apgerbs("Kleita",50,22)
drebes2 = Apgerbs("Kurpes",200,50)
ediens1 = Partika("Zemene",5)
ediens2 = Partika("Pica",13)

produkti = [ierice1.galiga_cena(),ierice2.galiga_cena(),drebes1.galiga_cena(),drebes2.galiga_cena(),ediens1.galiga_cena(),ediens2.galiga_cena()]
for i in produkti:
    print(i)
groza_kop = ierice1.gala_cena+ierice2.gala_cena+drebes1.gala_cena+drebes2.gala_cena+ediens1.cena+ediens2.cena
print(f"Groza kopējā cena: {groza_kop}€")



''''print("\n","-"*20,"5. uzd", "-"*20)
class Transportlidzeklis:
    def __init__(self,nosaukums):
        self.nosaukums = nosaukums
    def atrums(self):
        pass
class Auto(Transportlidzeklis):
    def __init__(self,nosaukums):
        super().__init__(self,nosaukums)
        self.vid_atrums = 65
    def atrums(self):
        return f"Auto {self.nosaukums} brauc ar ātrumu: {self.vid_atrums}km/h"
class Velosipeds(Transportlidzeklis):
    def __init__(self,nosaukums):
        super().__init__(self,nosaukums)
        self.vid_atrums = 15
    def atrums(self):
        return f"Velosipēds {self.nosaukums} brauc ar ātrumu: {self.vid_atrums}km/h"
class Vilciens(Transportlidzeklis):
    def __init__(self,nosaukums):
        super().__init__(self,nosaukums)
        self.vid_atrums = 110
    def atrums(self):
        return f"Vilciens {self.nosaukums} brauc ar ātrumu: {self.vid_atrums}km/h"

auto1 = Auto("Peugeot")
auto2 = Auto("Toyota")
velo1 = Velosipeds("Trek")
vilciens1 = Vilciens("Lionel")
vilciens2 = Vilciens("Bachmann")
transportlidzekli = [auto1.atrums(),auto2.atrums(),velo1.atrums(),vilciens1.atrums(),vilciens2.atrums()]'''


''''print("\n","-"*20,"6. uzd", "-"*20)
class Aktivitate:
    def __init__(self,ilgums):
        self.ilgums = ilgums
    def kalorijas(self):
        pass

class Skriesana(Aktivitate):
    def __init__(self,ilgums):
        super.__init__(self,ilgums)
    def kalorijas(self):
        self.kalorijas_skrienot = 9*self.ilgums
        return f"Skrienot {self.ilgums} minūtes zaudē {self.kalorijas_skrienot} kalorijas"
class Ritenbrauksana(Aktivitate):
    def __init__(self,ilgums):
        super.__init__(self,ilgums)
    def kalorijas(self):
        self.kalorijas_minot = 5*self.ilgums
        return f"Braucot ar riteni {self.ilgums} minūtes zaudē {self.kalorijas_minot} kalorijas"
class Peldesana(Aktivitate):
    def __init__(self,ilgums):
        super.__init__(self,ilgums)
    def kalorijas(self):
        self.kalorijas_peldot = 7*self.ilgums
        return f"Peldot {self.ilgums} minūtes zaudē {self.kalorijas_peldot} kalorijas"

skriet1 = Skriesana(45)
skriet2 = Skriesana(80)
ritens1 = Ritenbrauksana(120)
peldet1 = Peldesana(45)
aktivitates = [skriet1.kalorijas(),skriet2.kalorijas(),ritens1.kalorijas(),peldet1.kalorijas()]'''