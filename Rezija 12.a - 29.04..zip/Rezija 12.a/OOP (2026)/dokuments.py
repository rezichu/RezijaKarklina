#saprast, kā dažādi opbjekti var izmantot vienu un to pašu metodi
#izveido 3 klases: PDFdokuments, WordDokuments, ExcelDokuments
#katrai klasei bus konstruktors ar vienu parametru: nosaukums
#metodi atvert(): katrai klasei parāda itu tekstu
#izveidot 3 objektus, ielikt to sarakstā, ar ciklu izsaukt atvert() metodi

class PDFdokuments:
    def __init__(self, nosaukums):
        self.nosaukums =nosaukums

    def atvert(self):
        print(f"PDF dokuments '{self.nosaukums}' tiek atvērts pārlūkā.")

class WordDokuments:
    def __init__(self, nosaukums):
        self.nosaukums =nosaukums

    def atvert(self):
        print(f"Word dokuments '{self.nosaukums}' tiek atvērts pārlūkā.")

class ExcelDokuments:
    def __init__(self, nosaukums):
        self.nosaukums =nosaukums

    def atvert(self):
        print(f"Excel dokuments '{self.nosaukums}' tiek atvērts pārlūkā.")

#izveidot 3 objektus
dok1 = PDFdokuments("atskaite.pdf")
dok2 = WordDokuments("domraksts.docx")
dok3 = ExcelDokuments("dati.xlsx")

#visus objektus ieliek sarakstā
dokumenti = [dok1,dok2,dok3]

for i in dokumenti:
    i.atvert()