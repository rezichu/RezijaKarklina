#bankas sistemas  skelets(pārvediots stundas darbs)


class BankasKonts: 
    def __init__(self, konta_numurs, ipasnieks, atlikums=0.0):
        self.konta_numurs = konta_numurs #konstruktora parametri (dati, ko padod no ārpuses)
        self.ipasnieks = ipasnieks
        self.atlikums = atlikums

        self.darijumu_vesture = [] #tiek izveidots automātiski katram objektam

    #izvada konta informāciju
    def paradit_info(self):
        print(f"Konta numurs: {self.konta_numurs}")
        print(f"Īpašnieks: {self.ipasnieks}")
        print(f"Atlikums: {self.atlikums:.2f} EUR\n")

    #iemaksa kontā
    def iemaksat(self, summa):
        if summa > 0:
            self.atlikums += summa
            #pieraksta transakciju sarakstā kā tekstu
            self.darijumu_vesture.append(f"Iemaksa: +{summa:.2f} EUR\n")
        else:
            print("Kļūda: summai jābūt lielākai par 0\n")

    #izņem naudu no konta
    def iznemt(self, summa):
        if summa <= 0:
            print("Kļūda: summai jābūt lielākai par 0\n")
        elif summa <= self.atlikums:
            self.atlikums -= summa
            self.darijumu_vesture.append(f"Izņemšana: -{summa:.2f} EUR\n")
        else:
            print("Kļūda: nepietiek līdzekļu\n")

    #pārskaita naudu uz citu kontu
    def parskaitit(self, merka_konts, summa):
        if summa <=0:
            print("Kļūda: summai jābūt lielākai par 0\n")
        elif summa<=self.atlikums:
            self.atlikums -=summa 
            merka_konts.iemaksat(summa) #merka_konts-BankasKonts objekts(saņēmēja konts), lai varētu izsaukt iemaksat() un pārskaitīt naudu
            self.darijumu_vesture.append(
                f"Pārskaitījums uz {merka_konts.konta_numurs}: -{summa:.2f} EUR\n"
            )
        else:
            print("Kļūda: nepietiek līdzekļu\n")

    #izvada darījumu vēsturi
    def paradit_darijumu_vesturi(self):
        print("Darījumu vēsture:")
        if len(self.darijumu_vesture) == 0:
            print("Nav darījumu\n")
        else:
            for darijums in self.darijumu_vesture:
                print(darijums)


class Banka:
    def __init__(self, nosaukums):
        self.nosaukums=nosaukums
        self.konti={} #vārdnīca ļauj ātri atrast kontu pēc numura

    #pievieno kontu
    def pievienot_kontu(self, konts):
        self.konti[konts.konta_numurs]=konts 
        #vārdnīcā self.konti:
        #atslēga = konta numurs
        #vērtība = pats konta objekts

    #noņem kontu
    def nonemt_kontu(self, konta_numurs):
        if konta_numurs in self.konti:
            del self.konti[konta_numurs] #del izdzēš konkrētu atslēgu un tās vērtību

    #parāda visus kontus: iziet cauri visiem kontiem vārdnīcā 
    #items atgriež pārus:(key, value)
    #konta_numurs:atslēga
    #konts:objekts (BankasKonts)
    def paradit_visus_kontus(self):
        print(f"Banka: {self.nosaukums}")
        for konts in self.konti.values():
            print("--------------------")
            konts.paradit_info()
        print("--------------------")


class Krajkonts(BankasKonts):
    def __init__(self, konta_numurs, ipasnieks, atlikums=0.0, procentu_likme=0.02):
        super().__init__(konta_numurs, ipasnieks, atlikums)
        self.procentu_likme = procentu_likme

    def pieskaitit_procentus(self):
        summa = self.atlikums * self.procentu_likme #aprēķina cik pieskaitīs klāt atlikumam no procentu_likmes
        self.atlikums += summa
        self.darijumu_vesture.append(f"Procenti: +{summa:.2f} EUR\n")

    def paradit_info(self):
        print(f"Konta numurs: {self.konta_numurs}")
        print(f"Īpašnieks: {self.ipasnieks}")
        print(f"Atlikums: {self.atlikums:.2f} EUR")
        print(f"Procentu likme: {self.procentu_likme}\n") #pārraksta metodi, pieliekot klāt papildus info par Krajkontu


class Kreditkonts(BankasKonts):
    def __init__(self, konta_numurs, ipasnieks, atlikums=0.0, kredita_limits = 500.00):
        super().__init__(konta_numurs, ipasnieks, atlikums)
        self.kredita_limits = kredita_limits
        self.limits= kredita_limits #lai varētu pārbaudīt, ka nepārsniedz kredīta limitu nemainot kredīta mainīgā lielumu
    
    def iznemt(self, summa):
        if summa > self.limits:
            print("Kļūda: pārsniegts kredīta limits\n")
        elif summa <= self.limits:
            self.atlikums -= summa
            self.limits -= summa #noņem nost no limita, pielīdzinot limitu darījumiem
            self.darijumu_vesture.append(f"Izņemšana: -{summa:.2f} EUR\n")
        else:
            print("Kļūda: nepietiek līdzekļu\n")

    def paradit_info(self):
        print(f"Konta numurs: {self.konta_numurs}")
        print(f"Īpašnieks: {self.ipasnieks}")
        print(f"Atlikums: {self.atlikums:.2f} EUR")
        print(f"Kredīta limits: {self.kredita_limits} EUR\n") #pārraksta metodi, pieliekot klāt papildus info par Kreditkontu


#Objektu piemeri

banka = Banka("Banka ABC")

konts1 = BankasKonts("001", "Jānis Bērziņš", 500.0)
konts2 = Krajkonts("002", "Anna Liepiņa", 1200.0, 0.02)
konts3 = Kreditkonts("003", "Pēteris Ozols", 200.0, 500.0)
konts4 = BankasKonts("004", "Līga Ozoliņa", 0.0)

banka.pievienot_kontu(konts1)
banka.pievienot_kontu(konts2)
banka.pievienot_kontu(konts3)
banka.pievienot_kontu(konts4)

print(" "*20,"BankasKonts darbības")
konts1.paradit_info()
konts1.iemaksat(100)
konts1.iemaksat(-10) #izmet kļūdu par to ka nedrīkst iemaksāt negatīvu summu
konts1.iznemt(50)
konts1.iznemt(1000) #izmet kļūdu par limita pārkāpšanu
konts1.parskaitit(konts2, 200)
konts1.parskaitit(konts2, -5) #izmet kļūdu par to ka nevar pārskaitīt negatīvu summu
konts4.paradit_darijumu_vesturi() #parāda tukšu darījumu sarakstu
konts1.paradit_darijumu_vesturi()

print(" "*20,"Krajkonts darbības")
konts2.paradit_info()
konts2.pieskaitit_procentus()
konts2.paradit_darijumu_vesturi()

print(" "*20,"Kreditkonts darbības")
konts3.paradit_info()
konts3.iznemt(450)
konts3.iznemt(300) #izmet kļūdu par kredīta limita pārkāpšanu
konts3.paradit_darijumu_vesturi()

print(" "*20,"Banka darbības")
banka.paradit_visus_kontus()
banka.nonemt_kontu("004") #izņem konta informāciju no Bankas saraksta
banka.paradit_visus_kontus

print("\n"," "*20,"Polimorfisms")
visi_konti = [konts1, konts2, konts3] #ieliek visus kontus (kurus neizdzēsa) sarakstā un izprintē metodi paradit_info()
for konts in visi_konti:
    konts.paradit_info()
    print("--------------------") #╰(*°▽°*)╯