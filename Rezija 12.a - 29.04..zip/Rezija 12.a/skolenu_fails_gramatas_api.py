import requests
import random

#aizpildīt kodu atbilstoši prasībām‼️‼️‼️
#un salabot formatējumu, ja nepieciešams ‼️‼️‼️


#Šī adrese atgriež sarakstu ar grāmatām JSON formātā
gramatu_url = "https://pro2025.azurewebsites.net/books"

#URL adrese, no kuras iegūstam žurnālu datus.
zurnalu_url = "https://pro2025.azurewebsites.net/journals"


#4.1. uzdevums
def get_data():
    try:
        response=requests.get(gramatu_url)
        if response.status_code == 200:
            data = response.json()
            name=data['name']
            year=data['year_published']
            pages=data['pages']
#4.2. uzdevums
            print(f'Grāmatas "{name}"({year}), {pages} lpp.')
            return name
    except:
        print("Kļūda: nav datu! ")
get_data()
#dati no api laukiem
#name-grāmatas nosaukums
#year_published-izdošanas gads
#pages-lappušu skaits

#4.3. uzdevums
#Izveido sarakstu, kurā būs tikai grāmatu nosaukumi
nosaukumi=[]
nosaukumi.append(get_data())

#Ieraksti nosaukumus teksta failā.
#encoding="utf-8" vajadzīgs, lai pareizi saglabātos latviešu burti(ja buus)
with open("nosaukumi.txt", "w", encoding="utf-8") as fails:
    for nosaukums in nosaukumi:
        fails.write(nosaukums + "\n")

print("4.3. Grāmatu nosaukumi ierakstīti failā nosaukumi.txt")


#4.4. uzdevums: visvecākā grāmata
    #year_published API datos ir teksts, tāpēc jāparveido par int

print("4.4. Visvecākā grāmata:", visvecaka_gramata["name"])


#4.5. uzdevums:visu lappusu kopejais skaits un videjais aritmetiskais
kopejais_lappusu_skaits = 0
kopeja_cena = 0

for gramata in gramatas:
    pass
    #pages un price API datos ir teksta veidā, tāpēc tie jāpārveido par skaitļiem


print("4.5. Kopējais lappušu skaits:", kopejais_lappusu_skaits)
print("4.5. Vidējā aritmētiskā cena:", round(videja_cena, 2))


#4.6. uzdevums: gramata ar garako nosaukumu+autors un gads
#Izsauc iepriekš izveidoto funkciju
gramata_ar_garako_nosaukumu = garakais_nosaukums(gramatas)
#Funkcija, kas atrod un atgriež grāmatu ar garāko nosaukumu
#Parametrs "gramatas" ir saraksts ar visām grāmatām

print("4.6. Grāmatas ar garāko nosaukumu autors:", gramata_ar_garako_nosaukumu["author"])
print("4.6. Grāmatas ar garāko nosaukumu gads:", gramata_ar_garako_nosaukumu["year_published"])


#4.7. uzdevums
#Izveidojam jaunu datu struktūru(šajā piemērā var ņemt vienkārši sarakstu) ar visiem datiem par visām grāmatām
#Ja autoram ir tukšs teksts, tad ierakstām "Nav norādīts"
gramatu_dati = []
print("4.7. Izveidots saraksts ar visām grāmatām.")




#4.8.uzdevums
#izvadi visu grāmatu autorus alfabētiskā secībā (A–Z) (1 punkts), turklāt nodrošinot, ka autori neatkārtojas

    #Pārbauda, vai autors jau nav sarakstā-tas nodrošina, ka autori neatkārtojas

#Sakārtot autorus alfabētiskā secībā
print("4.8. Autori alfabētiskā secībā:")


#4.9. uzdevums
#Izveidojam vārdnīcu, kur atslēga būs autors, vērtība būs šī autora grāmatu nosaukumu saraksts

print(f'4.9. Autors, kuram ir visvairāk grāmatu ({gramatu_skaits}), - {autors_ar_visvairak_gramatam}:')



#4.10. uzdevums
#Iegūst žurnālu datus no otrās API adreses



#Nejauši izvēlas 10 žurnālus no visa žurnālu saraksta
#random.sample neatkārto vienu un to pašu elementu vairākas reizes
nejauši_zurnali = random.sample(visi_zurnali, 10)

#Izveidojam jaunu sarakstu, kur katram žurnālam glabājas tikai nosaukums un izdevējs
zurnalu_saraksts = []

#pievieno jaunu žurnālu

print("\nŽurnālu saraksts pēc jaunā žurnāla pievienošanas sākumā:")


#dzēš pēdējo žurnālu no saraksta


print("Žurnālu saraksts pēc pēdējā žurnāla dzēšanas:")
