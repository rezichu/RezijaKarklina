#uzd1: Ļaut ievadīt tikai veselus skaitļus(ievadot kaut ko citu, prasīt rakstīt vēlreiz-ar while true to var izdarīt)
print("***********Saraksti***********")  
while True: 
    try:  #list saglabā sarakstā
        saraksts = list(map(int, input("Ievadi skaitļu sarakstu (ar komatiem): ").split(","))) #ievadīto skaitļu atdalīšana ar komatu 
        break
    except ValueError:
        print("Lūdzu ievadi tikai veselus skaitļus, atdalot tos ar komatiem.") 
        #visvienkāršāk to izdarīt ar try/except

#uzd2:Aprēķināt vidējo vērtību, noapaļojot ar 2 cipariem aiz komata 
#ar sum metodi iegūst saraksta elementu summu, izdala ar visu garumu(len atgriezīs garumu kā skaitli) un izdrukā
vid_vertiba = sum(saraksts)/len(saraksts) 
#vid_vertiba_2 = round(vid_vertiba, 2)  #noapaļos ar 2 cipariem aiz komata
print(f"Vidējā vērtība: {vid_vertiba}")

#uzd3: Atrast skaitļu skaitu, kas pārsniedz vidējo vērtību
lielaks_par_vid = 0  #sākumā neviens sk nepārsniedz vidējo
for i in saraksts:
    if i > vid_vertiba:   #ar for ciklu iet cauri visam sarakstam, kur pārbauda vai cikla skaitītājs(i-katrs saraksta elements ir >par vid_vertibu)
        lielaks_par_vid += 1    #lielaks_par_vid=i+lielaks_par_vid
print(f"Skaitļu skaits, kas pārsniedz vidējo vērtību: {lielaks_par_vid}")



print("\n***********Vārdnīcas***********")
vardnica = {}# Sākumā izveido tukšu vārdnīcu, kur glabās lietotāja ievaditos datus
while True: #jānodrošina pareizo datu ievade. No cikla iziet tikai tad, kad dati ievadīti pareizi
    try:
        ievade = input("Ievadi vārdnīcu (atslega:vērtība, ...): ")
        dati_saraksts = ievade.split(",") #ievadītos datus atdala ar komatiem
        for dati in dati_saraksts: 
            atslega, vertiba = dati.split(":") #ar for ciklu katrs pāris tiek sadalīts ar : un ielikts vārdnīcā. 
            vardnica[atslega] = int(vertiba)  #tā kā nepieciešams atrast mazāko skaitli nāk.uzd, tad pārvērš vērtību par int
        break
    except ValueError:
        print("Lūdzu ievadi pareizu vārdnīcu ar formātu atslega:vērtība, piemēram, '10a:25, 9b:30'.")

#uzd4:Atrast atslēgu ar vismazāko vērtību(vismazāko skolēnu skaitu)
#1 variants
mazaka_vertiba = min(vardnica, key=vardnica.get)
print(f"Atslēga ar vismazāko vērtību (skolēnu skaitu) ir: {mazaka_vertiba} ar vērtību {vardnica[mazaka_vertiba]}")

#2 variants
#Atrast atslēgu ar vismazāko vērtību, izmantojot for ciklu
maz_vertiba = None #pirmajā iterācijā caur vārdnīcu šos iestata uz None, lai varētu salīdzināt pirmo vērtību-ja maz_vertiba ir None,tad piešķir pirmo key:value
atslega_ar_maz_vert = None

for key, value in vardnica.items():  #ar for ciklu apskata katru pāri vārdnīcā
    if maz_vertiba is None or value < maz_vertiba:   #katrā nākamajā iterācijā salīdzina esošo vērtību ar esošo mazāko un atjaunina(ja nepieciešams)
        maz_vertiba = value
        atslega_ar_maz_vert = value
print(f"Atslēga ar vismazāko vērtību (skolēnu skaits) ir: {atslega_ar_maz_vert} ar vērtību {maz_vertiba}")
#uzd5:Iegūt visu atslēgu sarakstu(tikai atslēgu)
atslegas = list(vardnica.keys())
print(f"Visu klašu atslegas: {atslegas}")



from collections import deque
#izmanto divvirzienu rindas(nejaukt metodes!)
print("\n***********Rindas***********")
rinda = deque(input("Ievadi rindas elementus, atdalot ar atstarpēm: ").split())

#uzd6:Noņemt pirmos divus elementus
rinda.popleft()
rinda.popleft()
print(f"Rinda pēc pirmo divu elementu noņemšanas: {rinda}")

#uzd7:Pievienot divus jaunus elementus
rinda.append("Jauns1")
rinda.append("Jauns2")
print(f"Rinda pēc jaunu elementu pievienošanas: {rinda}")

#uzd8:Izdrukāt rindas saturu
print(f"Rindas saturs: {rinda}")



print("\n***********Korteži***********")
kortezitis = tuple(input("Ievadi korteža elementus, atdalot ar komatiem: ").split(","))
elements = input("Ievadi elementu, lai pārbaudītu: ")
#uzd9:Pārbaudīt, vai elements ir kortežā
if elements in kortezitis:
    print(f"Elements '{elements}' ir kortežā.")
else:
    print(f"Elements '{elements}' nav kortežā.")
#uzd10:Saskaitīt, cik reizes elements parādās kortežā
skaits = kortezitis.count(elements)
print(f"Elements '{elements}' parādās kortežā {skaits} reizes.")


