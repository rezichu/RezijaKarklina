from collections import deque #importē deque

print("-"*5,"Darbs ar sarakstu(list)","-"*5)
#izveido 2 tukšus sarakstus
vardi = []
vardilidz5 = []
while True:
    try:
        vards = input("Ievadi vārdu (vai 'stop'): ").strip() #strip, lai vieglāk pārbaudītu vai ievade tukša
        if vards == "stop":
            break
        elif len(vards) >= 5: #pārbauda vai vārds ir garāks par 5 burtiem
            vardi.append(vards) #pievieno pie kopējā saraksta
            vardilidz5.append(vards) #pievieno pie saraksta, kur vārdi ir garāki par 5
        elif vards == "":
            print("Kļūda: vārds nedrīkst būt tukšs.")
        else:
            vardi.append(vards) #tikai pievieno pie kopējā saraksta
    except ValueError:
        print("Kļūda: vārds nedrīkst būt tukšs.")

print("Visi vārdi: ",vardi)
print("Vārdi ar garumu >= 5: ",vardilidz5)

print("\n","-"*5,"Telefongrāmata","-"*5)
telefongramata = {}
while True: #while un if murgs
    telefons = ""
    while True:
        if telefons == "stop":
            break
        vards = input("Ievadi vārdu (vai 'stop'): ").strip() #strip, lai vieglāk pārbaudītu vai ievade tukša
        if vards == "stop":
            break
        elif vards == "":
            print("Kļūda: vārds nedrīkst būt tukšs.")
        else:
            while True:
                telefons = input("Ievadi telefonu (vai 'stop'): ").strip()
                if telefons == "stop":
                    break
                elif telefons == "":
                    print("Kļūda: telefons nedrīkst būt tukšs.")
                else:
                    telefongramata[vards] = telefons
                    break
    break

print(f"\nTelefongrāmata: {telefongramata}")
while True:
    mekle = input("Ievaidiet vārdu, ko meklējat(vai X): ").strip() #strip, lai vieglāk pārbaudītu vai ievade tukša
    if mekle == "X":
        break
    elif mekle == "":
        print("Šāds kontakts neeksistē!")
    elif mekle == "x": #easter egg
        print("Lai beigtu meklēšanu, ievadiet X ar lielo burtu.")
    else:
        try:
            print(f"{mekle}: {telefongramata[mekle]}")
        except KeyError:
            print("Šāds kontakts neeksistē!")


print("\n","-"*5,"Darbs ar rindu(queue) un divvirzienu rindu(deque)","-"*5)
faili = deque()
while True:
    fails = input("Ievadi faila nosaukumu (vai 'stop'): ").strip() #strip, lai vieglāk pārbaudītu vai ievade tukša
    if fails == "stop":
        break
    elif fails == "":
        print("Kļūda: faila nosaukums nedrīkst būt tukšs.")
    else:
        faili.appendleft(fails) #saglā datus rindā no otra gala
        while len(faili)>5:
            liekais=faili.pop() #izdzēšs vecākos datus

print("\nPēdējie 5 faili (jaunākais pirmais):\n", faili)

print("\n","-"*5,"Darbs ar kopu(set)","-"*5)
id = set()
while True:
    try:
        skolena_id = input("Ievadi skolēna ID (vai 'stop'): ").strip() #strip, lai vieglāk pārbaudītu vai ievade tukša
        if skolena_id == "":
            print("Kļūda: jāievada vesels skaitlis vai 'stop'.")
        elif skolena_id == "stop":
            break
        elif skolena_id.isalpha(): #pārbauda vai ievade ir vārds, ja ir tad liek brīdina
            print("Kļūda: jāievada vesels skaitlis vai 'stop'.")
        else:
            if skolena_id in id:
                print("duplikāts")
            else:
                id.add(skolena_id)
                print("pievienots")
    except ValueError:
        print("Kļūda: jāievada vesels skaitlis vai 'stop'.")


print("Pieteikušies ID: ",id)