print("1.uzvevums - darbs ar sarakstu")
saraksts=[]

parbaude=0
while parbaude<10:
    try:
        skaitlis=int(input("Ievadiet veselu skaitli: "))
        saraksts.append(skaitlis)
        parbaude=parbaude+1 #pievienot ka drīkst kļūdīties tikai 3 reizes
    except ValueError:
        print("Ievadiet veselu skaitli!")

print(saraksts)
summa=0
for num in saraksts:
    summa += num #pievienot ka parāda mazāko un lielāko skaitli bez max un min
print("Saraksta vērtību summa: ",summa)

print("2.uzvevums - darbs ar vārdnīcu")
#lietotājs ievada vārdnīcu (atslēga:vērtība) atdalot ar komatu (vienā)
    #pārbauda vai tiek ievadīts pareizā formātā un brīdina lietotāju
#parāda visgarāko atslēgu (ne atslēgas garumu)

print("3.uzvevums - darbs ar kortežu")
#lietotājs ievada vērtības atdalot ar komatu
#programa jautā ievadīt elementu, lai atrastu tā indeksu un skaitu
#ja elementu atrod tad izmet indeksu, skaitu ("Elements '2' kortežā atrodas 2 reizes")

print("4.uzvevums - darbs ar kopu")
#lietotājs izveido 2 kopas, kurā ievada elementus atdalot ar atstarpēm
#parāda prasmes pielietojot - intersection(), union(), difference(), symetric_difference(), issubset() - metodes un salīdzina vai kopas ir vienādas
#katras metodes rezultātu saglabāšanai tiek veidoti jauni mainīgie
#pie rezultātu izvades tiek pievienots paskaidrojošs teksts (apvienotā kopa: rezultāti)