

# Uzdevums 1: Saraksti
# Lietotājs ievada veselu skaitļu sarakstu, atdalot to ar komatiem.
# 1. Atrast visu elementu summu.
# 2. Atrast lielāko un mazāko skaitli.

print("Uzdevums 1: Saraksti")

ievade = input("Ievadi veselu skaitļu sarakstu (ar komatiem): ")
teksta_saraksts = ievade.split(",")

saraksts = []
for elements in teksta_saraksts:
    skaitlis = int(elements.strip())   # noņem atstarpes un pārveido par int
    saraksts.append(skaitlis)

saraksta_summa = sum(saraksts)
lielakais = max(saraksts)
mazakais = min(saraksts)

print(f"Saraksta summa: {saraksta_summa}")
print(f"Lielākais skaitlis: {lielakais}, Mazākais skaitlis: {mazakais}")

print("Uzdevums 1: Saraksti")

saraksts = []  
max_kļūdas = 3
kļūdu_skaits = 0

while len(saraksts) < 10:
    try:
        skaitli = input(f"Ievadi {10 - len(saraksts)} veselos skaitļus (ar komatiem): ")
        saraksts = list(map(int, skaitli.split(",")))
        #map() ir domāts, lai automātiski piemērotu vienu funkciju visiem elementiem secībā (piemēram, sarakstā).
        if len(saraksts) != 10:
            print("Jāievada tieši 10 skaitļi! Mēģini vēlreiz.")
            saraksts = [] #iztukšo sarakstu, lai nākamajā iterācijā mēs mēģinātu no jauna
    except ValueError:
        kļūdu_skaits += 1
        if kļūdu_skaits >= max_kļūdas:
            print("Pārāk daudz kļūdu. Programma beidzas.")
            exit()
        print(f"Nederīga ievade! Atlikušie mēģinājumi: {max_kļūdas - kļūdu_skaits}")

saraksta_summa = 0
lielakais = saraksts[0]
mazakais = saraksts[0]

for skaitlis in saraksts:
    saraksta_summa += skaitlis
    if skaitlis > lielakais:
        lielakais = skaitlis
    if skaitlis < mazakais:
        mazakais = skaitlis

print(f"Saraksta summa: {saraksta_summa}")
print(f"Lielākais skaitlis: {lielakais}, Mazākais skaitlis: {mazakais}")




# Uzdevums 2: Vārdnīcas
# Lietotājs ievada vārdnīcu formā "atslēga: vērtība", atdalot pārus ar komatiem.
# 1. Atrast vērtības summu, ja visas vērtības ir skaitļi.
# 2. Atrast visgarāko atslēgu.

print("\nUzdevums 2: Vārdnīcas")
vardnica = {k: v for k, v in (pair.split(":") for pair in input("Ievadi vārdnīcu (atslēga:vērtība, ...): ").split(","))}
vardnica_vardibam = {k: int(v) for k, v in vardnica.items() if v.isdigit()}
vardnica_summma = sum(vardnica_vardibam.values())
visgaraka_atslega = max(vardnica.keys(), key=len)
print(f"Vērtību summa: {vardnica_summma}")
print(f"Visgarākā atslēga: {visgaraka_atslega}")

print("Ievadi vārdnīcu formātā 'atslēga:vārdība', katru pāri atdalot ar komatu.")

while True:
    try:
        # Lietotāja ievade
        ievade = input("Ievadi vārdnīcu: ")

        # Pārveido ievadi par vārdnīcu
        parīši = ievade.split(",")  # Sadala pa komatiem
        vardnica = {}

        for pāris in parīši:
            if ":" not in pāris:  # Pārbauda, vai ir atdalīts ar :
                raise ValueError("Kļūda! Jāizmanto ':' starp atslēgu un vērtību.")
            atslēga, vērtība = pāris.split(":", 1)  # Dalām tikai pirmo reizi
            atslēga = atslēga.strip()  # Noņem liekās atstarpes
            vērtība = vērtība.strip()
            vardnica[atslēga] = vērtība  # Pievieno vārdnīcai

        if not vardnica:  # Pārbauda, vai vārdnīca nav tukša
            raise ValueError("Kļūda! Vārdnīca nevar būt tukša.")

        break  # Ja nav kļūdu, pārtrauc ciklu

    except ValueError as e:
        print(e)
        print("Mēģini vēlreiz!")

# Atrod visgarāko atslēgu
visgaraka_atslega = max(vardnica.keys(), key=len)

# Izvada visgarāko atslēgu
print(f"Visgarākā atslēga: {visgaraka_atslega}")



# Uzdevums 4: Korteži
# Lietotājs ievada korteža elementus.
# 1. Atrast elementa indeksu un skaitu, ko norāda lietotājs.

print("\nUzdevums 4: Korteži")
kortezis = tuple(input("Ievadi korteža elementus, atdalot ar komatiem: ").split(","))
elements = input("Ievadi elementu, lai atrastu tā indeksu un skaitu: ")
indekss = kortezis.index(elements) if elements in kortezis else -1
skaits = kortezis.count(elements)
print(f"Indekss: {indekss} (ja -1, tad elements nav atrasts)")
print(f"Skaits: {skaits}")

# Uzdevums 5: Kopas
# Lietotājs ievada divas kopas elementus.
# 1. Atrast kādu elementu pārkıāšanos.
# 2. Apvienot kopas.

print("Ievadi pirmās un otrās kopas elementus, atdalot tos ar atstarpēm.")

# Lietotāja ievade un kopu izveide
kopa1 = set(input("Ievadi pirmās kopas elementus: ").split())
kopa2 = set(input("Ievadi otrās kopas elementus: ").split())

# Izmanto dažādas kopu metodes un saglabā rezultātus mainīgajos
kopa_apvienota = kopa1.union(kopa2)  # Apvienošana
kopa_kopiga = kopa1.intersection(kopa2)  # Kopīgie elementi
kopa_stariba1 = kopa1.difference(kopa2)  # Elementi, kas ir tikai pirmajā kopā
kopa_stariba2 = kopa2.difference(kopa1)  # Elementi, kas ir tikai otrajā kopā
kopa_sym_diff = kopa1.symmetric_difference(kopa2)  # Simetriskā starpība
vai_subset = kopa1.issubset(kopa2)  # Vai pirmā kopa ir otrās apakškopa
vai_equal = kopa1 == kopa2  # Vai kopas ir vienādas

# Rezultātu izvadīšana ar paskaidrojošu tekstu
print("\nRezultāti:")
print(f"Apvienotā kopa (union): {kopa_apvienota}")
print(f"Kopīgie elementi (intersection): {kopa_kopiga}")
print(f"Elementi, kas ir tikai pirmajā kopā (difference): {kopa_stariba1}")
print(f"Elementi, kas ir tikai otrajā kopā (difference): {kopa_stariba2}")
print(f"Simetriskā starpība (symmetric_difference): {kopa_sym_diff}")

if vai_subset:
    print("Pirmā kopa ir otrās apakškopa.")
else:
    print("Pirmā kopa NAV otrās apakškopa.")

if vai_equal:
    print("Kopas ir vienādas.")
else:
    print("Kopas NAV vienādas.")

# Kritēriji:
# - Pareizs datu ievads (katram uzdevumam atbilstošs formāts).
# - Precīzi aprēķini.
# - Koda loģika atbilst uzdevuma prasībām.
# - Korekti apstrādātas izņēmumu situācijas (piem., nekorekta ievade).
